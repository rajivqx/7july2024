<?php

// Class Theme Helper
require_once ( get_theme_file_path( '/core/class/theme-helper.php' ) );

// Class Theme Cache
require_once ( get_theme_file_path( '/core/class/theme-cache.php' ) );

// Class Walker comments
require_once ( get_theme_file_path( '/core/class/walker-comment.php' ) );

// Class Walker Mega Menu
require_once ( get_theme_file_path( '/core/class/walker-mega-menu.php' ) );

// Class Theme Likes
require_once ( get_theme_file_path( '/core/class/theme-likes.php' ) );

// Class Theme Cats Meta
require_once ( get_theme_file_path( '/core/class/theme-cat-meta.php' ) );

// Class Single Post
require_once ( get_theme_file_path( '/core/class/single-post.php' ) );

// Class Tinymce
require_once ( get_theme_file_path( '/core/class/tinymce-icon.php' ) );

// Class Theme Autoload
require_once ( get_theme_file_path( '/core/class/theme-autoload.php' ) );

// Class Theme Dashboard
require_once ( get_theme_file_path( '/core/class/theme-panel.php' ) );

// Class Theme Verify
require_once ( get_theme_file_path( '/core/class/theme-verify.php' ) );

function irecco_content_width() {
	if (! isset( $content_width )) {
		$content_width = 940;
	}
}
add_action( 'after_setup_theme', 'irecco_content_width', 0 );

function irecco_theme_slug_setup() {
	add_theme_support('title-tag');
}
add_action('after_setup_theme', 'irecco_theme_slug_setup');

add_action('init', 'irecco_page_init');
if (! function_exists('irecco_page_init')) {
	function irecco_page_init() {
		add_post_type_support('page', 'excerpt');
	}
}

add_action('admin_init', 'irecco_elementor_dom');
if (!function_exists('irecco_elementor_dom')) {
    function irecco_elementor_dom()
    {
        if(!get_option('wgl_elementor_e_dom') && class_exists('\Elementor\Core\Experiments\Manager')){
            $new_option = \Elementor\Core\Experiments\Manager::STATE_INACTIVE;
			update_option('elementor_experiment-e_dom_optimization', $new_option);
            update_option('wgl_elementor_e_dom', 1);
        }
    }
}

if (! function_exists('irecco_main_menu')) {
	function irecco_main_menu ($location = '') {
		wp_nav_menu( [
			'theme_location'  => 'main_menu',
			'menu'  => $location,
			'container' => '',
			'container_class' => '',
			'after' => '',
			'link_before' => '<span>',
			'link_after' => '</span>',
			'walker' => new iRecco_Mega_Menu_Waker()
		] );
	}
}

// return all sidebars
if (! function_exists('irecco_get_all_sidebar')) {
	function irecco_get_all_sidebar() {
		global $wp_registered_sidebars;
		$out = [];
		if (empty( $wp_registered_sidebars ) )
			return;
		 foreach ($wp_registered_sidebars as $sidebar_id => $sidebar) :
			$out[$sidebar_id] = $sidebar['name'];
		 endforeach;
		 return $out;
	}
}

if (! function_exists('irecco_get_custom_menu')) {
	function irecco_get_custom_menu() {
		$taxonomies = [];

		$menus = get_terms('nav_menu');
		foreach ($menus as $key => $value) {
			$taxonomies[$value->name] = $value->name;
		}
		return $taxonomies;
	}
}

function irecco_get_attachment($attachment_id) {
	$attachment = get_post( $attachment_id );
	return [
		'alt' => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
		'caption' => $attachment->post_excerpt,
		'description' => $attachment->post_content,
		'href' => get_permalink( $attachment->ID ),
		'src' => $attachment->guid,
		'title' => $attachment->post_title
	];
}

if (! function_exists('irecco_reorder_comment_fields')) {
	function irecco_reorder_comment_fields($fields) {
		$new_fields = [];

		$myorder = [ 'author', 'email', 'url', 'comment' ];

		foreach ($myorder as $key) {
			$new_fields[ $key ] = isset($fields[ $key ]) ? $fields[ $key ] : '';
			unset( $fields[ $key ] );
		}

		if ($fields) {
			foreach ($fields as $key => $val) {
				$new_fields[ $key ] = $val;
			}
		}

		return $new_fields;
	}
}
add_filter('comment_form_fields', 'irecco_reorder_comment_fields');

function irecco_mce_buttons_2($buttons) {
	array_unshift( $buttons, 'styleselect' );
	return $buttons;
}
add_filter( 'mce_buttons_2', 'irecco_mce_buttons_2' );


function irecco_tiny_mce_before_init( $settings) {

	$settings['theme_advanced_blockformats'] = 'p,h1,h2,h3,h4';
	$header_font_color = iRecco_Theme_Helper::get_option('header-font')['color'];
	$theme_color = iRecco_Theme_Helper::get_option('theme-primary-color');

	$style_formats = [
		[
			'title' => esc_html__('Dropcap', 'irecco'),
			'items' => [
				[
					'title' => esc_html__('Primary color', 'irecco'),
					'inline' => 'span',
					'classes' => 'dropcap-bg',
				], [
					'title' => esc_html__('Secondary color', 'irecco'),
					'inline' => 'span',
					'classes' => 'dropcap-bg secondary',
				],
			],
		],
		[
			'title' => esc_html__('Highlighter', 'irecco'),
			'items' => [
				[
					'title' => esc_html__('Primary color', 'irecco'),
					'inline' => 'span',
					'classes' => 'highlighter',
				], [
					'title' => esc_html__('Secondary color', 'irecco'),
					'inline' => 'span',
					'classes' => 'highlighter secondary',
				],
			],
		],
		[
			'title' => esc_html__('Font Weight', 'irecco'),
			'items' => [
				[
					'title' => esc_html__('Default', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => 'inherit' ],
				], [
					'title' => esc_html__('Lightest (100)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '100' ],
				], [
					'title' => esc_html__('Lighter (200)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '200' ],
				], [
					'title' => esc_html__('Light (300)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '300' ],
				], [
					'title' => esc_html__('Normal (400)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '400' ],
				], [
					'title' => esc_html__('Medium (500)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '500' ],
				], [
					'title' => esc_html__('Semi-Bold (600)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '600' ],
				], [
					'title' => esc_html__('Bold (700)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '700' ],
				], [
					'title' => esc_html__('Bolder (800)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '800' ],
				], [
					'title' => esc_html__('Extra Bold (900)', 'irecco'),
					'inline' => 'span',
					'styles' => [ 'font-weight' => '900' ],
				],
			]
		],
		[
			'title' => esc_html__('List Style', 'irecco'),
			'items' => [
				[
					'title' => esc_html__('Dot, primary color', 'irecco'),
					'selector' => 'ul',
					'classes' => 'irecco_dot',
				], [
					'title' => esc_html__('Dot, secondary color', 'irecco'),
					'selector' => 'ul',
					'classes' => 'irecco_dot secondary',
				], [
					'title' => esc_html__('Check, primary color', 'irecco'),
					'selector' => 'ul',
					'classes' => 'irecco_check',
				], [
					'title' => esc_html__('Check, secondary color', 'irecco'),
					'selector' => 'ul',
					'classes' => 'irecco_check secondary',
				], [
					'title' => esc_html__('Plus, primary color', 'irecco'),
					'selector' => 'ul',
					'classes' => 'irecco_plus',
				], [
					'title' => esc_html__('Plus, secondary color', 'irecco'),
					'selector' => 'ul',
					'classes' => 'irecco_plus secondary',
				], [
					'title' => esc_html__('Hyphen, primary color', 'irecco'),
					'selector' => 'ul',
					'classes' => 'irecco_hyphen',
				], [
					'title' => esc_html__('Hyphen, secondary color', 'irecco'),
					'selector' => 'ul',
					'classes' => 'irecco_hyphen secondary',
				], [
					'title' => esc_html__('No List Style', 'irecco'),
					'selector' => 'ul',
					'classes' => 'no-list-style',
				],
			]
		],
	];

	$settings['style_formats'] = str_replace( '"', "'", json_encode( $style_formats ) );
	$settings['extended_valid_elements'] = 'span[*],a[*],i[*]';
	return $settings;
}
add_filter( 'tiny_mce_before_init', 'irecco_tiny_mce_before_init' );

function irecco_theme_add_editor_styles() {
	add_editor_style( 'css/font-awesome.min.css' );
}
add_action( 'current_screen', 'irecco_theme_add_editor_styles' );

function irecco_categories_postcount_filter($variable)
{
	if (strpos($variable,'</a> (')) {
		$variable = str_replace('</a> (', '<span class="post_count">', $variable);
		$variable = str_replace('</a>&nbsp;(', '<span class="post_count">', $variable);
		$variable = str_replace(')', '</span></a>', $variable);
	} else {
		$variable = str_replace('</a> <span class="count">(', '<span class="post_count">', $variable);
		$variable = str_replace(')</span>', '</span></a>', $variable);
	}

	$pattern1 = '/cat-item-\d+/';
	preg_match_all( $pattern1, $variable, $matches );
	if (isset($matches[0])) {
		foreach ($matches[0] as $value) {
			$int = (int) str_replace('cat-item-', '', $value);
			$icon_image_id = get_term_meta ( $int, 'category-icon-image-id', true );
			if (! empty($icon_image_id)) {
				$icon_image = wp_get_attachment_image_src ( $icon_image_id, 'full' );
				$icon_image_alt = get_post_meta($icon_image_id, '_wp_attachment_image_alt', true);
				$replacement = '$1<img class="cats_item-image" src="'. esc_url($icon_image[0]) .'" alt="'.(! empty($icon_image_alt) ? esc_attr($icon_image_alt) : '').'"/>';
				$pattern = '/(cat-item-'.$int.'+.*?><a.*?>)/';
				$variable = preg_replace( $pattern, $replacement, $variable );
			}
		}
	}

	return $variable;
}
add_filter('wp_list_categories', 'irecco_categories_postcount_filter');

function irecco_render_archive_widgets($link_html, $url, $text, $format, $before, $after)
{
	$text = wptexturize($text);
	$url  = esc_url($url);

	if ('link' == $format) {
		$link_html = "\t<link rel='archives' title='" . esc_attr($text) . "' href='$url' />\n";
	} elseif ('option' == $format) {
		$link_html = "\t<option value='$url'>$before $text $after</option>\n";
	} elseif ('html' == $format) {

		$after = str_replace('(', '', $after);
		$after = str_replace(' ', '', $after);
		$after = str_replace('&nbsp;', '', $after);
		$after = str_replace(')', '', $after);

		$after = ! empty($after) ? " <span class='post_count'>".esc_html($after)."</span> " : "";

		$link_html = "<li>" . esc_html($before) . "<a href='" . esc_url($url) . "'>" . esc_html($text) . $after . "</a></li>";
	} else { // custom
		$link_html = "\t$before<a href='$url'>$text</a>$after\n";
	}

	return $link_html;
}
add_filter( 'get_archives_link', 'irecco_render_archive_widgets', 10, 6 );

// Add image size
if (function_exists( 'add_image_size' )) {
	add_image_size( 'irecco-840-620',  840, 620, true  );
	add_image_size( 'irecco-440-440',  440, 440, true  );
	add_image_size( 'irecco-180-180',  180, 180, true  );
	add_image_size( 'irecco-120-120',  120, 120, true  );
}

// Include Woocommerce init if plugin is active
if (class_exists( 'WooCommerce' )) {
	require_once get_theme_file_path ( '/woocommerce/woocommerce-init.php' );
}

add_filter('irecco_enqueue_shortcode_css', 'irecco_render_css');
function irecco_render_css($styles) {
	global $irecco_dynamic_css;
	if (! isset($irecco_dynamic_css['style'])) {
		$irecco_dynamic_css = [];
		$irecco_dynamic_css['style'] = $styles;
	} else {
		$irecco_dynamic_css['style'] .= $styles;
	}
}

add_filter('widget_types_to_hide_from_legacy_widget_block', function () {
    return [];
}, 10);

add_filter( 'wpcf7_autop_or_not', '__return_false');





//rajiv code here#########################################################
//#########################################################################


//woocommerce customization here

remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);

function remove_add_to_cart_button() {
    remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
}

add_action('init', 'remove_add_to_cart_button');




//###########################################################################
//Custom Side Bar Menu from here
function custom_horizontal_menu_shortcode() {
    ob_start(); ?>

    <style>
        this-body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
	

	.side-tab
		{
                //background-color:red;
                margin-top: -40px;
		}
       .side-tab ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            //background-color: #333;
        }

        .side-tab ul li {
            display: block;
            text-align: left;
            font-size: 16px;
            font-weight: bold;
        }

        .side-tab ul li a {
            display: block;
            color: #232323;
            //padding: 14px 16px;
            text-decoration: none;
        }

          .side-tab ul li a:hover {
            //background-color: #555;
        }

       .side-tab ul li.active {
            //background-color: #FFC909;
            //text-decoration:underline;
            color:rgba(254,190,15,0.4);
            
        }
        .side-tab ul li.active a {
             color: #ffc909;
         }
        
        
        
    </style>
<div class="side-tab">	
    <ul>
        <li id="2-wheeler"><a href="<?php echo home_url('/product-category/2-wheeler'); ?>">2-Wheeler</a></li>
        <li id="3-wheeler"><a href="<?php echo home_url('/product-category/3-wheeler'); ?>">3-Wheeler</a></li>
        <li id="e-cycles"><a href="<?php echo home_url('/product-category/e-cycles'); ?>">E-cycles</a></li>
    </ul>
</div>

    <script>
        // Get the current page URL
        var currentPage = window.location.href;

        // Identify the current page and add the 'active' class
        if (currentPage.includes("<?php echo home_url('/product-category/2-wheeler'); ?>")) {
            document.getElementById("2-wheeler").classList.add("active");
        } else if (currentPage.includes("<?php echo home_url('/product-category/3-wheeler'); ?>")) {
            document.getElementById("3-wheeler").classList.add("active");
        } else if (currentPage.includes("<?php echo home_url('/product-category/e-cycles'); ?>")) {
            document.getElementById("e-cycles").classList.add("active");
        } 
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('custom_horizontal_menu', 'custom_horizontal_menu_shortcode');





/**
 * Remove the review tab from WooCommerce product page
 */
function remove_product_reviews_tab( $tabs ) {
    unset( $tabs['reviews'] );
    return $tabs;
}
add_filter( 'woocommerce_product_tabs', 'remove_product_reviews_tab' );


//#################### Starting of Master Contact form #########################################
// Add the shortcode
function master_contact_form_shortcode() {
    ob_start();
    ?>
	<style>
    .hover-button1 {
      width:150px !important; 
      background-color: #FFC909 !important; 
      border: 5px solid #FFC909 !important;  
      color: #262325 !important; 
    }

    .hover-button1:hover {
      background-color: #232323 !important; 
      border: 5px solid #232323 !important;  
      color:#FFF !important; 
    } 
    </style>
    <div id="custom-contact-form">
        <form style="width: 100%;" method="post" action="">
            
            
            <input style="width: 100%;" type="text" name="name" placeholder="Enter Name" required>
			</br>
			
            <input style="width: 100%;" type="email" name="email" placeholder="Enter Email" required>
			</br>

            <input style="width: 100%;" type="tel" name="mobile" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number" required>
			</br>

            
            <select style="width: 100%;" name="state" required>
                <option value="" selected disabled>Select your state</option>
                <option value="Andhra Pradesh">Andhra Pradesh</option>
                <option value="Bihar">Bihar</option>
                <option value="Chhattisgarh">Chhattisgarh</option>
				<option value="Delhi">Delhi</option>
                <option value="Goa">Goa</option>
                <option value="Gujarat">Gujarat</option>
                <option value="Haryana">Haryana</option>
                <option value="Jharkhand">Jharkhand</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Kerala">Kerala</option>
                <option value="Maharashtra">Maharashtra</option>
                <option value="Odisha">Odisha</option>
                <option value="Punjab">Punjab</option>
                <option value="Rajasthan">Rajasthan</option>
                <option value="Tamil Nadu">Tamil Nadu</option>
                <option value="Telangana">Telangana</option>
                <option value="Uttar Pradesh">Uttar Pradesh</option>
                <option value="Uttarakhand">Uttarakhand</option>
                <option value="West Bengal">West Bengal</option>
                
            </select>
            </br>

           
            <input  style="width: 100%;" type="text" name="city" placeholder="Enter City Name" required>
            </br>
			
			<input  style="width: 100%;" type="text" name="pincode" placeholder="Enter Pin Code" required>
            </br>
			
			<input  style="width: 100%;" type="text" name="address" placeholder="Enter Address">
            </br>

           
            <select style="width: 100%;" name="query_type" required>
                <option value="" selected disabled>How do you want to partner with BLive?</option>
                <option value="EV Hub Franchise">EV Hub Franchise</option>
                <option value="Ezy Rental Franchise">Ezy Rental Franchise</option>
                <option value="Sell On BLive">Sell On BLive</option>
            </select>
            </br>

           
            <textarea style="width: 100%;" name="comment_message" rows="5" placeholder="Enter Message" required></textarea>
			</br>
            <input class="hover-button1" type="submit" name="submit" value="Submit">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

// Handle form submission and validation
function handle_master_contact_form() {
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit"])) {
        $name = sanitize_text_field($_POST["name"]);
        $email = sanitize_email($_POST["email"]);
        $mobile = sanitize_text_field($_POST["mobile"]);
        $state = sanitize_text_field($_POST["state"]);
        $city = sanitize_text_field($_POST["city"]);
		$pincode = sanitize_text_field($_POST["pincode"]);
		$address = sanitize_text_field($_POST["address"]);
        $query_type = sanitize_text_field($_POST["query_type"]);
        $comment_message = esc_textarea($_POST["comment_message"]);

            
//State code here
$es1="West Bengal";
$es2="Odisha";
$es3="Jharkhand";
$es4="Chhattisgarh";
$es5="Bihar";

$ws1="Maharashtra";
$ws2="Gujarat";
$ws3="Rajasthan";
$ws4="Goa";

$ns1="Uttar Pradesh";
$ns2="Punjab";
$ns3="Delhi";
$ns4="Haryana";
$ns5="Uttarakhand";

$ss1="Karnataka";
$ss2="Andhra Pradesh";
$ss3="Telangana";
$ss4="Kerala";
$ss5="Tamil Nadu";

$query_type3="Sell On BLive";
		
$to = '';
$headers = "From:$name <$email>";
$subject="Enquery Form From BLive.Co.In";

            
$body= "\n\nName: $name\nEmail: $email\nMobile Number: $mobile\nState: $state\nCity: $city\nPincode: $pincode\nAddress: $address\nHow do you want to partner with BLive?: $query_type\nYour Message:$comment_message";
		if($query_type == $query_type3)
			{
			$to = 'siddharth@blive.co.in';
			}
			
		else
		{
		
            switch (true) {
                case($state==$es1 || $state==$es2 || $state==$es3 || $state==$es4 || $state==$es5):
				
                    $to = 'sangeeta@blive.co.in'; 
					//$to = 'rajivcq@gmail.com';
                    break;
				case($state==$ws1 || $state==$ws2 || $state==$ws3 || $state==$ws4):
                
                    $to = 'shahzeb@blive.co.in,sangeeta@blive.co.in';
                    //$to = 'er.rajiv5587@gmail.com,rajivcq@gmail.com';
					break;
				case($state==$ns1 || $state==$ns2 || $state==$ns3 || $state==$ns4):	
				
                    //$to='rajivcq@gmail.com';
					$to = 'shahzeb@blive.co.in';
                    break;	
				case($state==$ss1 || $state==$ss2 || $state==$ss3 || $state==$ss4):	
				
				    //$to='rajivcq@yopmail.com';
                    $to = 'sravani@blive.co.in';
                    break;		
    
                default:
                    // Default email address if Sell on Blive
                    //$to = 'rajiv5587@gmail.com';
					$to = 'siddharth@blive.co.in';
            }
		}
		
            
			//$to1="rajivcq@gmail.com";
            $mail_success = wp_mail($to, $subject, $body, $headers);

            if ($mail_success) {
                // Redirect to the thank you page
                wp_redirect(home_url('/thank-you'));
                exit;
            } 
        } 
    }

// Hook the functions to WordPress actions
add_shortcode('master_contact_form', 'master_contact_form_shortcode');
add_action('init', 'handle_master_contact_form');

//#################### End of Master Contact form #########################################






//End