<?php
/**
 * Template Name: Rajiv Template
 */
get_header();
?>

        <h1>This is my custom template</h1>
        
        <?php
       
            $to = 'er.rajiv5587@gmail.com';
            $subject = 'Please provide feedback and rating to our experince';

            $body = 'Hello, Please click the link for giving valuable feedback.';

            $headers = array('Content-Type: text/html; charset=UTF-8');

            wp_mail($to, $subject, $body, $headers);	

        ?>
        

<?php
get_footer(); 
?>