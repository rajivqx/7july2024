
<!-- email_template.php -->

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verify Account</title>
        <!-- css -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    </head>

    <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
        <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
            <tbody>
                <tr>
                    <td>
                        <img style="margin-bottom: 25px; height: 37px;" src="https://thrv.app/wp-content/uploads/2022/03/logo.png" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [%Client's Name%],</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0 0 8px;">We hope you enjoyed your recent session with <strong> [%Provider's Name%]! </strong></p>
                        <p style="margin: 0 0 16px;"> Your feedback is crucial in helping us maintain the quality of our services. Please rate your experience: </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0 0 16px;"> ⭐⭐⭐⭐⭐</p>
                    </td>
                </tr>
                <tr>
                    <td style="display: flex;">
                        <a href="#" style="color: #fff; padding: 16px 44px; border-radius: 36px; background: #25394A; font-weight: 600; text-decoration: none;  margin: 0 0 30px;">Rate Your Session</a>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0 0 8px;"> Your rating helps ensure our providers are meeting the high standards our community expects. </p>
                        <p style="margin: 0 0 16px;"> Want to share more about your experience? Feel free to leave a detailed review <a href="#"> here</a> </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0;">Thank you for helping us create a better wellness community on [%Platform Name%].</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>

</html>


<?php
// functions.php or your custom plugin file

function send_custom_email($to, $subject, $recipient_name, $custom_message) {
    // Load HTML template content
    $htmlTemplate = file_get_contents(get_template_directory() . '/email_template.php');

    // Replace placeholders with dynamic data
    $htmlContent = str_replace(['%recipient_name%', '%custom_message%'], [$recipient_name, $custom_message], $htmlTemplate);

    // Set content type to HTML
    add_filter('wp_mail_content_type', function () {
        return 'text/html';
    });

    // Send the email
    $mailSent = wp_mail($to, $subject, $htmlContent);

    // Remove the content type filter
    remove_filter('wp_mail_content_type', 'wpdocs_set_html_mail_content_type');

    return $mailSent;
}
?>


<?php
// Example usage
$to = 'recipient@example.com';
$subject = 'HTML Email from WordPress';
$recipient_name = 'John Doe';
$custom_message = 'This is a custom message.';

$mailSent = send_custom_email($to, $subject, $recipient_name, $custom_message);

if ($mailSent) {
    echo "Email sent successfully!";
} else {
    echo "Error sending email.";
}
