<?php

//Page Redirection host profile
function thrv_custom_page_redirect_host() {
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    if (is_page('host-profile') && is_user_logged_in() && current_user_can('subscriber')) {
        // Redirect logged-in users with 'host' capability to '/host-profile'
        wp_redirect(home_url('/user-profile'));
        exit();
    }

    // Add some debugging statements
    error_log("Conditions not met for redirection on 'host-profile' page.");
}
add_action('template_redirect', 'thrv_custom_page_redirect_host');
//Page Redirection user profile
function thrv_custom_page_redirect_user() {
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    if (is_page('user-profile') && is_user_logged_in() && current_user_can('host')) {
		wp_redirect(home_url('/host-profile'));
        exit();
    }
	
    // Add some debugging statements
    error_log("Conditions not met for redirection on 'user-profile' page.");
}
add_action('template_redirect', 'thrv_custom_page_redirect_user');
