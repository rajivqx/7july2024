<?php


add_filter( 'login_redirect', 'custom_login_redirect', 10, 3 );


add_filter( 'jet-smart-filters/query/final-query', 'itchy_amend_map_query', 20 )




// setting the default status of experiences to pending at the time of creation
add_action( 'save_post_experiences', 'set_post_default_category', 10,3 );

 function set_post_default_category( $post_id, $post, $update ) {
	global $wpdb;
	$prefix = $wpdb->prefix;

	$post_date = $post->post_date;
	$post_modified  = $post->post_modified;
	
	if($post_date == $post_modified){
		$wpdb->update($prefix.'posts', array('post_status'=>'pending'), array('ID'=>$post_id));				
	}
 }



// adding additional column to wp_list table
add_filter('manage_edit-experiences_columns','action_link_column_addition');
function action_link_column_addition($columns){
	$columns['approve_action'] = __('Approve Action','custom-column');
	return $columns;
}




add_action('wp_logout','auto_redirect_after_logout');

function auto_redirect_after_logout(){
  wp_safe_redirect( home_url() );
  exit;
}





<?php get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <!-- Your custom template content goes here -->
        <h1>This is my custom template</h1>
    </main>
</div>

<?php get_footer(); ?>










?>




<?php

// functions.php or a custom plugin file
//[custom_shortcode text="Custom Text"]

function custom_shortcode_example($atts) {
    // Extract shortcode attributes
    $atts = shortcode_atts(
        array(
            'text' => 'Hello, World!',
        ),
        $atts,
        'custom_shortcode'
    );

    // Process and return the shortcode content
    $output = '<p>' . esc_html($atts['text']) . '</p>';

    return $output;
}
add_shortcode('custom_shortcode', 'custom_shortcode_example');



?>









<?php

/*
<form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
    <input type="hidden" name="action" value="process_feedback_form">
    <label for="name">Name:</label>
    <input type="text" name="name" required>
    <label for="email">Email:</label>
    <input type="email" name="email" required>
    <label for="message">Message:</label>
    <textarea name="message" required></textarea>
    <label for="rating">Rating:</label>
    <div class="star-rating">
        <input type="radio" name="rating" value="1"><i></i>
        <input type="radio" name="rating" value="2"><i></i>
        <input type="radio" name="rating" value="3"><i></i>
        <input type="radio" name="rating" value="4"><i></i>
        <input type="radio" name="rating" value="5"><i></i>
    </div>
    <input type="submit" value="Submit Feedback">
</form>



function process_feedback_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'process_feedback_form') {
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $message = sanitize_textarea_field($_POST['message']);
        $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;

        // Save or email the feedback data, including the rating

        // Redirect to a thank you page or the same page
        wp_redirect(home_url('/thank-you'));
        exit;
    }
}
*/




/*
if(//condition for completing services){

function send_feedback_email($name, $email, $message, $rating) {
    $to = $toEmail; //your email address
    $subject = 'Please give services feedback';

    $body = "Name: $name\n";
    $body .= "Email: $email\n";
    $body .= "Message: $message\n";
    $body .= "Rating: $rating\n";

    // Add URL to the email body
    $url = 'https://thrv.app/feedback-page'; // Replace with your actual URL
    $body .= "Feedback URL: $url\n";

    $headers = array('Content-Type: text/html; charset=UTF-8');

    // Send the email
    wp_mail($to, $subject, $body, $headers);
    
}



add_action('admin_post_nopriv_process_feedback_form', 'process_feedback_form');
add_action('admin_post_process_feedback_form', 'process_feedback_form');


	}

*/









if(//condition for completing services){



	// Custom function to send automated email
	function send_automated_email_to_user($user_id) {
	    $to = get_the_author_meta('user_email', $user_id);
	    $subject = 'Please provide valuable feedback and rating to our experince';
	    
	    // Add URL to the email body
	    $url = 'https://thrv.app/user-profile/?user_id=$userId'; // Replace with your actual URL
	    
	    // Customize the email body as needed
	    $body = 'Hello, Please click the link for giving valuable feedback.';
	    $body .= "Feedback URL: $url\n";

	    $headers = array('Content-Type: text/html; charset=UTF-8');

	    // Send the email
	    wp_mail($to, $subject, $body, $headers);
	}

	// Hook this function to an action or event
	// For example, let's hook it to a user registration event
	add_action('user_register', 'send_automated_email_to_user');

}




// Now $user_id contains the user ID from the query parameters

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;


?>










//##############################################################################################
//time 6:40 date 6/12/2023

<?php

/*
Template Name: Feedback Url
*/


$timestamp = time();

global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT user_email FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);




// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$feedback_status = $user_detail->feedback_status;
    $to = $user_detail->user_email;
    $subject = 'Please provide valuable feedback and rating to our experince';
    / Add URL to the email body
	$url = 'https://thrv.app/user-profile/?user_id=$userId'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: $url\n";


    // Additional headers if needed
    $headers = array('Content-Type: text/html; charset=UTF-8');

    // Send email
	if( $feedback_status == 0)
		{
			wp_mail($to, $subject, $body, $headers);

			//$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 where user_id = $userId"

			$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE user_id = '{$userId}'";

			$wpdb->query($sql2);
		}

	
}


//##############################################################################################
//time 7:50 date 6/12/2023

<?php

/*
Template Name: Feedback Url
*/


$timestamp = time();

global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);




// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->appointment_id;
	$feedback_status = $user_detail->feedback_status;
    $to = $user_detail->user_email;
    $subject = 'Please provide valuable feedback and rating to our experince';
    / Add URL to the email body
	$url = 'https://thrv.app/user-profile/?user_id=$userId'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: $url\n";


    // Additional headers if needed
    $headers = array('Content-Type: text/html; charset=UTF-8');

    // Send email
	if( $feedback_status != 1)
		{
			wp_mail($to, $subject, $body, $headers);

			//$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 where user_id = $userId"

			//$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE user_id = '{$userId}'";

			$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE appointment_id = '{$appointmentId}'";

			$wpdb->query($sql2);
		}

	
}





//##############################################################################################

//##############################################################################################
//time 12:00 date 8/12/2023



<?php

/*
Template Name: Feedback Url
*/


$timestamp = time();

global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);




// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->appointment_id;
	$feedback_status = $user_detail->feedback_status;
    $to = $user_detail->user_email;
    $subject = 'Please provide valuable feedback and rating to our experince';
    / Add URL to the email body
	$url = 'https://thrv.app/user-profile/?user_id=$userId'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: $url\n";


    // Additional headers if needed
    $headers = array('Content-Type: text/html; charset=UTF-8');

    // Send email
	if( $feedback_status != 1)
		{
			wp_mail($to, $subject, $body, $headers);

			//$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 where user_id = $userId"

			//$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE user_id = '{$userId}'";

			$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE appointment_id = '{$appointmentId}'";

			$wpdb->query($sql2);
		}

	
}


###############################################################################
<?php

/*
Template Name: Feedback Url
*/


$timestamp = time();

global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);




// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->appointment_id;
	$feedback_status = $user_detail->feedback_status;
    $to = $user_detail->user_email;
    $subject = 'Please provide valuable feedback and rating to our experince';
    / Add URL to the email body
	$url = 'https://thrv.app/user-profile/?user_id=$userId'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: $url\n";


    // Additional headers if needed
    $headers = array('Content-Type: text/html; charset=UTF-8');

    // Send email
	if( $feedback_status != 1)
		{
			wp_mail($to, $subject, $body, $headers);

			//$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 where user_id = $userId"

			//$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE user_id = '{$userId}'";

			$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE appointment_id = '{$appointmentId}'";

			$wpdb->query($sql2);
		}

	
}





//##############################################################################################

//##############################################################################################
//time 4:20 date 8/12/2023   tested first email



<?php

/*
Template Name: Feedback Url
*/

$timestamp = time();

global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);


// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->ID;
	$feedback_status = $user_detail->feedback_status;
    	//$to = $user_detail->user_email;
    	$to = "rajiv.jayaswal@kiwitech.com";
    	$subject = 'Please provide valuable feedback and rating to our experince';
    	// Add URL to the email body
	
	
	
	// Add URL to the email body
	$url = 'https://thrv.app/user-profile/'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: $url\n";
	
	
	
    	// Additional headers if needed
    	$headers = array('Content-Type: text/html; charset=UTF-8');
    	
    	
    	wp_mail($to, $subject, $body, $headers);
    	
    
	
}




echo"<pre>";
print_r($results);
print_r($userId);
print_r($appointmentId);
print_r($feedback_status);
print_r($to);
print_r($subject);
echo"</pre";
    	
    
?>

//##############################################################################################

<?php

// functions.php or a custom plugin file
//[custom_shortcode text="Custom Text"]

function custom_shortcode_example($atts) {
    // Extract shortcode attributes
    $atts = shortcode_atts(
        array(
            'text' => 'Hello, World!',
        ),
        $atts,
        'custom_shortcode'
    );

    // Process and return the shortcode content
    $output = '<p>' . esc_html($atts['text']) . '</p>';

    return $output;
}
add_shortcode('custom_shortcode', 'custom_shortcode_example');



// custom end point for Feedback URL

add_action( 'rest_api_init', function () {
  register_rest_route( 'myplugin/v1', '/author/(?P<id>\d+)', array(
    'methods' => 'GET',
    'callback' => 'my_awesome_func',
  ) );
} );



function my_awesome_func( $data ) {
  $posts = get_posts( array(
    'author' => $data['id'],
  ) );

  if ( empty( $posts ) ) {
    return null;
  }

  return $posts[0]->post_title;
}







?>



//##############################################################



//####################################################################################

// custom end point for Feedback URL

add_action( 'rp_my_feedback_func', 'my_feedback_func' );

function my_feedback_func() {
  
 $timestamp = time();
 //$timestamp =1701185400;


global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);


// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->ID;
	$feedback_status = $user_detail->feedback_status;
	//$to = $user_detail->user_email;
	$to = "rajiv.jayaswal@kiwitech.com";
	$subject = 'Please provide valuable feedback and rating to our experince';
	// Add URL to the email body
	
	
	
	// Add URL to the email body
	$url = 'https://thrv.app/user-profile/'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: ".$url."\n";
	
	
	
	// Additional headers if needed
	$headers = array('Content-Type: text/html; charset=UTF-8');
	
	
	wp_mail($to, $subject, $body, $headers);

	// Send email
	if( $feedback_status != 1)
	{
		wp_mail($to, $subject, $body, $headers);

		$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";

		$wpdb->query($sql2);
	}

   }
}


add_action( 'rest_api_init', 'create_custon_endpoint' );
function create_custon_endpoint(){
    register_rest_route(
        'wp/v2',
        '/send_feedback_email',
        array(
            'methods' => 'GET',
            'callback' => 'get_response',
        )
    );
}
 
function get_response() {
    // your code
    return 'This is your data!';
}












//##############################################################################
Date 11 December
//##############################################################################


//#############################################################################
// custom end point for Feedback URL

add_action( 'rp_my_feedback_func', 'my_feedback_func' );

function my_feedback_func() {
  
 $timestamp = time();
 //$timestamp =1701185400;


global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);


// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->ID;
	$feedback_status = $user_detail->feedback_status;
	//$to = $user_detail->user_email;
	$to = "neeraj.sharma@kiwitech.com";
	$subject = 'Please provide valuable feedback and rating to our experince';
	// Add URL to the email body
	
	
	
	// Add URL to the email body
	$url = 'https://thrv.app/user-profile/'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: ".$url."\n";
	
	
	
	// Additional headers if needed
	$headers = array('Content-Type: text/html; charset=UTF-8');
	
	
	//wp_mail($to, $subject, $body, $headers);

	// Send email
	if( $feedback_status != 1)
	{
		wp_mail($to, $subject, $body, $headers);

		$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";

		$wpdb->query($sql2);
		 echo "sent email";
	}

   }
}


//#############################################################################


function thrv_custom_page_redirect() {
    // Check if it's the specific page you want to redirect from
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}

add_action('template_redirect', 'thrv_custom_page_redirect');


function custom_role_redirect() {
    // Check if the user is logged in
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        
        // Check if the user has the particular role you want to redirect
        if (in_array('desired_user_role', $current_user->roles)) {
            // Redirect the user with the desired role to the home page
            wp_redirect(home_url());
            exit();
        }
    }
}

// Hook the function to the 'template_redirect' action
add_action('template_redirect', 'custom_role_redirect');



function custom_multi_role_redirect() {
    // Check if the user is logged in
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();

        // Define the two roles you want to check
        $desired_roles = array('role1', 'role2');

        // Check if the user has at least one of the desired roles
        if (array_intersect($desired_roles, $current_user->roles)) {
            // Redirect the user with the desired roles to the home page
            wp_redirect(home_url());
            exit();
        }
    }
}

// Hook the function to the 'template_redirect' action
add_action('template_redirect', 'custom_multi_role_redirect');


//###################################################################





//##################################################################
//Working code for redirection Tested successfully

//############################################################################
// Rajiv Custom Function file inclusion
//include get_template_directory() . '/custom/rj-custom-functions.php'; 
//include get_template_directory() . '/custom/custom-functions.php'; 
//require get_template_directory() . '/inc/r1-custom.php';

//First Short code

function display_related_posts($array = array()) 
    {
    return '<h3>My First simple Shortcode</h3>';
    }

add_shortcode('display_related_posts', 'display_related_posts');



function thrv_custom_page_redirect1() {
    // Check if it's the specific page you want to redirect from
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect1');

function thrv_custom_page_redirect2() {
    // Check if it's the specific page you want to redirect from
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect2');









//#################################################################################
//##################################Date 12/12/2023 ###############################
//#################################################################################


// custom end point for Feedback URL

add_action( 'rp_my_feedback_func', 'my_feedback_func' );

function my_feedback_func() {
  
 $timestamp = time();
 //$timestamp =1701185400;


global $wpdb;

$table_name = $wpdb->prefix . 'jet_appointments';

// Your SQL query
$sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;

// Fetch results
$results = $wpdb->get_results($sql);


// Loop through the users and send email to each one
foreach ($results as $user_detail) {
	$userId = $user_detail->user_id;
	$appointmentId = $user_detail->ID;
	$feedback_status = $user_detail->feedback_status;
	//$to = $user_detail->user_email;
	$to = "neeraj.sharma@kiwitech.com";
	$subject = 'Please provide valuable feedback and rating to our experince';
	// Add URL to the email body
	
	
	
	// Add URL to the email body
	$url = 'https://thrv.app/user-profile/'; // Replace with your actual URL
	
	// Customize the email body as needed
	$body = 'Hello, Please click the link for giving valuable feedback.';
	$body .= "Feedback URL: ".$url."\n";
	
	
	
	// Additional headers if needed
	$headers = array('Content-Type: text/html; charset=UTF-8');
	
	
	//wp_mail($to, $subject, $body, $headers);

	// Send email
	if( $feedback_status != 1)
	{
		wp_mail($to, $subject, $body, $headers);

		$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";

		$wpdb->query($sql2);
		 echo "sent email";
	}

   }
}


//############################################################################
// Rajiv Custom Function file inclusion
//include get_template_directory() . '/custom/rj-custom-functions.php'; 
//include get_template_directory() . '/custom/custom-functions.php'; 
//require get_template_directory() . '/inc/r1-custom.php';

//First Short code

function display_related_posts($array = array()) 
    {
    return '<h3>My First simple Shortcode</h3>';
    }

add_shortcode('display_related_posts', 'display_related_posts');



function thrv_custom_page_redirect1() {
    // Check if it's the specific page you want to redirect from
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect1');

function thrv_custom_page_redirect2() {
    // Check if it's the specific page you want to redirect from
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
}
add_action('template_redirect', 'thrv_custom_page_redirect2');




//################################################################################################


//#################################################################################
//##################################Date 13/12/2023 ###############################
//#################################################################################

<!-- email_template.php -->

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verify Account</title>
        <!-- css -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    </head>

    <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
        <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
            <tbody>
                <tr>
                    <td>
                        <img style="margin-bottom: 25px; height: 37px;" src="https://thrv.app/wp-content/uploads/2022/03/logo.png" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [Client Name],</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0 0 8px;">We hope you enjoyed your recent session with <strong> [Provider Name]! </strong></p>
                        <p style="margin: 0 0 16px;"> Your feedback is crucial in helping us maintain the quality of our services. Please rate your experience: </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0 0 16px;"> ⭐⭐⭐⭐⭐</p>
                    </td>
                </tr>
                <tr>
                    <td style="display: flex;">
                        <a href="#" style="color: #fff; padding: 16px 44px; border-radius: 36px; background: #25394A; font-weight: 600; text-decoration: none;  margin: 0 0 30px;">Rate Your Session</a>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0 0 8px;"> Your rating helps ensure our providers are meeting the high standards our community expects. </p>
                        <p style="margin: 0 0 16px;"> Want to share more about your experience? Feel free to leave a detailed review <a href="#"> here</a> </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0;">Thank you for helping us create a better wellness community on [Platform Name].</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>

</html>


//####################################################################################################
//Running Function with Dynamic Data arry
//Email Template Function for review rating

function thrv_email_template_feedback() {
            
    $timestamp = time();
    
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'jet_appointments';
    
    // Your SQL query
    $sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;
    
    // Fetch results
    $results = $wpdb->get_results($sql);
    
    
    // Loop through the users and send email to each one
    foreach ($results as $user_detail) {
        $userId = $user_detail->user_id;
        $appointmentId = $user_detail->ID;
        $feedback_status = $user_detail->feedback_status;
            //$to = $user_detail->user_email;
            $to = "rajiv.jayaswal@kiwitech.com";
            $subject = 'Please provide valuable feedback and rating to our experince';
            // Add URL to the email body
        
        
        
    $htmlTemplate='<!DOCTYPE html>
    <html lang="en">
    
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Verify Account</title>
            <!-- css -->
            <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
        </head>
    
        <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
            <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                <tbody>
                    <tr>
                        <td>
                            <img style="margin-bottom: 25px; height: 37px;" src="https://thrv.app/staging/wp-content/uploads/2022/03/logo.png" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ClientName],</p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 8px;">We hope you enjoyed your recent session with <strong> [ProviderName]! </strong></p>
                            <p style="margin: 0 0 16px;"> Your feedback is crucial in helping us maintain the quality of our services. Please rate your experience: </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 16px;"> ⭐⭐⭐⭐⭐</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="display: flex;">
                            <a href="#" style="color: #fff; padding: 16px 44px; border-radius: 36px; background: #25394A; font-weight: 600; text-decoration: none;  margin: 0 0 30px;">Rate Your Session</a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 8px;"> Your rating helps ensure our providers are meeting the high standards our community expects. </p>
                            <p style="margin: 0 0 16px;"> Want to share more about your experience? Feel free to leave a detailed review <a href="https://thrv.app/user-profile/"> here</a> </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0;">Thank you for helping us create a better wellness community on [THRV Team].</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </body>
    
    </html>';
            
        
        
        
    
    
    
    
        $user_data['client_name']="Rajiv Subscriber";
        $user_data['provider_name']="Aman Host";
        // Replace placeholders with dynamic data
            $htmlContent = str_replace(['[ClientName]', '[ProviderName]'], [$user_data['client_name'], $user_data['provider_name']], $htmlTemplate);
        
        
        wp_mail($to, $subject, $htmlContent, 'Content-type: text/html');
        
        
        
        // Send email
        /**
        if( $feedback_status != 1)
        {
            wp_mail($to, $subject, $body, $headers);
    
            //$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 where user_id = $userId"
    
            //$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE user_id = '{$userId}'";
    
            $sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";
    
            $wpdb->query($sql2);
        }
    
            */
            
        
        
    }
    }

    //#####################################################################################################################
//###################################Date 14 Dec-#################################

function thrv_custom_page_redirect1() {
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    if (is_page('host-profile') && is_user_logged_in() && current_user_can('user')) {
        // Redirect logged-in users with 'host' capability to '/host-profile'
        wp_redirect(home_url());
        exit();
    }

    // Add some debugging statements
    error_log("Conditions not met for redirection on 'host-profile' page.");
}
add_action('template_redirect', 'thrv_custom_page_redirect1');



###################################################################################################

function thrv_custom_page_redirect2() {
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    if (is_page('user-profile') && is_user_logged_in() && current_user_can('host')) {
        
        wp_redirect(home_url());
        exit();
    }

    // Add some debugging statements
    error_log("Conditions not met for redirection on 'host-profile' page.");
}
add_action('template_redirect', 'thrv_custom_page_redirect2');




//#############################################################################################################


// Rajiv Custome code starting from here............................
//Email Custom Template Function for review rating
//thrv_email_template_feedback();

function thrv_email_template_feedback() {
            
    $timestamp = time();
    
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'jet_appointments';
    
    // Your SQL query
    $sql = "SELECT * FROM ".$table_name." where slot_end <= ".$timestamp;
    
    
    
    // Fetch results
    $results = $wpdb->get_results($sql);
    
    
    // Loop through the users and send email to each one
    foreach ($results as $user_detail) {
        $userId = $user_detail->user_id;
        $appointmentId = $user_detail->ID;
        $feedback_status = $user_detail->feedback_status;
        //$to = $user_detail->user_email;
        $to = "rajiv.jayaswal@kiwitech.com,neeraj.sharma@kiwitech.com";
        $subject = 'Please provide valuable feedback and rating to our experince';
        // Add URL to the email body
        
        
        
    $htmlTemplate='<!DOCTYPE html>
    <html lang="en">
    
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Verify Account</title>
            <!-- css -->
            <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
        </head>
    
        <body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 24px; font-weight: 300; color: #333; background: #f8f8f8; margin: 0; padding: 0;">
            <table width="640" style="background: #fff; padding: 58px 62px 50px; margin: 16px auto;">
                <tbody>
                    <tr>
                        <td>
                            <img style="margin-bottom: 26px; height: 37px;" title="logo" alt="logo" src="[ThrvLogo]" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="font-weight: 600; font-size: 16px; color: #333; margin: 0 0 16px;">Dear [ClientName],</p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 8px;">We hope you enjoyed your recent session with <strong> [ProviderName]! </strong></p>
                            <p style="margin: 0 0 16px;"> Your feedback is crucial in helping us maintain the quality of our services. Please rate your experience: </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 16px;"> ⭐⭐⭐⭐⭐</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="display: flex;">
                            <a href="#" style="color: #fff; padding: 16px 44px; border-radius: 36px; background: #25394A; font-weight: 600; text-decoration: none;  margin: 0 0 30px;">Rate Your Session</a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0 0 8px;"> Your rating helps ensure our providers are meeting the high standards our community expects. </p>
                            <p style="margin: 0 0 16px;"> Want to share more about your experience? Feel free to leave a detailed review <a href="https://thrv.app/user-profile/"> here</a> </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="margin: 0;">Thank you for helping us create a better wellness community on [THRV Team].</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </body>
    
    </html>';
            
        
        

    
        $user_data['client_name']="Rajiv Subscriber";
        $user_data['provider_name']="Aman Host";
        //$thrv_logo="https://www.vhv.rs/dpng/d/15-155087_dummy-image-of-user-hd-png-download.png";
        $thrv_logo="https://thrv.app/wp-content/uploads/2022/03/logo.png";
        // Replace placeholders with dynamic data
        $htmlContent = str_replace(['[ClientName]', '[ProviderName]', '[ThrvLogo]'], [$user_data['client_name'], $user_data['provider_name'], $thrv_logo], $htmlTemplate);
        
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
        
        
        
        //wp_mail($to, $subject, $htmlContent, 'Content-type: text/html');
        wp_mail($to, $subject, $htmlContent, $headers);
        
        
        // Send email
        
        if( $feedback_status != 1)
        {
            wp_mail($to, $subject, $body, $headers);
    
            //$sql2 = "UPDATE ".$table_name." SET feedback_status = 1 where user_id = $userId"
    
            //$sql2 = "UPDATE {$table_name} SET feedback_status = 1 WHERE user_id = '{$userId}'";
    
            $sql2 = "UPDATE ".$table_name." SET feedback_status = 1 WHERE ID = '".$appointmentId."'";
    
            $wpdb->query($sql2);
        }
               
        
    }
    }
    
//thrv_email_template_feedback();
//Page Redirection
function thrv_custom_page_redirect_host() {
    if (is_page('host-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    if (is_page('host-profile') && is_user_logged_in() && current_user_can('subscriber')) {
        // Redirect logged-in users with 'host' capability to '/host-profile'
        wp_redirect(home_url('/user-profile'));
        exit();
    }

    // Add some debugging statements
    error_log("Conditions not met for redirection on 'host-profile' page.");
}
add_action('template_redirect', 'thrv_custom_page_redirect_host');


function thrv_custom_page_redirect_user() {
    if (is_page('user-profile') && !is_user_logged_in()) {
        // Redirect not logged-in users to the home page
        wp_redirect(home_url());
        exit();
    }
    if (is_page('user-profile') && is_user_logged_in() && current_user_can('host')) {
		wp_redirect(home_url('/host-profile'));
        exit();
    }
	
    // Add some debugging statements
    error_log("Conditions not met for redirection on 'user-profile' page.");
}
add_action('template_redirect', 'thrv_custom_page_redirect_user');


//########################################################################################################################
//#######################################################Date-15 Dec 2023#################################################

function customize_rejection_email($new_status, $old_status, $post) {
    if ($new_status == 'rejected' && $old_status != 'rejected') {
        $author_name = get_the_author_meta('display_name', $post->post_author);
        $to = get_the_author_meta('user_email', $post->post_author);
        $subject = 'Custom Subject for Rejected Post';
        $message = "Dear $author_name,\n\n";
        $message .= "We regret to inform you that your post titled '{$post->post_title}' has been rejected by the administrator. ";
        $message .= "Please review and make necessary corrections before resubmitting.\n\n";
        $message .= "Thank you,\nThe Administrator";

        $headers = array('Content-Type: text/html; charset=UTF-8');

        // Send the customized email
        wp_mail($to, $subject, $message, $headers);
    }
}
add_action('transition_post_status', 'customize_rejection_email', 10, 3);


//########################################################################################################################
function customize_news_approval_email($new_status, $old_status, $post) {
    if ($post->post_type === 'news' && $new_status == 'approved' && $old_status != 'approved') {
        $to = get_the_author_meta('user_email', $post->post_author);
        $subject = 'Your News has been Approved and Published';
        $message = "Dear Author,\n\n";
        $message .= "Congratulations! Your news article titled '{$post->post_title}' has been approved and published by the administrator. ";
        $message .= "You can view it here: " . get_permalink($post->ID) . "\n\n";
        $message .= "Thank you,\nThe Administrator";

        $headers = array('Content-Type: text/html; charset=UTF-8');

        // Send the customized email
        wp_mail($to, $subject, $message, $headers);
    }
}
add_action('transition_post_status', 'customize_news_approval_email', 10, 3);




