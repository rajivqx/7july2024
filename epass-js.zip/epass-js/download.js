document.addEventListener('DOMContentLoaded', function() {
    var DEFAULT_URL = "https://www.enpass.io/downloads/";
    var WINDOWS_URL = "https://www.microsoft.com/store/apps/enpass-password-manager/9nj3kmh29vgj";
    var MAC_URL = "https://apps.apple.com/app/apple-store/id732710998";
    var LINUX_URL = "https://www.enpass.io/support/kb/general/how-to-install-enpass-on-linux/";
    var IOS_URL = "https://apps.apple.com/app/apple-store/id455566716";
    var ANDROID_URL = "https://play.google.com/store/apps/details?id=io.enpass.app";

    var webPageName = getWebsitePageName();
    // console.log(webPageName);
    var OSName = getOperatingSystem();
    // console.log(OSName);

    // download button specific url query
    var downloadElement = document.querySelectorAll('[event_category="download_enpass"]');
    if(downloadElement.length > 0 && webPageName !== "pricing") {
        for(var i = 0; i < downloadElement.length; i++) {
            downloadElement[i].addEventListener('click',function(e) {
                e.preventDefault();
                if(OSName == "Linux") {
                    window.location.href = LINUX_URL; 
                } else if(OSName == "Windows PC") {
                    window.location.href = WINDOWS_URL; 
                } else if(OSName == "Mac") {
                    window.location.href = MAC_URL; 
                } else if(OSName == "iOS") {
                    window.location.href = IOS_URL; 
                } else if(OSName == "Android") {
                    window.location.href = ANDROID_URL; 
                } else {
                    // console.log("default download page");
                    window.location.href = DEFAULT_URL;
                }

            }, false);
        }
    }

    if(webPageName == "downloads") {

        function defaultSetActive() {
            setTimeout(function () {
                var hash = window.location.hash.substr(1);
    
                if (hash && hash=="desktop" || hash=="mobiles" || hash=="extensions") {
                    $('a[href*="#"]').parent().removeClass('active');
                    $('a[href="#' + hash + '"]').parent().addClass('active');
                    $('#' + hash).addClass('in active');
                } else {
                    // set default active on load
                    if(OSName == "iOS" || OSName == "Android") {
                        if(hash && hash=="desktop_store_slide" || hash=="desktop_web_slide") {
                            $('#desktop').addClass('in active');
                            $('a[href="#desktop"]').parent().addClass('active');
                        } else {
                            $('#mobiles').addClass('in active');
                            $('a[href="#mobiles"]').parent().addClass('active');
                        }                        
                    } else {
                        $('#desktop').addClass('in active');
                        $('a[href="#desktop"]').parent().addClass('active');
                    }
                }
            }, 15);
        }    
        defaultSetActive(); // On Page Load
    
        $('a[href*="#"]').click(function () { // On link click    
            var hash = window.location.hash.substr(1);
            if (hash) {
                if (window.history.replaceState) {
                    //prevents browser from storing history with each change:
                    window.history.replaceState({}, null, $(this).prop('href'));
                }
            }
        });
    
    }

}, false);
/*================================================
    desktop OS detection on client desktop machine
  ================================================
*/
function getOperatingSystem() {

    var appVersion = (navigator && navigator.appVersion || '').toLowerCase();    
    var isLinux = /linux/.test(appVersion);
    var isWindows = /win/.test(appVersion);
    var isMac = /mac/.test(appVersion);

    // mobile os detection 
    var isMobile = {
        Android: function() {
            return navigator.userAgent.match(/Android/i);
        },
        iOS: function() {
          return navigator.userAgent.match(/iPhone|iPad|iPod/i);
        }
    };
    
    if ( isMobile.Android() ) {
        return "Android";        
    } else if (isMobile.iOS()) {
        return "iOS";
    } else if(isLinux) {
        return "Linux";
    } else if(window.navigator.userAgent.indexOf("Windows NT 10.0")!= -1) {
        return "Windows PC";
    } else if(isWindows) {
        return "Windows";
    } else if(isMac) {
        return "Mac";
    } else {
        return "UNKNOWN";
    }
};

function getWebsitePageName() {
    var url = window.location.pathname;
        pageName = url.split('/');
        pageName = pageName[1];
    return pageName;
}