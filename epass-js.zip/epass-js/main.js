// website URLs
var pricing_URL = "https://www.enpass.io/pricing";
var download_URL = "https://www.enpass.io/downloads";
var import_URL = "https://www.enpass.io/docs/manual-desktop/import_export.html";
// magnificPopup enpass home video
document.addEventListener("DOMContentLoaded", function() {
    var playVideoButton = document.querySelectorAll(".popup-youtube");
    if(playVideoButton.length > 0) {
        $('#play_video, .popup-youtube').magnificPopup({
            type: 'iframe',  
            iframe: {
                markup: '<div class="mfp-iframe-scaler">'+
                        '<div class="mfp-close"></div>'+
                        '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>'+
                      '</div>',  
                patterns: {
                    youtube: {
                        index: '//www.youtube.com',
                        id: 'v=',
                        src: '//www.youtube.com/embed/%id%?enablejsapi=1&origin=https://www.enpass.io?controls=2;autoplay=1;rel=0&fs=0&showinfo=0'
                    }
                },
                srcAction: 'iframe_src'
            }
        });
    }
    
});

// form validations
document.addEventListener("DOMContentLoaded", function() {  

    // Add or remove label from input box in form
    $('input,textarea,select').blur(function() {
        var $this = $(this);
        if ($this.val()) {
            $this.addClass('used');
        } else {
            $this.removeClass('used');
        }
    });

    // pricing promo    
    const promoInput = document.querySelector('#promodCode');
    if(promoInput) {
        $('#applyPromoCode').attr('disabled',true);
        $('#promodCode').bind("change keyup input",function(){
            if($(this).val().trim().length >=6){
                $('#applyPromoCode').attr('disabled', false);
            } else {
                $('#applyPromoCode').attr('disabled', true);        
            }
        })
    }    
    
    // submit newsletter form
    var submit_news_btn = document.querySelector("#submitSubscription");
    if(submit_news_btn) {

        $("#subsciption_form").on("submit",function(e) {
            e.preventDefault();

            var subscriptionInfo = { email : '' };
            updateSubscriptionInfo(subscriptionInfo);

            var validationStatus = validateSubscriptionFields();
            if(validationStatus) {

                var sendData = $( this ).serialize();
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/subscribe.php",
                    data: sendData,
                    success: function(data){
                        $(".response_msg").text(data);                                    
                        $("#subsciption_form").find("input[type=email]").val("");
                    }
                });
            }
        });
    }

    // submit app subscription form
    var newsletter_subscribe = document.querySelector("#subscribe_newsletter");
    if(newsletter_subscribe) {
    
        $("#newsletterForm").on("submit",function(e) {
            e.preventDefault();
            var subscriberInfo = { email : '' };
            updateSubscriberInfo(subscriberInfo);
    
            var validationStatus = validateSubscribeInfoFields();
            if(validationStatus) {
        
                var sendData = $( this ).serialize();
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/appsubscribe.php",
                    data: sendData,
                    success: function(data){
                        $(".subscribe_message").text(data);                                    
                        $("#newsletterForm").find("input[type=email]").val("");
                    }
                });
            }
        });
    }

    //submit beta subscription form
    var submit_beta_btn = document.querySelector("#submit_beta_form");
    if(submit_beta_btn) {
        $("#beta_subsc_form").on("submit",function(e) {
            e.preventDefault();
            var betaInfo = { first_name:'',last_name:'',beta_email:'',beta_platform:'',spam_value:'' };
            updateBetaInfo(betaInfo);
        });
    }

    // submit contact us form
    var submit_contact_btn = document.querySelector("#submit_contact_form");
    if(submit_contact_btn) {

        var textArea = document.querySelector('#textArea');
        var textCopy = document.querySelector('#textCopy');
            textArea.addEventListener('change', autosize, false);
            textArea.addEventListener('keydown', autosize, false);
            textArea.addEventListener('keyup', autosize, false);
            autosize();
                    
            function autosize() {
                textCopy.innerHTML = textArea.value.replace(/\n/g, '<br/>') + '&nbsp;';
            }

        $("#contact_us_form").on("submit",function(e) {
            e.preventDefault();
            var contactInfo = { user_name:'',user_email:'',user_subject:'',user_platform:'',user_country:'',enpass_version:'',os_version:'',user_message:'' };
            updateContactInfo(contactInfo);
            var validationStatus = validateContactFields();
            if(validationStatus) {
                var serialized = JSON.stringify(contactInfo);
                var sendData = JSON.parse(serialized);
                // var sendData = $( this ).serialize();
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/contact_response.php",
                    data: sendData,
                    success: function(data){
                        $(".contact_response").text(data);
                        $("#contact_us_form").find("input[type=text], input[type=email], textarea").val("").removeClass("used");
                    }
                });
            }
        });

    }

    // submit student form
    var submit_student_form = document.querySelector("#submit_student_form");
    if(submit_student_form) {

        var textArea = document.querySelector('#textArea');
        var textCopy = document.querySelector('#textCopy');
            textArea.addEventListener('change', autosize, false);
            textArea.addEventListener('keydown', autosize, false);
            textArea.addEventListener('keyup', autosize, false);
            autosize();
                        
        function autosize() {
            textCopy.innerHTML = textArea.value.replace(/\n/g, '<br/>') + '&nbsp;';
        }
    
        $("#student_education_form").on("submit",function(e) {
            e.preventDefault();
            var studentInfo = { user_name:'',user_email:'',user_org:'',user_country:'',user_message:'' };
            updateStudentInfo(studentInfo);
            var validationStatus = validateStudentFields();
            if(validationStatus) {
                var serialized = JSON.stringify(studentInfo);
                var sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/student_response.php",
                    data: sendData,
                    success: function(data){
                        $(".student_education_form_response").text(data);
                        $("#student_education_form").find("input[type=text], input[type=email], textarea").val("").removeClass("used");
                    }
                });
            }
        });
    }

    // submit teams form
    var submit_teams_form = document.querySelector("#submit_teams_form");
    var submit_starter_form = document.querySelector("#submit_starter_form");
    if(submit_teams_form || submit_starter_form) {

        const cloudOptions = document.getElementById('cloud_services');
        cloudOptions.addEventListener('change', (event) => {
            const cloudOptions = event.target.value;

            if(cloudOptions == "microsoft_365_business_cloud" || cloudOptions == "google_workspace" || cloudOptions == "-1") {
                document.getElementById("vault_access_note").style.display = "none";
                document.querySelectorAll('.feature_onedrive').forEach(function(el) {
                    el.style.display = 'list-item';
                });
            } else {
                document.getElementById("vault_access_note").style.display = "block";
                document.querySelectorAll('.feature_onedrive').forEach(function(el) {
                    el.style.display = 'none';
                });
            }
        });

        $("#enpass_teams_form").on("submit",function(e) {
            e.preventDefault();
            var teamsInfo = {};
            updateTeamsInfo(teamsInfo);
            var validationStatus = validateTeamsFormFields();
            if(validationStatus) {
                var serialized = JSON.stringify(teamsInfo);
                var sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/teams_response.php",
                    data: sendData,
                    // Handle success here
                    success: function(data){
                        var response_data = JSON.parse(data);
                        if(response_data) {
                            if(response_data.error == false) {
                                window.location.href = response_data.secret;
                            } else {
                                if(response_data.code == "already_exists") {
                                    $("#teams_form_error").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "missing_parameters") {
                                    $("#teams_form_error").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "unknown_error") {
                                    $("#teams_form_error").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "invalid_email") {
                                    $("#teams_form_error").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "non_business_domain") {
                                    $("#teams_form_error").text(response_data.description).css("display", "block");
                                }
                            }
                        }
                    },
                    cache: false
                }).fail(function (jqXHR, textStatus, error) {
                    $('#teams_form_error').text("Something went wrong. Please try again.").css("display", "block");
                });
            }
        });

        $("#enpass_starter_form").on("submit",function(e) {
            e.preventDefault();
            var starterInfo = {};
            updateStarterInfo(starterInfo);
            var validationStatus = validateStarterFormFields();
            if(validationStatus) {
                var serialized = JSON.stringify(starterInfo);
                var sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/starter_response.php",
                    data: sendData,
                    // Handle success here
                    success: function(data){
                        var response_data = JSON.parse(data);
                        if(response_data) {
                            if(response_data.error == false) {
                                window.location.href = response_data.secret;
                            } else {
                                if(response_data.code == "already_exists") {
                                    $("#starter_form_error").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "missing_parameters") {
                                    $("#starter_form_error").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "unknown_error") {
                                    $("#starter_form_error").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "invalid_email") {
                                    $("#starter_form_error").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "non_business_domain") {
                                    $("#starter_form_error").text(response_data.description).css("display", "block");
                                }
                            }
                        }
                    },
                    cache: false
                }).fail(function (jqXHR, textStatus, error) {
                    $('#starter_form_error').text("Something went wrong. Please try again.").css("display", "block");
                });
            }
        });
    }

    // Business users family plan
    let submit_family_form = document.querySelector("#submit_bfp_form");
    if(submit_family_form) {
        $("#enpass_bfp_form").on("submit",function(e) {
            e.preventDefault();
            let familyUserInfo = {};
            let responseStatus = document.querySelector("#bfp_response_status");
                responseStatus.textContent = "";
                responseStatus.style.display = "none";
            
            let DEFAULT_URL = window.location.href;
            let pathParameter = getUrlParams(DEFAULT_URL);
            if(pathParameter.redeem_code) {
                familyUserInfo.uuid = pathParameter.redeem_code;
            }

            updateFamilyUserInfo(familyUserInfo);

            const businessEmail = familyUserInfo.business_email;
            const clientDomain = getClientDomain(businessEmail);

            let validationStatus = validateFamilyUserFormFields();
            if(validationStatus) {
                let serialized = JSON.stringify(familyUserInfo);
                let sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/family_response.php",
                    data: sendData,
                    // Handle success here
                    success: function(data,status,xhr){
                        if(xhr.status == 200) {
                            let response_data = JSON.parse(data);
                            if(response_data) {
                                if(response_data.error == false) {
                                    document.querySelector("#bfp_content_wrapper").style.display = "none";
                                    document.querySelector("#bfp_otp_container").style.display = "flex";
                                    document.querySelector("#bfp_content").scrollIntoView({behavior: "smooth"});
    
                                    let backButton = document.querySelector("#backToPrimaryform");
                                    let otpInput = document.getElementById('otp');
                                    let verifyButton = document.getElementById('submit_otp');
                                    let resendButton =document.getElementById('resend_otp');

                                    if(backButton) {
                                        backButton.addEventListener('click',function(e){
                                            document.querySelector("#bfp_otp_container").style.display = "none";
                                            document.querySelector("#bfp_content_wrapper").style.display = "flex";
                                            document.querySelector("#bfp_content_wrapper").scrollIntoView({behavior: "smooth"});
                                            otpInput.value = "";

                                            let verifyResponseStatus = document.querySelector("#bvfp_response_status");
                                            verifyResponseStatus.textContent = "";
                                            verifyResponseStatus.style.display = "none";
                                        });
                                    }

                                    // Enable or disable the verify button based on the input value
                                    otpInput.addEventListener('input', function() {
                                        let otpInputValue = otpInput.value.trim();
                                        verifyButton.disabled = (otpInputValue.length < 6);
                                    });

                                    // resend otp query
                                    resendButton.addEventListener('click', function(event) {
                                        e.preventDefault();
                                        let verifyResponseStatus = document.querySelector("#bvfp_response_status");
                                            verifyResponseStatus.textContent = "";
                                            verifyResponseStatus.style.display = "none";

                                        $.ajax({
                                            type: "POST",
                                            url: "/wp-content/themes/enpass/family_response.php",
                                            data: sendData,
                                            // Handle success here
                                            success: function(data,status,xhr){
                                                if(xhr.status == 200) {
                                                    let response_data = JSON.parse(data);
                                                    if(response_data.error == true){
                                                        $("#bvfp_response_status").text(response_data.description).css("display", "block");
                                                    }
                                                }
                                            },
                                        cache: false
                                        }).fail(function (jqXHR, textStatus, error) {
                                            $('#bvfp_response_status').text("Something went wrong. Please try again.").css("display", "block");
                                        });

                                    });

                                    // submit otp verification
                                    verifyButton.addEventListener('click', function(event) {
                                        event.preventDefault();
                                        let verifyUserInfo = {};
                                            verifyUserInfo.business_email = familyUserInfo.business_email;
                                            verifyUserInfo.otp = otpInput.value.trim();
                                            verifyUserInfo.uuid = familyUserInfo.uuid;

                                        let verifyResponseStatus = document.querySelector("#bvfp_response_status");
                                            verifyResponseStatus.textContent = "";
                                            verifyResponseStatus.style.display = "none";

                                        let serializedVerification = JSON.stringify(verifyUserInfo);
                                        let sendVerificationData = JSON.parse(serializedVerification);

                                        $.ajax({
                                            type: "POST",
                                            url: "/wp-content/themes/enpass/family_verify.php",
                                            data: sendVerificationData,
                                            // Handle success here
                                            success: function(data,status,xhr) {
                                                if(xhr.status == 200) {
                                                    let response_data = JSON.parse(data);
                                                    if(response_data){
                                                        if(response_data.error == false){
                                                            window.location.href = window.location.origin + "/complimentary-family-success/";
                                                        } else {
                                                            if(response_data.code == "missing_parameters"){
                                                                $("#bvfp_response_status").text("Please fill all fields and checkboxes.").css("display", "block");
                                                            }
                                                            if(response_data.code == "invalid_business_email"){
                                                                $("#bvfp_response_status").text(`No such email was found at ${clientDomain}.`).css("display", "block");
                                                            }
                                                            if(response_data.code == "already_redeemed"){
                                                                $("#bvfp_response_status").text("There is already an Enpass Family Plan associated with this email address.").css("display", "block");
                                                            }
                                                            if(response_data.code == "invalid_link"){
                                                                $("#bvfp_response_status").text("Link is invalid.").css("display", "block");
                                                            }
                                                            if(response_data.code == "user_not_found"){
                                                                $("#bvfp_response_status").text(`Unable to find this email found at ${clientDomain}.`).css("display", "block");
                                                            }
                                                            if(response_data.code == "otp_invalid"){
                                                                $("#bvfp_response_status").text("This one-time password is invalid or expired.").css("display", "block");
                                                            }
                                                            if(response_data.code == "request_not_found"){
                                                                $("#bvfp_response_status").html(`Please start at <a href="${DEFAULT_URL}">${DEFAULT_URL}</a>.`).css("display", "block");
                                                            }
                                                            if(response_data.code == "unknown_error"){
                                                                $("#bvfp_response_status").html('Unknown error occurred. Contact <a href="mailto:support@enpass.io" target="_blank">support@enpass.io</a> for help.').css("display", "block");
                                                            }
                                                            if(response_data.code == "query_blocked"){
                                                                $("#bvfp_response_status").html('There have been too many attempts to redeem this Family Plan. Contact <a href="mailto:support@enpass.io" target="_blank">support@enpass.io</a> for help.').css("display", "block");
                                                            }
                                                        }
                                                    }
                                                }
                                            },
                                            cache: false
                                        }).fail(function (jqXHR, textStatus, error) {
                                            $('#bvfp_response_status').text("Something went wrong. Please try again.").css("display", "block");
                                        });
                                    });

                                } else {
                                    if(response_data.code == "missing_parameters") {
                                        $("#bfp_response_status").text("Please fill all fields and checkboxes.").css("display", "block");
                                    }
                                    if(response_data.code == "invalid_business_email") {
                                        $("#bfp_response_status").text("Please provide a valid email address.").css("display", "block");
                                    }
                                    if(response_data.code == "invalid_personal_email") {
                                        $("#bfp_response_status").text("Please provide a valid email address.").css("display", "block");
                                    }
                                    if(response_data.code == "matching_emails") {
                                        $("#bfp_response_status").text("Please provide a personal email rather than a work email.").css("display", "block");
                                    }
                                    if(response_data.code == "invalid_link") {
                                        $("#bfp_response_status").text("There is already an Enpass Family Plan associated with this email address.").css("display", "block");
                                    }
                                    if(response_data.code == "already_redeemed") {
                                        $("#bfp_response_status").text("This user's complimentary Family Plan has already been redeemed.").css("display", "block");
                                    }
                                    if(response_data.code == "user_not_found") {
                                        $("#bfp_response_status").text("Invalid Business email.").css("display", "block");
                                    }
                                    if(response_data.code == "invalid_request") {
                                        $("#bfp_response_status").text("Unable to process this request, possibly because the information provided doesn't match the user who received the invitation.").css("display", "block");
                                    }
                                    if(response_data.code == "family_already_exists") {
                                        $("#bfp_response_status").text("There is already an Enpass Family Plan associated with this email address.").css("display", "block");
                                    }
                                    if(response_data.code == "org_expired") {
                                        $("#bfp_response_status").text("This organization's Enpass Business plan is no longer active.").css("display", "block");
                                    }
                                    if(response_data.code == "org_benefit_revoked") {
                                        $("#bfp_response_status").text("Organization has revoked family benefits.").css("display", "block");
                                    }
                                    if(response_data.code == "teamuser_not_found") {
                                        $("#bfp_response_status").text(`This user appears to no longer be active at ${clientDomain}.`).css("display", "block");
                                    }
                                    if(response_data.code == "subscription_not_found") {
                                        $("#bfp_response_status").text(`This user appears to no longer be active at ${clientDomain}.`).css("display", "block");
                                    }
                                    if(response_data.code == "inactive_team_user") {
                                        $("#bfp_response_status").text(`This email is not associated with an active license from ${clientDomain}.`).css("display", "block");
                                    }
                                    if(response_data.code == "unknown_error") {
                                        $("#bfp_response_status").html('Unknown error occurred. Contact <a href="mailto:support@enpass.io" target="_blank">support@enpass.io</a> for help.').css("display", "block");
                                    }
                                    if(response_data.code == "query_blocked") {
                                        $("#bfp_response_status").html('There have been too many attempts to redeem this Family Plan. Contact <a href="mailto:support@enpass.io" target="_blank">support@enpass.io</a> for help.').css("display", "block");
                                    }
                                }
                            }
                        }
                    },
                    cache: false
                }).fail(function (jqXHR, textStatus, error) {
                    $('#bfp_response_status').text("Something went wrong. Please try again.").css("display", "block");
                });

            }
        });
    }

    // submit enterprise form
    var submit_enterprise_form = document.querySelector("#submit_enterprise_form");
    if(submit_enterprise_form) {
        
        $("#company_size").change(function () {
            if($('#company_size option:selected').val() == "-1") $(this).css("color", "gray");
            else $(this).css("color","#333");
        });
        $("#company_size").change();

        $("#country").change(function () {
            if($('#country option:selected').val() == "-1") $(this).css("color", "gray");
            else $(this).css("color","#333");
        });
        $("#country").change();

        $("#cloud_services").change(function () {
            if($('#cloud_services option:selected').val() == "-1") {
                $(this).css("color", "gray");
            } else {
                $(this).css("color","#333");
            }
            var cloudOptions = document.getElementById('cloud_services').value;
            if(cloudOptions == "microsoft_365_business_cloud" || cloudOptions == "google_workspace" || cloudOptions == "-1") {
                document.getElementById("vault_access_note").style.display = "none";
            } else {
                document.getElementById("vault_access_note").style.display = "block";
            }
        });
        $("#cloud_services").change();        
        
        $("#enpass_enterprise_form").on("submit",function(e) {
            e.preventDefault();
            var enterpriseInfo = {};
            updateEnterpriseInfo(enterpriseInfo);
            var validationStatus = validateEnterpriseFormFields();
            if(validationStatus) {
                var serialized = JSON.stringify(enterpriseInfo);
                var sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/enterprise_response.php",
                    data: sendData,
                    // Handle success here
                    success: function(data){
                        var response_data = JSON.parse(data);
                        if(response_data) {
                            if(response_data.error == false) {
                                $("#enterprise_page_wrapper").css("display","none");
                                $("#enterprise_submitted_successfully").css("display","flex");
                                window.scrollTo({top: 0, behavior: 'smooth'});
                            } else {
                                if(response_data.code == "already_exists") {
                                    $("#enterprise_response_status").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "missing_parameters") {
                                    $("#enterprise_response_status").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "unknown_error") {
                                    $("#enterprise_response_status").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "non_business_domain") {
                                    $("#enterprise_response_status").text(response_data.description).css("display", "block");
                                }
                            }
                            $("#enpass_enterprise_form").find("input[type=text],input[type=tel],input[type=email],textarea").val("").removeClass("used");
                            $("#enpass_enterprise_form select").val("-1").change();
                            $('#agree_terms_and_condition').prop('checked', false);
                        }
                    },
                    cache: false
                }).fail(function (jqXHR, textStatus, error) {
                    // handle error here
                    $('#enterprise_response_status').text("Something went wrong. Please try again.").css("display", "block");
                });
            }
        });
    }

    // submit entdel form
    var submit_entdel_form = document.querySelector("#submit_entdel_form");
    if(submit_entdel_form) {

        $("#country").change(function () {
            if($('#country option:selected').val() == "-1") $(this).css("color", "gray");
            else $(this).css("color","#333");
        });
        $("#country").change();       
        
        $("#enpass_entdel_form").on("submit",function(e) {
            e.preventDefault();
            var entdelInfo = {};
            updateEntdelInfo(entdelInfo);
            var validationStatus = validateEntdelFormFields();
            if(validationStatus) {
                var serialized = JSON.stringify(entdelInfo);
                var sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/entdel_response.php",
                    data: sendData,
                    // Handle success here
                    success: function(data){
                        var response_data = JSON.parse(data);
                        if(response_data) {
                            if(response_data.error == false) {
                                $("#entdel_page_wrapper").css("display","none");
                                $("#entdel_submitted_successfully").css("display","flex");
                                window.scrollTo({top: 0, behavior: 'smooth'});
                            } else {
                                if(response_data.code == "missing_parameters") {
                                    $("#entdel_response_status").text(response_data.description).css("display", "block");
                                }
                            }
                            $("#enpass_entdel_form").find("input[type=text],input[type=tel],input[type=email]").val("").removeClass("used");
                            $("#enpass_entdel_form select").val("-1").change();
                            $('#agree_terms_and_condition').prop('checked', false);
                        }
                    },
                    cache: false
                }).fail(function (jqXHR, textStatus, error) {
                    // handle error here
                    $('#enterprise_response_status').text("Something went wrong. Please try again.").css("display", "block");
                });
            }
        });
    }

    // submit reseller program
    var submit_reseller_form = document.querySelector("#enpass_reseller_form");
    if(submit_reseller_form) {

        $("#country").change(function () {
            if($('#country option:selected').val() == "-1") $(this).css("color", "gray");
            else $(this).css("color","#333");
        });
        $("#country").change();

        $("#enpass_reseller_form").on("submit",function(e) {
            e.preventDefault();
            var resellerInfo = {};
            updateResellerInfo(resellerInfo);
            var validationStatus = validateResellerFormFields();
            if(validationStatus) {
                var serialized = JSON.stringify(resellerInfo);
                var sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/reseller_onboarding.php",
                    data: sendData,
                    // Handle success here
                    success: function(data){
                        var response_data = JSON.parse(data);
                        if(response_data) {
                            if(response_data.error == false) {
                                $("#enpass_reseller_form").css("display","none");
                                $("#header_description").css("display","none");
                                $("#reseller_submitted_successfully").css("display","block");
                                    document.querySelector("#reseller_formPannel").scrollIntoView({behavior: "smooth"});
                            } else {
                                if(response_data.code == "already_exists") {
                                    $("#reseller_response_status").text("Partner already exists").css("display", "block");
                                }
                                if(response_data.code == "missing_parameters") {
                                    $("#reseller_response_status").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "invalid_email") {
                                    $("reseller_response_status").text(response_data.description).css("display", "block");
                                }
                                if(response_data.code == "invalid_parameters") {
                                    $("#reseller_response_status").text(response_data.description).css("display", "block");
                                }
                            }
                            $("#enpass_reseller_form").find("input[type=text],input[type=tel],input[type=email],textarea").val("").removeClass("used");
                            $("#enpass_reseller_form select").val("-1").change();
                            $('#agree_terms_and_condition').prop('checked', false);
                        }
                    },
                    cache: false
                }).fail(function (jqXHR, textStatus, error) {
                    // handle error here
                    $('#reseller_response_status').text("Something went wrong. Please try again.").css("display", "block");
                });
            }
        });
    }

    // submit affiliate form
    var submit_affiliate_btn = document.querySelector("#submit_affiliate_form");
    if(submit_affiliate_btn) {

        var textArea = document.querySelector('#textArea');
        var textCopy = document.querySelector('#textCopy');
            textArea.addEventListener('change', autosize, false);
            textArea.addEventListener('keydown', autosize, false);
            textArea.addEventListener('keyup', autosize, false);
            autosize();
                    
            function autosize() {
                textCopy.innerHTML = textArea.value.replace(/\n/g, '<br/>') + '&nbsp;';
            }

        $("#join_affiliate_form").on("submit",function(e) {
            e.preventDefault();
            var affiliateInfo = { user_name:'',user_email:'',user_org:'',user_message:'' };
            updateAffiliateInfo(affiliateInfo);
            var validationStatus = validateAffiliateFields();
            if(validationStatus) {
                var serialized = JSON.stringify(affiliateInfo);
                var sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/affiliate_response.php",
                    data: sendData,
                    success: function(data){
                        $(".affiliate_response").text(data);
                        $("#join_affiliate_form").find("input[type=text], input[type=email], textarea").val("").removeClass("used");
                    }
                });
            }
        });

    }

    // submit pressroom form
    var submit_press_btn = document.querySelector("#submit_pressroom_form");
    if(submit_press_btn) {
        
        $("#pressroom_form").on("submit",function(e) {
            e.preventDefault();
            var pressroomInfo = { user_name:'',press_name:'',website:'',user_email:'',spam_value:'' };
            updatePressroomInfo(pressroomInfo);
            var validationStatus = validatePressroomFields();
            if(validationStatus) {
                var serialized = JSON.stringify(pressroomInfo);
                var sendData = JSON.parse(serialized);
                // var sendData = $( this ).serialize();
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/press_subscribe.php",
                    data: sendData,
                    success: function(data){
                        $(".press_response").text(data);
                        $("#pressroom_form").find("input[type=text], input[type=email]").val("").removeClass("used");
                    }
                });
            }
        });
    }

    // submit breachsearch form
    var breachSearchForm = document.querySelector("#breachsearchform");
    if(breachSearchForm) {

        $( "#breachsearchform" ).submit(function( event ) {		
            $('#breach_result').hide();
            $("#monitoring_response").hide();
            event.preventDefault();
            var domain = $("#domain").val().trim();
            if(domain){		
                var domainRegex = /(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]/gi;
                if(!domainRegex.test(domain)){
                    $('#breach_result').text('Please enter a valid domain.').css('color','red').show()
                    return;
                }
                console.log(domain,JSON.stringify({domain:domain}));
                var breachApiURL = "/wp-content/themes/enpass/breach_monitoring.php";
                $.post(breachApiURL,{"domain": domain}, function( data ) {	
                    if(data){
                        var data = JSON.parse(data); 
                        if(data.uuid) {
                            window.location.href = "https://www.enpass.io/breach/report/?uuid="+data.uuid;
                        } else {
                            //no breach found
                            if(data.code == "not_found") {
                                $("#monitor_logo").attr("src",data.logo);
                                $('#monitor_url').text(domain);
                                $('#monitor_web_desc').text('No password breaches for '+domain+' have been found.');
                                $('#monitoring_response').show();
                            }
                            if(data.code == "domain_not_found") {
                                $("#monitor_logo").attr("src","/wp-content/uploads/2020/12/default_breach_icon.png");
                                $('#monitor_url').text(domain);
                                $('#monitor_web_desc').text('No password breaches for '+domain+' have been found.');
                                $('#monitoring_response').show();
                            }
                            if(data.code == "missing_parameters") {
                                $('#breach_result').text('Some error occurred while fetching report.').css('color','red').show()
                            }
                        }
                    } else{
                        //some error in fetching report
                        $('#breach_result').text('Some error occurred while fetching report.').css('color','red').show()
                    }
                            
                }).fail(function(response) {
                    //some error in fetching report	
                    $('#breach_result').text('Some error occurred while fetching report.').css('color','red').show()
                });
                        
                                            
            } else {
                //show error code
                $('#breach_result').text('Please enter domain.').css('color','red').show()
            }		
        });
    }
    
    // check input name value is valid or not
    function isValidName(name) {
        var pattern = new RegExp (/^[a-zA-Z ]*$/i);
        if(name) {
            return pattern.test(name);
        }
        return false;
    };
    
    // Check input email address value is valid or not
    function isValidEmailAddress(emailAddress) {
        var pattern = new RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
        // var pattern = new RegExp(/^(("[\w-+\s]+")|([\w-+]+(?:\.[\w-+]+)*)|("[\w-+\s]+")([\w-+]+(?:\.[\w-+]+)*))(@((?:[\w-+]+\.)*\w[\w-+]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][\d]\.|1[\d]{2}\.|[\d]{1,2}\.))((25[0-5]|2[0-4][\d]|1[\d]{2}|[\d]{1,2})\.){2}(25[0-5]|2[0-4][\d]|1[\d]{2}|[\d]{1,2})\]?$)/i);
        if(emailAddress) {
            return pattern.test(emailAddress);
        }
        return false;
    };
    
    // check the url address is valid or not
    function isValidUrl(websiteURL) {
        var pattern = new RegExp(/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i);
        if(websiteURL) {
            return pattern.test(websiteURL);
        }
        return false;
    };

    /*function to get client domain
        email: default email
    */
    function getClientDomain(email) {
        const atIndex = email.indexOf('@');
        if (atIndex !== -1) {
            const domain = email.substring(atIndex + 1);
            return domain;
        }
        return null;
    }

    function updateSubscriptionInfo(subscriptionInfo) {
        var subsc_email = $('#subscription_mail').val();
        if(subsc_email) {
            subscriptionInfo.email = subsc_email;
        }
    }
   
    function validateSubscriptionFields() {
        var email = $('#subscription_mail').val();
            validationStatus = true;
        
        if(!email || !isValidEmailAddress(email)) {
            validationStatus = false;
        }
        return validationStatus;
    }

    function updateSubscriberInfo(subscriberInfo) {
        var subsc_email = $('#subscribeEmail').val();
        if(subsc_email) {
            subscriberInfo.email = subsc_email;
        }
    }

    function getBetaSelectedPlatform(betaInfo,validationStatus) {
        betaInfo.beta_platform = '';
        var selected_platform = $("#beta_subc_field_4 option:selected");
        if(!selected_platform || selected_platform.length === 0) {
            validationStatus = false;
            return;
        }

            for(var i = 0,length = selected_platform.length;i < length;i++) {
                var beta_platform = selected_platform[i].value;

                if(beta_platform == "mac") {
                    betaInfo.beta_platform = beta_platform;
                }
                if(beta_platform == "Traditional win32") {
                    betaInfo.beta_platform = beta_platform;
                }
                if(beta_platform == "Linux") {
                    betaInfo.beta_platform = beta_platform;
                }
                if(beta_platform == "Windows 10-Desktop") {
                    betaInfo.beta_platform = beta_platform;
                }
                if(beta_platform == "iOS") {
                    betaInfo.beta_platform = beta_platform;
                }
                if(beta_platform == "Android") {
                    betaInfo.beta_platform = beta_platform;
                }
                if(beta_platform == "Windows UWP") {
                    betaInfo.beta_platform = beta_platform;
                }
                if(beta_platform == "Portable USB") {
                    betaInfo.beta_platform = beta_platform;
                }

                if(validationStatus) {
                    var serialized = JSON.stringify(betaInfo);
                    var sendData = JSON.parse(serialized);
                    $.ajax({
                        type: "POST",
                        url: "/wp-content/themes/enpass/beta_subscribe.php",
                        data: sendData,
                        success: function(data){
                            $(".beta_response").text(data);
                            $("#beta_subsc_form").find("input[type=text], input[type=email]").val("").removeClass("used");
                        }
                    });
                }
            }   
    }

    function validateSubscribeInfoFields() {
        var email = $('#subscribeEmail').val();
            validationStatus = true;
        
        if(!email || !isValidEmailAddress(email)) {
            validationStatus = false;
        }
        return validationStatus;
    }

    function updateBetaInfo(betaInfo) {
        var first_name = $('#beta_subc_field_1').val().trim();
        var last_name = $('#beta_subc_field_2').val().trim();
        var beta_email = $('#beta_subc_field_3').val();
        var spam_value = $('#beta_subc_value').val();
        var validationStatus = true;

        if(first_name) {
            betaInfo.first_name = first_name;
        }
        if(last_name) {
            betaInfo.last_name = last_name;
        }    
        if(beta_email) {
            betaInfo.beta_email = beta_email;
        }
        if(spam_value) {
            betaInfo.spam_value = spam_value;
        }

        var validationStatus = validateBetaFormFields(betaInfo,validationStatus);
        var beta_platform = getBetaSelectedPlatform(betaInfo,validationStatus);
    }

    function updateContactInfo(contactInfo) {
        var contact_name = $('#contact_field_1').val();
        var contact_email = $('#contact_field_2').val();
        var contact_subject = $('#contact_field_3').val();
        var contact_platform = $("#contact_field_4 option:selected").text();
        var enpass_version = $('#contact_field_5').val();
        var os_version = $('#contact_field_6').val();
        var contact_message = $('#textArea').val();
        var contact_country = $('#contact_country').val();        

        if(contact_name) {
            contactInfo.user_name = contact_name;
        }
        if(contact_email) {
            contactInfo.user_email = contact_email;
        }
        if(contact_subject) {
            contactInfo.user_subject = contact_subject;
        }
        if(contact_platform) {
            contactInfo.user_platform = contact_platform;
        }
        if(contact_country) {
            contactInfo.user_country = contact_country;
        }
        if(enpass_version) {
            contactInfo.enpass_version = enpass_version;
        }
        if(os_version) {
            contactInfo.os_version = os_version;
        }
        if(contact_message) {
            contactInfo.user_message = contact_message;
        }
    }

    function updateStudentInfo(studentInfo) {
        var student_name = $('#student_field_1').val();
        var student_email = $('#student_field_2').val();
        var student_org = $('#student_field_3').val();
        var student_country = $('#student_field_4').val();
        var student_message = $('#textArea').val();        

        if(student_name) {
            studentInfo.user_name = student_name;
        }
        if(student_email) {
            studentInfo.user_email = student_email;
        }
        if(student_org) {
            studentInfo.user_org = student_org;
        }
        if(student_country) {
            studentInfo.user_country = student_country;
        }
        if(student_message) {
            studentInfo.user_message = student_message;
        }
    }

    function updateTeamsInfo(teamsInfo) {
        var fullName = $('#teams_field_1').val();
        var workEmail = $('#teams_field_2').val();
        var companyName = $('#teams_field_3').val();
        var companySize = $('#teams_field_4 option:selected').val();
        var country = $('#teams_field_5 option:selected').val();
        var cloudServices = $('#cloud_services option:selected').val();
        var term_and_condition_check = document.getElementById("agree_terms_and_condition").checked;

        if(fullName) {
            teamsInfo.full_name = fullName;
        }
        if(workEmail) {
            teamsInfo.work_email = workEmail;
        }
        if(companyName) {
            teamsInfo.company_name = companyName;
        }
        if(companySize && companySize !== "-1") {
            teamsInfo.company_size = $('#teams_field_4 option:selected').text().trim();
        }
        if(country && country !== "-1") {
            teamsInfo.country = $('#teams_field_5 option:selected').text().trim();
        }
        if(cloudServices && cloudServices !== "-1") {
            teamsInfo.business_cloud = cloudServices;
        }
        if (term_and_condition_check){
            teamsInfo.agree_terms_and_condition = term_and_condition_check;
        }
    }

    function updateStarterInfo(starterInfo) {
        var fullName = $('#starter_field_1').val();
        var workEmail = $('#starter_field_2').val();
        var companyName = $('#starter_field_3').val();
        var companySize = $('#starter_field_4 option:selected').val();
        var country = $('#starter_field_5 option:selected').val();
        var cloudServices = $('#cloud_services option:selected').val();
        var term_and_condition_check = document.getElementById("agree_terms_and_condition").checked;

        if(fullName) {
            starterInfo.full_name = fullName;
        }
        if(workEmail) {
            starterInfo.work_email = workEmail;
        }
        if(companyName) {
            starterInfo.company_name = companyName;
        }
        if(companySize && companySize !== "-1") {
            starterInfo.company_size = $('#starter_field_4 option:selected').text().trim();
        }
        if(country && country !== "-1") {
            starterInfo.country = $('#starter_field_5 option:selected').text().trim();
        }
        if(cloudServices && cloudServices !== "-1") {
            starterInfo.business_cloud = cloudServices;
        }
        if (term_and_condition_check){
            starterInfo.agree_terms_and_condition = term_and_condition_check;
        }
    }

    function updateFamilyUserInfo(familyUserInfo) {
        var businessEmail = $('#business_email').val();
        var fullName = $('#full_name').val();
        var personalEmail = $('#personal_email').val();
        var term_and_condition_check = document.getElementById("agree_terms_and_condition").checked;

        if(businessEmail) {
            familyUserInfo.business_email = businessEmail;
        }
        if(fullName) {
            familyUserInfo.name = fullName;
        }
        if(personalEmail) {
            familyUserInfo.personal_email = personalEmail;
        }
        if (term_and_condition_check){
            familyUserInfo.agree_terms_and_condition = term_and_condition_check;
        }
    }

    function updateEnterpriseInfo(enterpriseInfo) {
        var firstName = $('#first_name').val();
        var lastName = $('#last_name').val();
        var jobTitle = $('#job_title').val();
        var businessEmail = $('#business_email').val();
        var companyName = $('#company_name').val();
        var companySize = $('#company_size option:selected').val();
        var phone = $('#phone').val();
        var country = $('#country option:selected').val();
        var zipCode = $('#zip_code').val();
        var cloudServices = $('#cloud_services option:selected').val();
        var message = $('#message').val();
        var term_and_condition_check = document.getElementById("agree_terms_and_condition").checked;

        if(firstName) {
            enterpriseInfo.first_name = firstName;
        }
        if(lastName) {
            enterpriseInfo.last_name = lastName;
        }
        if(jobTitle) {
            enterpriseInfo.job_title = jobTitle;
        }
        if(businessEmail) {
            enterpriseInfo.company_email_address = businessEmail;
        }
        if(companyName) {
            enterpriseInfo.company_name = companyName;
        }
        if(companySize && companySize !== "-1") {
            enterpriseInfo.company_size = $('#company_size option:selected').text().trim();
        }
        if(phone) {
            enterpriseInfo.phone = phone;
        }
        if(country && country !== "-1") {
            enterpriseInfo.country = $('#country option:selected').text().trim();
        }
        if(zipCode) {
            enterpriseInfo.zip_code = zipCode;
        }
        if(cloudServices && cloudServices !== "-1") {
            enterpriseInfo.business_cloud = cloudServices;
        }
        if(message) {
            enterpriseInfo.message = message;
        }        
        if (term_and_condition_check){
            enterpriseInfo.agree_terms_and_condition = term_and_condition_check;
        }
    }

    function updateEntdelInfo(entdelInfo) {
        var companyName = $('#company_name').val();
        var memberFirmName = $('#member_firm_name').val();
        var firstName = $('#first_name').val();
        var lastName = $('#last_name').val();
        var jobTitle = $('#job_title').val();
        var businessEmail = $('#business_email').val();
        var phone = $('#phone').val();
        var country = $('#country option:selected').val();
        var term_and_condition_check = document.getElementById("agree_terms_and_condition").checked;

        if(companyName) {
            entdelInfo.company_name = companyName;
        }
        if(memberFirmName) {
            entdelInfo.member_firm_name = memberFirmName;
        }
        if(firstName) {
            entdelInfo.first_name = firstName;
        }
        if(lastName) {
            entdelInfo.last_name = lastName;
        }
        if(jobTitle) {
            entdelInfo.job_title = jobTitle;
        }
        if(businessEmail) {
            entdelInfo.business_email = businessEmail;
        }
        if(phone) {
            entdelInfo.phone = phone;
        }
        if(country && country !== "-1") {
            entdelInfo.country = $('#country option:selected').text().trim();
        }        
        if (term_and_condition_check){
            entdelInfo.agree_terms_and_condition = term_and_condition_check;
        }
    }

    function updateResellerInfo(resellerInfo) {
        var firstName = $('#first_name').val();
        var lastName = $('#last_name').val();
        var email = $('#email').val();
        var companyName = $('#company_name').val();
        var address = $('#address').val();
        var country = $('#country option:selected').val();
        var contact = $('#contact').val();
        var additionalInformation = $('#additional_information').val();
        var term_and_condition_check = document.getElementById("agree_terms_and_condition").checked;

        if(firstName) {
            resellerInfo.first_name = firstName;
        }
        if(lastName) {
            resellerInfo.last_name = lastName;
        }
        if(email) {
            resellerInfo.email = email;
        }
        if(companyName) {
            resellerInfo.company_name = companyName;
        }
        if(address) {
            resellerInfo.address = address;
        }
        if(country && country !== "-1") {
            resellerInfo.country = $('#country option:selected').text().trim();
        }
        if(contact) {
            resellerInfo.contact = contact;
        }
        if(additionalInformation) {
            resellerInfo.additional_information = additionalInformation;
        }     
        if (term_and_condition_check){
            resellerInfo.agree_terms_and_condition = term_and_condition_check;
        }
    }

    function updateAffiliateInfo(affiliateInfo) {
        var affiliate_name = $('#affiliate_field_1').val();
        var affiliate_email = $('#affiliate_field_2').val();
        var affiliate_org = $('#affiliate_field_3').val();
        var affiliate_message = $('#textArea').val();        

        if(affiliate_name) {
            affiliateInfo.user_name = affiliate_name;
        }
        if(affiliate_email) {
            affiliateInfo.user_email = affiliate_email;
        }
        if(affiliate_org) {
            affiliateInfo.user_org = affiliate_org;
        }
        if(affiliate_message) {
            affiliateInfo.user_message = affiliate_message;
        }
    }

    function updatePressroomInfo(pressroomInfo) {
        var fullName = $('#pressroom_field_1').val();
        var pressName = $('#pressroom_field_2').val();
        var pressWebsite = $('#pressroom_field_3').val();
        var pressEmail = $('#pressroom_field_4').val();
        var spam_value = $("#press_subc_value").val();

        if(fullName) {
            pressroomInfo.user_name = fullName;
        }
        if(pressName) {
            pressroomInfo.press_name = pressName;
        }
        if(pressWebsite) {
            pressroomInfo.website = pressWebsite;
        }
        if(pressEmail) {
            pressroomInfo.user_email = pressEmail;
        }
        if(spam_value) {
            pressroomInfo.spam_value = spam_value;
        }
    }
    
    function validateBetaFormFields(betaInfo,validationStatus) {
        var first_name = betaInfo.first_name.trim();
        var last_name = betaInfo.last_name.trim();
        var beta_email = betaInfo.beta_email;
        var spam_value = betaInfo.spam_value;

        if(!first_name || !last_name || !beta_email || !isValidEmailAddress(beta_email)) {
            validationStatus = false;
        }
        if(spam_value) {
            validationStatus = false;
        }
        if(!grecaptcha.getResponse()) {
            validationStatus = false;
            alert("Please confirm captcha to proceed ");
        }
        return validationStatus;
    }

    function validateContactFields() {
        var name = $('#contact_field_1').val().trim();
            email = $('#contact_field_2').val();
            subject = $('#contact_field_3').val().trim();
            message = $('#textArea').val().trim();
            validationStatus = true;

        if(!name || !email || !isValidEmailAddress(email) || !subject || !message) {
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            validationStatus = false;
            alert('Please confirm captcha to proceed');
        }
        return validationStatus;
    }

    function validateStudentFields() {
        var name = $('#student_field_1').val().trim();
            email = $('#student_field_2').val();
            org = $('#student_field_3').val().trim();
            country = $('#student_field_4').val().trim();
            message = $('#textArea').val().trim();
            validationStatus = true;

        if(!name || !email || !isValidEmailAddress(email) || !org || !country || !message) {
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            validationStatus = false;
            alert('Please confirm captcha to proceed');
        }
        return validationStatus;
    }

    function validateTeamsFormFields() {
        var fullName = $('#teams_field_1').val().trim();
            workEmail = $('#teams_field_2').val();
            companyName = $('#teams_field_3').val().trim();
            country = $('#teams_field_5 option:selected').val();
            cloudServices = $('#cloud_services option:selected').val();
            term_and_condition_check = document.getElementById("agree_terms_and_condition");
            validationStatus = true;

        if(!fullName || !workEmail || !isValidEmailAddress(workEmail) || !companyName || !country || country == "-1" || !cloudServices || cloudServices == "-1") {
            validationStatus = false;
        }
        if(term_and_condition_check.checked == false) {
            $("#teams_form_error").text("You must agree to Enpass Terms of Use and Privacy Notice to create an account").css("display", "block");
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            validationStatus = false;
            alert('Please confirm captcha to proceed');
        }
        return validationStatus;
    }

    function validateStarterFormFields() {
        var fullName = $('#starter_field_1').val().trim();
            workEmail = $('#starter_field_2').val();
            companyName = $('#starter_field_3').val().trim();
            country = $('#starter_field_5 option:selected').val();
            cloudServices = $('#cloud_services option:selected').val();
            term_and_condition_check = document.getElementById("agree_terms_and_condition");
            validationStatus = true;

        if(!fullName || !workEmail || !isValidEmailAddress(workEmail) || !companyName || !country || country == "-1" || !cloudServices || cloudServices == "-1") {
            validationStatus = false;
        }
        if(term_and_condition_check.checked == false) {
            $("#teams_form_error").text("You must agree to Enpass Terms of Use and Privacy Notice to create an account").css("display", "block");
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            validationStatus = false;
            alert('Please confirm captcha to proceed');
        }
        return validationStatus;
    }

    function validateFamilyUserFormFields() {
        var businessEmail = $('#business_email').val().trim();
            fullName = $('#full_name').val().trim();
            personalEmail = $('#personal_email').val();
            term_and_condition_check = document.getElementById("agree_terms_and_condition");
            validationStatus = true;

        if(!businessEmail || !fullName || !isValidEmailAddress(businessEmail) || !personalEmail || !isValidEmailAddress(personalEmail)) {
            validationStatus = false;
        }
        if(term_and_condition_check.checked == false) {
            $("#bfp_response_status").text("You must agree to Enpass Terms of Use and Privacy Notice to create an account").css("display", "block");
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            $("#bfp_response_status").text("Please confirm captcha to proceed").css("display", "block");
            validationStatus = false;
        }
        return validationStatus;
    }

    function validateEnterpriseFormFields() {
        var firstName = $('#first_name').val().trim();
            lastName = $('#last_name').val().trim();
            jobTitle = $('#job_title').val().trim();
            businessEmail = $('#business_email').val();
            companyName = $('#company_name').val().trim();
            country = $('#country option:selected').val();
            zipCode = $('#zip_code').val().trim();
            cloudServices = $('#cloud_services option:selected').val();
            message = $('#message').val().trim();
            term_and_condition_check = document.getElementById("agree_terms_and_condition");
            var errorCss = {"border" :"1px solid red"};
            validationStatus = true;
        
        if (!firstName) {
            $('#first_name').css(errorCss);
            validationStatus = false;
        }
        if (!lastName) {
            $('#last_name').css(errorCss);
            validationStatus = false;
        }
        if(!isValidEmailAddress(businessEmail)) {
            $('#business_email').css(errorCss);
            validationStatus = false;
        }
        if (!companyName) {
            $('#company_name').css(errorCss);
            validationStatus = false;
        }
        if (!country || country == "-1") {
            $('#country').css(errorCss);
            validationStatus = false;
        }
        if (!zipCode) {
            $('#zip_code').css(errorCss);
            validationStatus = false;
        }
        if (!cloudServices || cloudServices == "-1") {
            $('#cloud_services').css(errorCss);
            validationStatus = false;
        }
        if (!message) {
            $('#message').css(errorCss);
            validationStatus = false;
        }
        if(term_and_condition_check.checked == false) {
            $("#enterprise_response_status").text("You must agree to Enpass Terms of Use and Privacy Notice to create an account").css("display", "block");
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            validationStatus = false;
            alert('Please confirm captcha to proceed');
        }
        return validationStatus;
    }

    function validateEntdelFormFields() {
        var companyName = $('#company_name').val().trim();
            memberFirmName = $('#member_firm_name').val().trim();
            firstName = $('#first_name').val().trim();
            lastName = $('#last_name').val().trim();
            jobTitle = $('#job_title').val().trim();
            businessEmail = $('#business_email').val();
            contact = $('#phone').val().trim();
            country = $('#country option:selected').val();
            term_and_condition_check = document.getElementById("agree_terms_and_condition");
            var errorCss = {"border" :"1px solid red"};
            validationStatus = true;
        
        if (!companyName) {
            $('#company_name').css(errorCss);
            validationStatus = false;
        }
        if (!memberFirmName) {
            $('#member_firm_name').css(errorCss);
            validationStatus = false;
        }
        if (!firstName) {
            $('#first_name').css(errorCss);
            validationStatus = false;
        }
        if (!lastName) {
            $('#last_name').css(errorCss);
            validationStatus = false;
        }
        if (!jobTitle) {
            $('#job_title').css(errorCss);
            validationStatus = false;
        }
        if(!isValidEmailAddress(businessEmail)) {
            $('#business_email').css(errorCss);
            validationStatus = false;
        }
        if (!contact) {
            $('#phone').css(errorCss);
            validationStatus = false;
        }
        if (!country || country == "-1") {
            $('#country').css(errorCss);
            validationStatus = false;
        }
        if(term_and_condition_check.checked == false) {
            $("#entdel_response_status").text("You must agree to Enpass Terms of Use and Privacy Notice to proceed.").css("display", "block");
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            validationStatus = false;
            alert('Please confirm captcha to proceed');
        }
        return validationStatus;
    }

    function validateResellerFormFields() {
        var firstName = $('#first_name').val().trim();
            lastName = $('#last_name').val().trim();
            email = $('#email').val();
            companyName = $('#company_name').val().trim();
            country = $('#country option:selected').val();
            contact = $('#contact').val().trim();
            term_and_condition_check = document.getElementById("agree_terms_and_condition");
            var errorCss = {"border" :"1px solid red"};
            validationStatus = true;
        
        if (!firstName) {
            $('#first_name').css(errorCss);
            validationStatus = false;
        }
        if (!lastName) {
            $('#last_name').css(errorCss);
            validationStatus = false;
        }
        if(!isValidEmailAddress(email)) {
            $('#email').css(errorCss);
            validationStatus = false;
        }
        if (!companyName) {
            $('#company_name').css(errorCss);
            validationStatus = false;
        }
        if (!country || country == "-1") {
            $('#country').css(errorCss);
            validationStatus = false;
        }
        if (!contact) {
            $('#contact').css(errorCss);
            validationStatus = false;
        }
        if(term_and_condition_check.checked == false) {
            $("#enterprise_response_status").text("You must agree to Enpass Terms of Use and Privacy Notice to register yourself").css("display", "block");
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            validationStatus = false;
            alert('Please confirm captcha to proceed');
        }
        return validationStatus;
    }

    function validateAffiliateFields() {
        var name = $('#affiliate_field_1').val().trim();
            email = $('#affiliate_field_2').val();
            org = $('#affiliate_field_3').val().trim();
            message = $('#textArea').val().trim();
            validationStatus = true;

        if(!name || !email || !isValidEmailAddress(email) || !org || !message) {
            validationStatus = false;
        }
        if (!grecaptcha.getResponse()) {
            validationStatus = false;
            alert('Please confirm captcha to proceed');
        }
        return validationStatus;
    }

    function validatePressroomFields() {
        var fullName = $('#pressroom_field_1').val().trim();
            pressName = $('#pressroom_field_2').val().trim();
            website = $('#pressroom_field_3').val().trim();
            email = $('#pressroom_field_4').val();
            spam_value = $('#press_subc_value').val().trim();        
            
            validationStatus = true;

        if(!fullName || !pressName || !email || !isValidEmailAddress(email)) {
            validationStatus = false;
        }
        if(spam_value) {
            validationStatus = false;
        }
        if(!grecaptcha.getResponse()) {
            validationStatus = false;
            alert("Please confirm captcha to proceed");
        }
        return validationStatus;
    }
    
});

// collapsable panel
document.addEventListener("DOMContentLoaded", function() {
    $('.collapse.in').prev('.panel-heading').addClass('active');
    var panel_element = $('#accordion .panel-heading');

    if(panel_element) {
        [].forEach.call(panel_element, function(div) {
            div.addEventListener('click', hide);
        });
    }

    function hide() {
        for(var i = 0; i < panel_element.length; i++){
            // case1: except clicked panel element 
            if(this != panel_element[i]){
                $(panel_element[i]).removeClass("active");                
            }
            // case2: clicked panel element
            if(this == panel_element[i]){
                // case1.1: clicked panel element contain active class
                if(panel_element[i].classList.contains("active")) {
                    $(panel_element[i]).removeClass("active");
                } else {
                // case1.2: clicked panel element does not contain active class                
                    $(panel_element[i]).addClass("active");
                }                
            }

        }
    }

});
document.addEventListener("DOMContentLoaded", function() {
    // check breach report page url
    var pathArray = window.location.pathname.split('/');
    var urlSlug = pathArray[1];
    var urlSlugTerm = pathArray[2];
    if(urlSlug == "breach" && urlSlugTerm == "report") {
        var DEFAULT_URL = window.location.href;
        var pathParameter = getUrlParams(DEFAULT_URL);
        if(pathParameter.uuid) {
            breachUuid = {"uuid":pathParameter.uuid};
            var serialized = JSON.stringify(breachUuid);
            var sendData = JSON.parse(serialized);
                $.ajax({
                    type: "POST",
                    url: "/wp-content/themes/enpass/breach_response.php",
                    data: sendData,
                    success: function(data){
                        var breach_data = JSON.parse(data); 
                        updateBreachWebsiteDetails(breach_data);
                        document.getElementById("breach_website").style.display = "flex";
                        document.getElementById("compromisedData").style.display = "block";
                    }
                });    
        }
    }
    
    function updateBreachWebsiteDetails(breach_data) {
        if(!breach_data) {return;}
        $("#compromisedData .more_info_wrapper").hide();
        
        if(breach_data.logo_path) {
            document.getElementById("breach_website_logo").src = breach_data.logo_path;
        }
        if(breach_data.domain) {
            document.getElementById("breach_website_url").innerHTML = breach_data.domain;
            document.getElementById("breach_website_name").innerHTML = breach_data.domain;
        }
        if(breach_data.breach_date) {
            var breach_date = new Date(breach_data.breach_date * 1000);
            breach_date = breach_date.toDateString().split(' ').slice(1).join(' ');
            if(!breach_data.IsDateConfirmed) {
                document.getElementById("breach_date").innerHTML = " on " + breach_date;
            }            
        }
        if(breach_data.description) {

            var referenceDesc = breach_data.description;
            var isHTML = RegExp.prototype.test.bind(/(<([^>]+)>)/i);
            if(isHTML(referenceDesc)) {
                var DescText = $(referenceDesc).text();
            } else {
                var DescText = referenceDesc;
            }
            
            var link = $("<a>");
            link.attr("href", DescText);
            link.attr("target", "_blank");
            link.text(DescText);
            link.addClass("note_desc");
            $("#compromisedData .more_info_wrapper").append(link);
            $("#compromisedData .more_info_wrapper").show();
        }
        if(breach_data.breach_data) {
            var compromisedData = breach_data.breach_data;
            for(var i = 0; i < compromisedData.length; i++) {
                var dataList = document.createElement("div");
                dataList.innerHTML = compromisedData[i];
                document.getElementById("compromisedListWrapper").appendChild(dataList);
            }
        }
        if(breach_data.provider == "haveibeenpwned.com") {
            $("#compromisedData .sourceProvider span").text(breach_data.provider);
            $("#compromisedData .sourceProvider").show();
        }
        
    }

    /*function to get current url parameters
        CURRENT_URL: default url 
    */
    function getUrlParams (CURRENT_URL) {
        if(!CURRENT_URL) {return;}
        
        params = {};
        (CURRENT_URL + '?').split('?')[1].split('&').forEach(function (pair) {
            pair = (pair + '=').split('=').map(decodeURIComponent);
            if (pair[0].length) {
                params[pair[0]] = pair[1];
            }
        });
        return params;
    }
});
// document.addEventListener("DOMContentLoaded", function() {
//     $('.collapse.in').prev('.panel-heading').addClass('active');
//     $('#accordion, #bs-collapse')
//       .on('show.bs.collapse', function(a) {
//         $(a.target).prev('.panel-heading').addClass('active');
//       })
//       .on('hide.bs.collapse', function(a) {
//         $(a.target).prev('.panel-heading').removeClass('active');
//       });

//     // fix for download page tabs link
//     $(function() {
//         var hash = window.location.hash;    
//         // do some validation on the hash here    
//         hash && $('ul.nav a[href="' + hash + '"]').tab('show');
//     });
// });