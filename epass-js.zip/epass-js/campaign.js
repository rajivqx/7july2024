document.addEventListener('DOMContentLoaded', function() {
    var DEFAULT_URL = window.location.href;
    var default_parameter = getUrlParams(DEFAULT_URL);
    // console.log(default_parameter);
    var OSName="";

    /*################### Mobile OS detection ###################*/

    var isMobile = {
        Android: function() {
            return navigator.userAgent.match(/Android/i);
        },
        iOS: function() {
            return navigator.userAgent.match(/iPhone|iPad|iPod/i);
        },
        any: function() {
            return (isMobile.Android() || isMobile.iOS());
        }
    };

    if (isMobile.any()) {

        if ( isMobile.Android() ) {
            // console.log("detected platform: Android");
            if(params.c == "tw") {
                var store_url = "https://play.google.com/store/apps/details?id=io.enpass.app&referrer=utm_source%3Dtwitter";
                window.location.href = store_url;
            } else if(params.c == "fb") {
                var store_url = "https://play.google.com/store/apps/details?id=io.enpass.app&referrer=utm_source%3Dfb";
                window.location.href = store_url;
            } else if(params.c == "in") {
                var store_url = "https://play.google.com/store/apps/details?id=io.enpass.app&referrer=utm_source%3Dinsta";
                window.location.href = store_url;
            } else if(params.c == "bl") {
                var store_url = "https://play.google.com/store/apps/details?id=io.enpass.app&referrer=utm_source%3Dblog";
                window.location.href = store_url;
            }
            
        } else if (isMobile.iOS()) {
            // console.log("detected platform: ios");
            if(params.c == "tw") {
                var store_url = "https://apps.apple.com/app/apple-store/id455566716?pt=637991&ct=twitter&mt=8";
                window.location.href = store_url;
            } else if(params.c == "fb") {
                var store_url = "https://apps.apple.com/app/apple-store/id455566716?pt=637991&ct=fb&mt=8";
                window.location.href = store_url;
            } else if(params.c == "in") {
                var store_url = "https://apps.apple.com/app/apple-store/id455566716?pt=637991&ct=insta&mt=8";
                window.location.href = store_url;
            } else if(params.c == "bl") {
                var store_url = "https://apps.apple.com/app/apple-store/id455566716?pt=637991&ct=blog&mt=8";
                window.location.href = store_url;
            }
        }
    } else {

        /*#################### Desktop OS detection ####################*/

        // If Detected OS is Windows 10

        if (window.navigator.userAgent.indexOf("Windows NT 10.0")!= -1 && (OSName="Windows 10")) {
            // console.log('os name : ' + OSName);
            if(params.c == "tw") {
                var store_url = "https://www.microsoft.com/store/apps/enpass-password-manager/9nj3kmh29vgj?cid=twitter";
                window.location.href = store_url;
            } else if(params.c == "fb") {
                var store_url = "https://www.microsoft.com/store/apps/enpass-password-manager/9nj3kmh29vgj?cid=fb";
                window.location.href = store_url;
            } else if(params.c == "in") {
                var store_url = "https://www.microsoft.com/store/apps/enpass-password-manager/9nj3kmh29vgj?cid=insta";
                window.location.href = store_url;
            } else if(params.c == "bl") {
                var store_url = "https://www.microsoft.com/store/apps/enpass-password-manager/9nj3kmh29vgj?cid=blog";
                window.location.href = store_url;
            }
        }

        // If Detected OS is MacOS 
        if (navigator.appVersion.indexOf("Mac")!=-1 && (OSName="MacOS")) {
            // console.log('os name : ' + OSName);
            if(params.c == "tw") {
                var store_url = "https://apps.apple.com/app/apple-store/id732710998?pt=637991&ct=twitter&mt=8";
                window.location.href = store_url;
            } else if(params.c == "fb") {
                var store_url = "https://apps.apple.com/app/apple-store/id732710998?pt=637991&ct=fb&mt=8";
                window.location.href = store_url;
            } else if(params.c == "in") {
                var store_url = "https://apps.apple.com/app/apple-store/id732710998?pt=637991&ct=insta&mt=8";
                window.location.href = store_url;
            } else if(params.c == "bl") {
                var store_url = "https://apps.apple.com/app/apple-store/id732710998?pt=637991&ct=blog&mt=8";
                window.location.href = store_url;
            }
        }

        // client os is not match
        if(!isMobile.any() && OSName == "") {
            var cid = params.c;
            if(cid == "tw" || cid == "fb" || cid == "in" || cid == "bl") {
                // console.log("default download page");
                var store_url = "/downloads/";
                window.location.href = store_url;
            }
        }
    }

}, false);

/*function to get current url parameters
  CURRENT_URL: default url 
*/
function getUrlParams (CURRENT_URL) {
    if(!CURRENT_URL) {return;}

    params = {};
    (CURRENT_URL + '?').split('?')[1].split('&').forEach(function (pair) {
        pair = (pair + '=').split('=').map(decodeURIComponent);
        if (pair[0].length) {
            params[pair[0]] = pair[1];
        }
    });
    return params;
}