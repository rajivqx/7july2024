
$(document).ready(function(){
	$('input, textarea,select').attr('required', false);
	$('input, textarea,select').attr('autocomplete', 'off');

	$('.delet-btn').click(function(e){
		e.preventDefault();
		var id = $(this).data('id');
		$('input[name=delete_id]').val(id);
	});

	$('form.form-submit').submit(function(e){
		e.preventDefault();
		$('.preloader').show();
		$('input, textarea,select').attr('readonly', true);
		$('.notification-popup').html('');
		var actn = $(this).attr('action');
		$.ajax({
			url: actn,
			data:new FormData(this),
			type: 'post',
			contentType: false,
			cache: false,
			processData: false,
			dataType:'json',
			success: function(result){
				$('input, textarea,select').attr('readonly', false);
				if(result.success == true){
					if(result.msg){alert(result.msg); }
					if(result.r_link){ document.location.href = result.r_link; }
                    else{
					   location.reload();
                    }
				}
				else{
					$.each(result.message,function(key,value){
						var popup = $('.notification-popup');
						popup.show();
						popup.removeClass('hide');
						popup.append(value);
						popup.fadeOut(5000);
					});
				}
				$('.preloader').hide();
			}

		});
	});

	$('.signupform').submit(function(e){
		e.preventDefault();
		$('.loading-prv').show();
		$('.frm_error_lg').remove();
		var lnk = $(this).attr('action');
		$.ajax({
			url: lnk,
			data: new FormData(this),
			type: 'post',
			contentType: false,
			cache: false,
			processData: false,
			dataType:'json',
			success: function(result){
				$('.loading-prv').hide();
				if(result.success == true){
					location.reload();
				}
				else{
					$.each(result.message,function(key,value){
						var element = $('input[name='+key+']');
                        element.before(value);
					});
				}
			}

		});
	});


});
/*preview image */
    function readURL(input, str1) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#'+str1).attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }