<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brands extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'brands', 'id', 'desc');
		$this->load->view('admin/brands', array('list'=>$lst));
	}

	public function add(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'Title', 'required|is_unique[brands.title]');

		if($this->form_validation->run()){
            
            
            $config = [
                'upload_path' => './../asset/images/brands/',
                'allowed_types' => 'jpg|png|gif|jpeg',
                'encrypt_name' => TRUE
            ];

            $this->load->library('upload', $config); 
            $files = $_FILES;
            if(!empty($_FILES['image']['name'])){
                $this->upload->initialize($config);
                if($this->upload->do_upload('image')){
                    $img_data = $this->upload->data();
                    $form_data['image'] = $img_data['file_name'];                    
                    
                    $data = array(
                        'title' => $form_data['title'],
                        'image' => $form_data['image'],
                        'details' => $form_data['detail'],
                        'create_date' => date('Y-m-d'),
                        'status' => $form_data['status']
                    );
                    if($this->mymodel->insert_data('brands', $data))	{
                        $error['success'] = true;
                    }
                    else{
                        $error['message']['title'] = '<p>Error in submiting data</p>';
                    }
                }else{
                    $error['message']['image'] = $this->upload->display_errors('<p>', '</p>');
                }
            }
            else{$error['message']['image'] = '<p>Please upload an image</p>';}

					
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function delete(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('delete_id', 'Category', 'required|is_natural');
		if($this->form_validation->run()){
			if($this->mymodel->delete('category', array('category_id'=>$form_data['delete_id'])))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}
		}
		else{
			$error['message'][$key] = form_error($key);
		}
		echo json_encode($error);
	}


	public function edit(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('e_title', 'Title', 'required');

		$config = [
			'upload_path' => './../asset/images/brands/',
			'allowed_types' => 'jpg|png|gif|jpeg',
			'encrypt_name' => TRUE
		];

		$this->load->library('upload', $config); 
		$files = $_FILES;
		if(!empty($_FILES['e_image']['name'])){
			$this->upload->initialize($config);
			if($this->upload->do_upload('e_image')){
				$img_data = $this->upload->data();
				$form_data['image'] = $img_data['file_name'];
			}else{
				$error['message']['e_image'] = $this->upload->display_errors('<span class="frm_error">', '</span>');
			}
		}
		else{$form_data['image'] = $form_data['gallery_img']; }
		
		if($this->form_validation->run()){

			 $data = array(
                'title' => $form_data['e_title'],
                'image' => $form_data['image'],
                'details' => $form_data['e_detail'],
                'status' => $form_data['e_status']
            );
			if($this->mymodel->update('brands', array('id'=>$form_data['brnds_id']), $data))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}

}