<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'orders', 'order_id', 'desc');
        $this->load->view('admin/orders', array('list'=>$lst));
	}
	
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('login'));
		}
	}


}
