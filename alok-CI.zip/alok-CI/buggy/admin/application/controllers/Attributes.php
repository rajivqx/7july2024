<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attributes extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'attributes', 'id', 'desc');
		$this->load->view('admin/attributes-list', array('list'=>$lst));
	}

	public function add(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'Attribute title', 'required|is_unique[attributes.name]');
		$this->form_validation->set_rules('property', 'Property', 'required');

		if($this->form_validation->run()){

			$data = array(
				'name' => strtoupper($form_data['title']),
				'status' => $form_data['status']
			);
			$sql = $this->mymodel->insert_data('attributes', $data);
			if($sql){
				$propt = explode( ',',$form_data['property']);
				foreach($propt as $prp){
					$data = array(
						'attribute_id' => $sql,
						'name' => strtoupper($prp)
					);
					$this->mymodel->insert_data('attribute_property', $data);
				}
				$error['success'] = true;
				$error['msg'] = 'New Attribute created successfully';
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function delete(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('delete_id', 'Category', 'required|is_natural');
		if($this->form_validation->run()){
			if($this->mymodel->delete('attributes', array('id'=>$form_data['delete_id'])))	{
				$this->mymodel->delete('attribute_property', array('attribute_id'=>$form_data['delete_id']));
				$this->mymodel->delete('product_property', array('attribute_id'=>$form_data['delete_id']));
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}
		}
		else{
			$error['message'][$key] = form_error($key);
		}
		echo json_encode($error);
	}
    
    public function fetch($id){
        if($id){
            $lst = $this->mymodel->select_all_where('*', array('attribute_id'=>$id), 'attribute_property');
            if($lst){
                echo '<div class="attr-prop">';
                foreach($lst as $lt){
                    echo '
                        <span class="checkbox-inline"><input type="checkbox" name="prop[]" value="'.$lt->id.'">'.$lt->name.'</span>
                    ';
                }
                echo '</div>';
            }else{
                echo '<p class="alert alert-danger>NO property found</p>';
            }
        }else{
            echo '<p class="alert alert-danger>NO property found</p>';
        }
    }
        
    public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}

}