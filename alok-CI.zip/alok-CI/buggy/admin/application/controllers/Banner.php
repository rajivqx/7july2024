<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'banners', 'id', 'desc');
		$this->load->view('admin/banners', array('list'=>$lst));
	}

	public function add(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('page', 'Page', 'required');
		$this->form_validation->set_rules('type', 'Banner type', 'required');

		if($this->form_validation->run()){
            
            
            $config = [
                'upload_path' => './../asset/images/banners/',
                'allowed_types' => 'jpg|png|gif|jpeg',
                'encrypt_name' => TRUE
            ];

            $this->load->library('upload', $config); 
            $files = $_FILES;
            if(!empty($_FILES['image']['name'])){
                $this->upload->initialize($config);
                if($this->upload->do_upload('image')){
                    $img_data = $this->upload->data();
                    $form_data['image'] = $img_data['file_name'];                    
                    
                    $data = array(
                        'title' => $form_data['title'],
                        'image_link' => $form_data['image'],
                        'page' => $form_data['page'],
                        'url_link' => $form_data['url_link'],
                        'banner_type' => $form_data['type']
                    );
                    if($this->mymodel->insert_data('banners', $data))	{
                        $error['success'] = true;
                    }
                    else{
                        $error['message']['title'] = '<p>Error in submiting data</p>';
                    }
                }else{
                    $error['message']['image'] = $this->upload->display_errors('<p>', '</p>');
                }
            }
            else{$error['message']['image'] = '<p>Please upload an image</p>';}

					
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function delete(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('delete_id', 'Category', 'required|is_natural');
		if($this->form_validation->run()){
			if($this->mymodel->delete('banners', array('id'=>$form_data['delete_id'])))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}
		}
		else{
			$error['message'][$key] = form_error($key);
		}
		echo json_encode($error);
	}


	public function edit(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
        $this->form_validation->set_rules('e_title', 'Title', 'required');
		$this->form_validation->set_rules('e_page', 'Page', 'required');
		$this->form_validation->set_rules('e_type', 'Banner type', 'required');

		$config = [
			'upload_path' => './../asset/images/banners/',
			'allowed_types' => 'jpg|png|gif|jpeg',
			'encrypt_name' => TRUE
		];

		$this->load->library('upload', $config); 
		$files = $_FILES;
		if(!empty($_FILES['e_image']['name'])){
			$this->upload->initialize($config);
			if($this->upload->do_upload('e_image')){
				$img_data = $this->upload->data();
				$form_data['image'] = $img_data['file_name'];
			}else{
				$error['message']['e_image'] = $this->upload->display_errors('<span class="frm_error">', '</span>');
			}
		}
		else{$form_data['image'] = $form_data['gallery_img']; }
		
		if($this->form_validation->run()){

			 $data = array(
                'title' => $form_data['e_title'],
                'image_link' => $form_data['image'],
                'page' => $form_data['e_page'],
                'url_link' => $form_data['e_url_link'],
                'banner_type' => $form_data['e_type']
            );
			if($this->mymodel->update('banners', array('id'=>$form_data['banner_id']), $data))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}

}