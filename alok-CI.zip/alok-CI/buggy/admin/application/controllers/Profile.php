<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	public function index()
	{
        $pr = $this->mymodel->get_1('*', 'admin_list', array('admin_id'=> $this->session->userdata('admin_id')));
		$this->load->view('admin/profile', array('prfl'=>$pr));
	}
    
    public function edit(){
        $error = array('success'=>'false', 'message'=>array());
        $this->load->library('form_validation');
        $form_data = $this->input->post();
        $this->form_validation->set_error_delimiters('<span class="frm_error">', '</span>');
        $this->form_validation->set_rules('name', 'Name', 'required|max_length[50]');
        $this->form_validation->set_rules('email', 'Email', 'required|max_length[100]|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required|exact_length[10]');
        $config = [
            'upload_path' => './asset/img/',
            'allowed_types' => 'jpg|png|gif|jpeg',
            'encrypt_name' => TRUE
        ];

        $this->load->library('upload', $config); 
        $files = $_FILES;
        if(!empty($_FILES['image']['name'])){
            $this->upload->initialize($config);
            if($this->upload->do_upload('image')){
                $img_data = $this->upload->data();
                $form_data['image'] = $img_data['file_name'];
            }else{
                $error['message']['image'] = $this->upload->display_errors('<span class="frm_error">', '</span>');
            }
        }
        else{$form_data['image'] = $form_data['prfl_img'];}

        if($this->form_validation->run()){

            $data = array(
                'admin_name' => $form_data['name'],
                'admin_email' => $form_data['email'],
                'admin_mobile' => $form_data['mobile'],
                'admin_image' => $form_data['image']
            );
            $admnid = $this->session->userdata('admin_id');
            if($this->mymodel->update('admin_list', array('admin_id'=>$admnid), $data)){
                $error['success'] = true;
            }
            else{
                $error['message']['e_category'] = '<span class="frm_error">Failed to submit, please try again!!</span>';
            }

        }
        else{
            foreach($_POST as $key => $value){
                $error['message'][$key] = form_error($key);
            }
        }

        echo json_encode($error);

    }
    
    public function change_password(){
        $error = array('success'=>'false', 'message'=>array());
        $this->load->library('form_validation');
        $form_data = $this->input->post();
        $this->form_validation->set_error_delimiters('<span class="frm_error">', '</span>');
        $this->form_validation->set_rules('old_pass', 'Old password', 'required');
        $this->form_validation->set_rules('new_pass', 'New password', 'required|min_length[7]|max_length[50]');
        $this->form_validation->set_rules('conf_pass', 'Confirm password', 'required|matches[new_pass]');

        if($this->form_validation->run()){
            $admnid = $this->session->userdata('admin_id');
            $prpl = $this->mymodel->get_1('admin_password', 'admin_list', array('admin_id'=>$admnid));
            if($prpl->admin_password === $form_data['old_pass']){
                $data = array(
                    'admin_password' => $form_data['new_pass']
                );

                if($this->mymodel->update('admin_list', array('admin_id'=>$admnid), $data)){
                    $error['success'] = true;
                }
                else{
                    $error['message']['old_pass'] = '<span class="frm_error">Failed to submit, please try again!!</span>';
                }
            }
            else{
                $error['message']['old_pass'] = '<span class="frm_error">Old password is invalid.please try again!!</span>';
            }

        }
        else{
            foreach($_POST as $key => $value){
                $error['message'][$key] = form_error($key);
            }
        }

        echo json_encode($error); 
    }
	
    public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('login'));
		}
	}


}
