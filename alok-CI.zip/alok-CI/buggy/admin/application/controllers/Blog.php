<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'blog', 'id', 'desc');
		$this->load->view('admin/blog-list', array('list'=>$lst));
	}
    
    public function addblog()
	{
		$this->load->view('admin/blog-add');
	}
    
	public function add(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'Title', 'required|max_length[200]');
		$this->form_validation->set_rules('short_dtl', 'Details', 'required');
        $config = [
            'upload_path' => './../asset/images/blog/',
            'allowed_types' => 'jpg|png|gif|jpeg',
            'encrypt_name' => TRUE
        ];

        $this->load->library('upload', $config); 
        $files = $_FILES;
        
		if($this->form_validation->run()){
            if(!empty($_FILES['image']['name'])){
                $this->upload->initialize($config);

                if($this->upload->do_upload('image')){
                    $img_data = $this->upload->data();
                    $form_data['image'] = $img_data['file_name'];                  

                    $data = array(
                        'title' => $form_data['title'],
                        'image' => $form_data['image'],
                        'contents' => $form_data['short_dtl'],
                        'added_by' => 'ADMIN',
                        'added_by_id' => 1,
                        'create_date' => date('Y-m-d H:i'),
                        'status' => $form_data['status']
                    );
                    if($this->mymodel->insert_data('blog', $data)){
                        $error['success'] = true;
                        $error['r_link'] = base_url('blog');
                    }
                    else{
                        $error['message']['title'] = '<p>Error in submiting data</p>';
                    }	
                }else{
                    $error['message']['image'] = $this->upload->display_errors('<p>', '</p>');
                }
            }
            else{
                $error['message']['image'] = '<p>Please upload an image</p>';
            }
				
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}
    
    public function edit($id){
        if (!$id) {return redirect('blog');}
        $lst = $this->mymodel->get_1('*', 'blog', array('id' =>$id));
        $this->load->view('admin/blog_edit', array('list'=>$lst));
    }
    
    public function edt(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'Title', 'required|max_length[200]');
		$this->form_validation->set_rules('short_dtl', 'Details', 'required');
		$this->form_validation->set_rules('edt_id', 'id', 'required');
        $config = [
            'upload_path' => './../asset/images/blog/',
            'allowed_types' => 'jpg|png|gif|jpeg',
            'encrypt_name' => TRUE
        ];

        $this->load->library('upload', $config); 
        $files = $_FILES;
        if(!empty($_FILES['image']['name'])){
            $this->upload->initialize($config);

            if($this->upload->do_upload('image')){
                $img_data = $this->upload->data();
                $form_data['image'] = $img_data['file_name'];                  
            }else{
                 $form_data['image'] = $this->upload->display_errors('<p>', '</p>');
            }
        }else{
            $form_data['image'] = $form_data['img1']; 
        }
		if($this->form_validation->run()){
            $data = array(
                'title' => $form_data['title'],
                'image' => $form_data['image'],
                'contents' => $form_data['short_dtl'],
                'status' => $form_data['status']
            );
            if($this->mymodel->update('blog', array('id'=>$form_data['edt_id']), $data)){
                $error['success'] = true;
                $error['r_link'] = base_url('blog');
            }
            else{
                $error['message']['title'] = '<p>Error in submiting data</p>';
            }	
				
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function delete(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('delete_id', 'Vendor', 'required|is_natural');
		if($this->form_validation->run()){
			if($this->mymodel->delete('blog', array('id'=>$form_data['delete_id'])))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}
		}
		else{
			$error['message'][$key] = form_error($key);
		}
		echo json_encode($error);
	}

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}

}