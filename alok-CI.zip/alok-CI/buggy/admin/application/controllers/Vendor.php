<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'vendors', 'id', 'desc');
		$this->load->view('admin/vendor-list', array('list'=>$lst));
	}

	public function add(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('compnay', 'Company', 'required|max_length[200]');
		$this->form_validation->set_rules('contact_prson', 'Contact person', 'required|max_length[100]');
		$this->form_validation->set_rules('mobile', 'Mobile', 'required|is_unique[vendors.mobile_no]|is_natural|exact_length[10]');
		$this->form_validation->set_rules('email', 'Email', 'required|is_unique[vendors.email_id]|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'required');

		if($this->form_validation->run()){

			$data = array(
				'mobile_no' => $form_data['mobile'],
				'email_id' => $form_data['email'],
				'company_name' => $form_data['compnay'],
				'contact_person' => $form_data['contact_prson'],
				'address' => $form_data['address'],
				'join_date' => date('Y-m-d H:i'),
				'password' => $form_data['password'],
				'status' => $form_data['status']
			);
			if($this->mymodel->insert_data('vendors', $data)){
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function delete(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('delete_id', 'Vendor', 'required|is_natural');
		if($this->form_validation->run()){
			if($this->mymodel->delete('vendors', array('id'=>$form_data['delete_id'])))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}
		}
		else{
			$error['message'][$key] = form_error($key);
		}
		echo json_encode($error);
	}

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}

}