<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'category', 'category_id', 'desc');
		$this->load->view('admin/category', array('list'=>$lst));
	}

	public function add_category(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'Category name', 'required|is_unique[category.category_title]');
		$this->form_validation->set_rules('position', 'Position', 'required|is_unique[category.position]|is_natural');

		$config = [
			'upload_path' => './asset/img/category/',
			'allowed_types' => 'jpg|png|gif|jpeg',
			'encrypt_name' => TRUE
		];

		$this->load->library('upload', $config); 
		$files = $_FILES;
		if(!empty($_FILES['image']['name'])){
			$this->upload->initialize($config);
			if($this->upload->do_upload('image')){
				$img_data = $this->upload->data();
				$form_data['image'] = $img_data['file_name'];
			}else{
				$error['message']['image'] = $this->upload->display_errors('<span class="frm_error">', '</span>');
			}
		}
		else{$form_data['image'] = "default.png";}
		
		if($this->form_validation->run()){

			$data = array(
				'category_title' => $form_data['title'],
				'category_image' => $form_data['image'],
				'category_detail' => $form_data['detail'],
				'position' => $form_data['position'],
				'status' => $form_data['status']
			);
			if($this->mymodel->insert_data('category', $data))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function delete(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('delete_id', 'Category', 'required|is_natural');
		if($this->form_validation->run()){
			if($this->mymodel->delete('category', array('category_id'=>$form_data['delete_id'])))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}
		}
		else{
			$error['message'][$key] = form_error($key);
		}
		echo json_encode($error);
	}


	public function edit_category(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('e_title', 'Category name', 'required');
		$this->form_validation->set_rules('e_position', 'Position', 'required|is_natural');

		$config = [
			'upload_path' => './asset/img/category/',
			'allowed_types' => 'jpg|png|gif|jpeg',
			'encrypt_name' => TRUE
		];

		$this->load->library('upload', $config); 
		$files = $_FILES;
		if(!empty($_FILES['e_image']['name'])){
			$this->upload->initialize($config);
			if($this->upload->do_upload('e_image')){
				$img_data = $this->upload->data();
				$form_data['image'] = $img_data['file_name'];
			}else{
				$error['message']['e_image'] = $this->upload->display_errors('<span class="frm_error">', '</span>');
			}
		}
		else{$form_data['image'] = $form_data['gallery_img']; }
		
		if($this->form_validation->run()){

			$data = array(
				'category_title' => $form_data['e_title'],
				'category_image' => $form_data['image'],
				'category_detail' => $form_data['e_detail'],
				'position' => $form_data['e_position'],
				'status' => $form_data['e_status']
			);
			if($this->mymodel->update('category', array('category_id'=>$form_data['category_id']), $data))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}

}