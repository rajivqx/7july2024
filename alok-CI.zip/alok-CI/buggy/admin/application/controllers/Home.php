<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$order = $this->mymodel->select_all_limit('*', array('deliver_status'=>'INPROCESS'), 'orders', 'order_id', 'desc', 5, 0);
		$cuts = $this->mymodel->select_all_limit('*', array('status'=>'ACTIVE'), 'customers', 'customer_id', 'desc', 5, 0);
		$vndr = $this->mymodel->select_all_limit('*', array('status'=>'ACTIVE'), 'vendors', 'id', 'desc', 5, 0);
		$catg = $this->mymodel->select_all_limit('*', array('status'=>'ACTIVE'), 'category', 'category_id', 'desc', 5, 0);
        $this->load->view('admin/index',array('odr'=>$order, 'custmr'=>$cuts, 'vender'=>$vndr, 'cat'=>$catg));
	}
	
	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('login'));
		}
	}


}
