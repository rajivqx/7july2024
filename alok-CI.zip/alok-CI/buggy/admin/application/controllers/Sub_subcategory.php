<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sub_subCategory extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'sub_subcategory', 'id', 'desc');
		$this->load->view('admin/sub_subcategory', array('list'=>$lst));
	}

	public function add(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'title', 'required');
		$this->form_validation->set_rules('category_id', 'Category', 'required');
		$this->form_validation->set_rules('subcategory_id', 'Sub category', 'required');
		$this->form_validation->set_rules('position', 'Position', 'required');

		if($this->form_validation->run()){

			$data = array(
				'title' => $form_data['title'],
				'category_id' => $form_data['category_id'],
				'subcategory_id' => $form_data['subcategory_id'],
				'position' => $form_data['position'],
				'detail' => $form_data['detail'],
				'status' => $form_data['status']
			);
			if($this->mymodel->insert_data('sub_subcategory', $data))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function edit($id){
		if (!$id) {return redirect('sub_subcategory');}
		$lst = $this->mymodel->get_1('*', 'sub_subcategory', array('id' =>$id));
		$this->load->view('admin/sub_subcategory_edit', array('list'=>$lst));
	}
	public function delete(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('delete_id', 'Category', 'required|is_natural');
		if($this->form_validation->run()){
			if($this->mymodel->delete('category', array('category_id'=>$form_data['delete_id'])))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}
		}
		else{
			$error['message'][$key] = form_error($key);
		}
		echo json_encode($error);
	}


	public function edit_subx(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'title', 'required');
		$this->form_validation->set_rules('category_id', 'Category', 'required');
		$this->form_validation->set_rules('subcategory_id', 'Sub category', 'required');
		$this->form_validation->set_rules('position', 'Position', 'required|is_natural');

		if($this->form_validation->run()){

			$data = array(
				'title' => $form_data['title'],
				'category_id' => $form_data['category_id'],
				'subcategory_id' => $form_data['subcategory_id'],
				'position' => $form_data['position'],
				'detail' => $form_data['detail'],
				'status' => $form_data['status']
			);
			if($this->mymodel->update('sub_subcategory',array('id'=>$form_data['edit_id']), $data))	{
				$error['msg'] = "Sub subcategory updated successfully";
				$error['r_link'] = base_url('sub_subcategory');
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}

}