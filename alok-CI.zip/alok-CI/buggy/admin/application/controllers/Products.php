<?php

	class Products extends CI_Controller{
		public function index(){
			$lst = $this->mymodel->select_all('*', 'products', 'id', 'desc');
			$this->load->view('admin/product_list', array('list'=>$lst));
		}
        
        public function addnew(){
            $this->load->view('admin/product_add');   
        }
        
        public function search($id){
            $lst = $this->mymodel->select_all_where('*', " title like '%".$id."%'", 'products');
            if($lst){
                
            echo '<table class="table">';
                foreach($lst as $prd){
                    $cat = $this->mymodel->get_1('category_title', 'category', array('category_id'=>$prd->category_id));
                    $scat = $this->mymodel->get_1('title', 'subcategory', array('subcategory_id'=>$prd->subcategory_id));
                    $sscat = $this->mymodel->get_1('title', 'sub_subcategory', array('id'=>$prd->sub_subcategory));
                    $img = $this->mymodel->get_1('*', 'product_image', array('product_id'=>$prd->id));
                    if($img){$imag_lnk = $img->image_link; }else{
                        $imag_lnk = 'default.png';
                    }
        ?>
            <tr>
                <td>
                    <img src="<?= base_url('../asset/images/products/'.$imag_lnk); ?>" style="height: 50px; width: 50px;">
                </td>
                <td>
                   <h5><?= $prd->title; ?></h5>
                </td>
                <td><p><?= $cat->category_title; ?> <i class="fa fa-angle-right"></i> <?= $scat->title; ?> <i class="fa fa-angle-right"></i> <?= $sscat->title; ?></p></td>
                <td><a onclick="selectProduct(<?= $prd->id; ?>)" href="#">Select</a></td>
                
            </tr>
        <?php
                }
            echo '</table>';
            }
            else{
                echo '<p class="alert alert-danger">No match found</p>';
            }
        }       
        
		public function add(){
			$error = array('success'=>false, 'message'=>array());
            $this->load->library('form_validation');
			$form_data = $this->input->post();
			$this->form_validation->set_error_delimiters('<p>','</p>');
			$this->form_validation->set_rules('category_id', 'Category', 'required');
			$this->form_validation->set_rules('subcategory_id', 'Sub category', 'required');
			$this->form_validation->set_rules('sub_subcategory_id', 'Sub sub-category', 'required');
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('sku', 'SKU', 'required');
			$this->form_validation->set_rules('hline', 'Heading', 'required');
			$this->form_validation->set_rules('mrp', 'MRP Price', 'required|is_natural');
			$this->form_validation->set_rules('price', 'Price', 'required|is_natural');
			$this->form_validation->set_rules('brand', 'Brand', 'required|is_natural');
			$this->form_validation->set_rules('short_dtl', 'Highlights', 'required');
			$this->form_validation->set_rules('detail', 'Description', 'required');
			$this->form_validation->set_rules('qty', 'Quantity', 'required|is_natural');
			$this->form_validation->set_rules('vendor', 'Vendor', 'required|is_natural');
			$this->form_validation->set_rules('d_price', 'Delivary charge', 'required|is_natural');
			$this->form_validation->set_rules('v_price', 'Vendor Price', 'required|is_natural');

			if($this->form_validation->run()){
				//strart image validation
				$data = array(
                    'title' => $form_data['title'],
                    'heading_line' => $form_data['hline'],
                    'sku' => $form_data['sku'],
                    'brand_id' => $form_data['brand'],
                    'category_id' => $form_data['category_id'],
                    'subcategory_id' => $form_data['subcategory_id'],
                    'sub_subcategory' => $form_data['sub_subcategory_id'],
                    'price' => $form_data['price'],
                    'mrp' => $form_data['mrp'],
                    'short_details' => $form_data['short_dtl'],
                    'detail' => $form_data['detail'],
                    'create_date' => date('Y-m-d H:i')
                );

                $prd_id = $this->mymodel->insert_data('products', $data);
                if($prd_id){
                    //multiple images
                    if($form_data['approvel'] == 'APPROVE'){ $app_date = date('Y-m-d H:i');}else{$app_date = null;}
                    $vdata = array(
                        'vender_id' => $form_data['vendor'],
                        'product_id' => $prd_id,
                        'vendors_price' => $form_data['v_price'],
                        'shipping_charge' => $form_data['d_price'],
                        'create_date' => date('Y-m-d H:i'),
                        'approval' => $form_data['approvel'],
                        'approval_date' => $app_date,
                        'display_status' => $form_data['display'],
                        'comment' => $form_data['comments'],
                        'quantity' => $form_data['qty']
                    );
                    $this->mymodel->insert_data('vendors_products', $vdata);
                    
                    if($_FILES){
                        $this->load->library('upload');
                        $config = [
                            'upload_path' => './../asset/images/products/',
                            'allowed_types' => 'jpg|png|gif|jpeg',
                            'encrypt_name' => TRUE
                        ];
                        $files = $_FILES;
                        $cpt = count($_FILES['userfile']['name']);
                        for($i=0; $i<$cpt; $i++)
                        {
                            $_FILES['userfile']['name']= $files['userfile']['name'][$i];
                            $_FILES['userfile']['type']= $files['userfile']['type'][$i];
                            $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
                            $_FILES['userfile']['error']= $files['userfile']['error'][$i];
                            $_FILES['userfile']['size']= $files['userfile']['size'][$i]; 

                            $this->upload->initialize($config);
                            if($this->upload->do_upload()){
                                $dataInfo = $this->upload->data();
                                $this->mymodel->insert_data('product_image', array('product_id'=>$prd_id, 'image_link'=>$dataInfo['file_name']));
                                
                            }
                        }
                    }
				//end image validation
                    if(isset($_REQUEST['prop'])){
                        $prop = $_REQUEST['prop'];
                        $s = count($prop);
                        for($i=1; $i<=$s; $i++){
                            $attr_id = $this->mymodel->get_1('*', 'attribute_property', array('id' =>$prop[$i-1]));
                            $this->mymodel->insert_data('product_property', array('attribute_id'=>$attr_id->attribute_id, 'property_id'=>$prop[$i-1], 'product_id'=>$prd_id));
                        }
                    }
                    $error['success'] = true;
                    $error['r_link'] = base_url('products');
                }
            }
			else{
				foreach ($_POST as $key => $value) {
					$error['message'][$key] = form_error($key);
				}
			}

			echo json_encode($error);
		}
        
        public function select_product($id){
            if (!$id) {echo '<p class="alert alert-danger">No match found</p>';}
			$prd = $this->mymodel->get_1('*', 'products', array('id' =>$id));
            if($prd){
               $cat = $this->mymodel->get_1('category_title', 'category', array('category_id'=>$prd->category_id));
                $scat = $this->mymodel->get_1('title', 'subcategory', array('subcategory_id'=>$prd->subcategory_id));
                $sscat = $this->mymodel->get_1('title', 'sub_subcategory', array('subcategory_id'=>$prd->sub_subcategory));
                $img = $this->mymodel->get_1('*', 'product_image', array('product_id'=>$prd->id));
                if($img){$imag_lnk = $img->image_link; }else{
                    $imag_lnk = 'default.png';
                }
                    
        ?>
            
            <div class="col-md-4">
                <img src="<?= base_url('../asset/images/products/'.$imag_lnk); ?>" style="width:100%;">
                <input type="hidden" name="prds_id" value="<?= $prd->id; ?>">
                <input type="hidden" name="product_name" value="<?= $prd->title; ?>">
            </div>
            <div class="col-md-8">
                <h3><?= $prd->title; ?></h3>
                <h4><?= $prd->heading_line; ?></h4>
                <p>
                    <label class="label label-success-border"><?= $cat->category_title; ?></label> <i class="fa fa-angle-right"></i>
                    <label class="label label-success-border"><?= $scat->title; ?></label> <i class="fa fa-angle-right"></i>
                    <label class="label label-success-border"><?= $sscat->title; ?></label> 
                </p>
                <p>Price : Rs- <?= $prd->price; ?> </p>
            </div>
        <?php
                }
            else{
                echo '<p class="alert alert-danger">No match found</p>';
            }
        }  

        public function vendor_product(){
            $error = array('success'=>false, 'message'=>array());
            $this->load->library('form_validation');
			$form_data = $this->input->post();
			$this->form_validation->set_error_delimiters('<p>','</p>');
			$this->form_validation->set_rules('product_name', 'Product', 'required');
			$this->form_validation->set_rules('prds_id', 'Product', 'required');
			$this->form_validation->set_rules('qyantity', 'Quantity', 'required|is_natural');
			$this->form_validation->set_rules('vendor_id', 'Vendor', 'required|is_natural');
			$this->form_validation->set_rules('delivery_price', 'Delivary charge', 'required|is_natural');
			$this->form_validation->set_rules('vendor_price', 'Vendor Price', 'required|is_natural');

			if($this->form_validation->run()){
				//strart image validation
                if($form_data['approv_status'] == 'APPROVE'){ $app_date = date('Y-m-d H:i');}else{$app_date = null;}
				$vdata = array(
                    'vender_id' => $form_data['vendor_id'],
                    'product_id' => $form_data['prds_id'],
                    'vendors_price' => $form_data['vendor_price'],
                    'shipping_charge' => $form_data['delivery_price'],
                    'create_date' => date('Y-m-d H:i'),
                    'approval' => $form_data['approv_status'],
                    'approval_date' => $app_date,
                    'display_status' => $form_data['display_status'],
                    'comment' => $form_data['comment'],
                    'quantity' => $form_data['qyantity']
                );

                $prd_id = $this->mymodel->insert_data('vendors_products', $vdata);
                if($prd_id){
                    //multiple images
                    $error['success'] = true;
                    $error['r_link'] = base_url('products');
                }
            }
			else{
				foreach ($_POST as $key => $value) {
					$error['message'][$key] = form_error($key);
				}
			}

			echo json_encode($error);
        }

		public function edits(){
			$error = array('success'=>false, 'message'=>array());
            $this->load->library('form_validation');
			$form_data = $this->input->post();
			$this->form_validation->set_error_delimiters('<p>','</p>');
			$this->form_validation->set_rules('category_id', 'Category', 'required');
			$this->form_validation->set_rules('subcategory_id', 'Sub category', 'required');
			$this->form_validation->set_rules('sub_subcategory_id', 'Sub sub-category', 'required');
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('sku', 'SKU', 'required');
			$this->form_validation->set_rules('hline', 'Heading', 'required');
			$this->form_validation->set_rules('mrp', 'MRP Price', 'required|is_natural');
			$this->form_validation->set_rules('price', 'Price', 'required|is_natural');
			$this->form_validation->set_rules('brand', 'Brand', 'required|is_natural');
			$this->form_validation->set_rules('short_dtl', 'Highlights', 'required');
			$this->form_validation->set_rules('detail', 'Description', 'required');

			if($this->form_validation->run()){
				//strart image validation
				$data = array(
                    'title' => $form_data['title'],
                    'heading_line' => $form_data['hline'],
                    'sku' => $form_data['sku'],
                    'brand_id' => $form_data['brand'],
                    'category_id' => $form_data['category_id'],
                    'subcategory_id' => $form_data['subcategory_id'],
                    'sub_subcategory' => $form_data['sub_subcategory_id'],
                    'price' => $form_data['price'],
                    'mrp' => $form_data['mrp'],
                    'short_details' => $form_data['short_dtl'],
                    'detail' => $form_data['detail'],
                    'create_date' => date('Y-m-d H:i')
                );

                $prd_id = $this->mymodel->update('products',array('id'=>$form_data['prdid']), $data);
                if($prd_id){
                    //multiple images
                    
                    if($_FILES){
                        $this->load->library('upload');
                        $config = [
                            'upload_path' => './../asset/images/products/',
                            'allowed_types' => 'jpg|png|gif|jpeg',
                            'encrypt_name' => TRUE
                        ];
                        $files = $_FILES;
                        $cpt = count($_FILES['userfile']['name']);
                        for($i=0; $i<$cpt; $i++)
                        {
                            $_FILES['userfile']['name']= $files['userfile']['name'][$i];
                            $_FILES['userfile']['type']= $files['userfile']['type'][$i];
                            $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
                            $_FILES['userfile']['error']= $files['userfile']['error'][$i];
                            $_FILES['userfile']['size']= $files['userfile']['size'][$i]; 

                            $this->upload->initialize($config);
                            if($this->upload->do_upload()){
                                $dataInfo = $this->upload->data();
                                $this->mymodel->insert_data('product_image', array('product_id'=>$form_data['prdid'], 'image_link'=>$dataInfo['file_name']));
                                
                            }
                        }
                    }
				//end image validation
                    $this->mymodel->delete('product_property', array('product_id'=>$form_data['prdid']));
                    if(isset($_REQUEST['prop'])){
                        $prop = $_REQUEST['prop'];
                        $s = count($prop);
                        for($i=1; $i<=$s; $i++){
                            $attr_id = $this->mymodel->get_1('*', 'attribute_property', array('id' =>$prop[$i-1]));
                            $this->mymodel->insert_data('product_property', array('attribute_id'=>$attr_id->attribute_id, 'property_id'=>$prop[$i-1], 'product_id'=>$form_data['prdid']));
                        }
                    }
                    $error['success'] = true;
                    $error['r_link'] = base_url('products');
                }
            }
			else{
				foreach ($_POST as $key => $value) {
					$error['message'][$key] = form_error($key);
				}
			}

			echo json_encode($error);
		}

		public function delete(){
			$error = array('success'=>false, 'message'=>array());
			$form_data = $this->input->post();
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<p>','</p>');
			$this->form_validation->set_rules('delete_id', 'Products', 'required|is_natural');
			if($this->form_validation->run()){
				if($this->mymodel->delete('products', array('id'=>$form_data['delete_id'])))	{
					$error['success'] = true;
					$error['msg'] = 'Product deleted successfully';
				}
				else{
					$error['message']['title'] = '<p>Error in submiting data</p>';
				}
			}
			else{
				$error['message'][$key] = form_error($key);
			}
			echo json_encode($error);
		}
        
        public function removeimg($id){
			if($this->mymodel->delete('product_image', array('id'=>$id)))	{
               echo 'ok';
            }
            else{
                $error['message']['title'] = '<p>Error in submiting data</p>';
            }
		}

		public function edit($id){
			if (!$id) {return redirect('products');}
			$lst = $this->mymodel->get_1('*', 'products', array('id' =>$id));
			$this->load->view('admin/product_edit', array('list'=>$lst));
		}

		public function fetch_subcategory($id){
			$subcat = $this->mymodel->select_all_where('*', array('category_id'=>$id), 'subcategory');
			if($subcat){
				echo '<option value="">Select</option>';
				foreach ($subcat as $key) {
					echo '<option value="'.$key->subcategory_id.'">'.$key->title.'</option>';
				}
			}
			else{
				echo '<option value="">NO Sub category found</option>';
			}
		}
		public function fetch_sub_subcategory($id){
			$subcat = $this->mymodel->select_all_where('*', array('subcategory_id'=>$id), 'sub_subcategory');
			if($subcat){
				echo '<option value="">Select</option>';
				foreach ($subcat as $key) {
					echo '<option value="'.$key->id.'">'.$key->title.'</option>';
				}
			}
			else{
				echo '<option value="">NO Sub category found</option>';
			}
		}
	}