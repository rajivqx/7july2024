<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->view('admin/login');
	}
	public function forgot_password()
	{
		$this->load->view('admin/forgot-password');
	}

	public function signin(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('username', 'user name', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		if($this->form_validation->run()){
			$sql = $this->mymodel->get_1('admin_id, admin_name', 'admin_list', '(admin_email="'.$form_data['username'].'" or admin_mobile="'.$form_data['username'].'") and admin_password="'.$form_data['password'].'"');
				if($sql){
					$this->session->set_userdata('admin_id', $sql->admin_id);
					$this->session->set_userdata('admin_name', $sql->admin_name);
					$error['success'] = true;
				}
				else{
					$error['message']['username'] = '<p>Invaild login detail, please try again</p>';
				}
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function __construct(){
		parent::__construct();
		if($this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}


}
