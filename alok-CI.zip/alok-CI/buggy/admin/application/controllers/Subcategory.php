<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class subcategory extends CI_Controller {

	public function index()
	{
		$lst = $this->mymodel->select_all('*', 'subcategory', 'subcategory_id', 'desc');
		$this->load->view('admin/subcategory', array('list'=>$lst));
	}

	public function add(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'Category name', 'required');
		$this->form_validation->set_rules('position', 'Position', 'required|is_natural');
		$this->form_validation->set_rules('category_id', 'Category', 'required|is_natural');

		if($this->form_validation->run()){

			$data = array(
				'title' => $form_data['title'],
				'category_id' => $form_data['category_id'],
				'detail' => $form_data['detail'],
				'position' => $form_data['position'],
				'status' => $form_data['status']
			);
			if($this->mymodel->insert_data('subcategory', $data))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}

	public function delete(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('delete_id', 'Category', 'required|is_natural');
		if($this->form_validation->run()){
			if($this->mymodel->delete('subcategory', array('subcategory_id'=>$form_data['delete_id'])))	{
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}
		}
		else{
			$error['message'][$key] = form_error($key);
		}
		echo json_encode($error);
	}

	public function edit($id){
		if(!$id){return redirect(base_url('subcategory'));}
		$lst = $this->mymodel->get_1('*', 'subcategory', array('subcategory_id' =>$id));
		$this->load->view('admin/subcategory_edit', array('list'=>$lst));
	}
	public function edit_sub(){
		$error = array('success'=>false, 'message'=>array());
		$form_data = $this->input->post();
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p>','</p>');
		$this->form_validation->set_rules('title', 'Category name', 'required');
		$this->form_validation->set_rules('position', 'Position', 'required|is_natural');
		$this->form_validation->set_rules('category_id', 'Category', 'required|is_natural');

		if($this->form_validation->run()){

			$data = array(
				'title' => $form_data['title'],
				'category_id' => $form_data['category_id'],
				'detail' => $form_data['detail'],
				'position' => $form_data['position'],
				'status' => $form_data['status']
			);
			if($this->mymodel->update('subcategory', array('subcategory_id'=>$form_data['edit_id']), $data))	{
				$error['success'] = true;
				$error['msg'] = "Subcategory updated sucsessfully";
				$error['r_link'] = base_url('subcategory');
				$error['success'] = true;
			}
			else{
				$error['message']['title'] = '<p>Error in submiting data</p>';
			}		
		}
		else{
			foreach ($_POST as $key => $value) {
				$error['message'][$key] = form_error($key);
			}
		}

		echo json_encode($error);
	}
	

	public function fetch_subcategory($id){
		$subcat = $this->mymodel->select_all_where('*', array('category_id'=>$id), 'subcategory');
		if($subcat){
			foreach ($subcat as $key) {
				echo '<option value="'.$key->subcategory_id.'">'.$key->title.'</option>';
			}
		}
		else{
			echo '<option value="">NO Sub category found</option>';
		}
	}

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('admin_id')){
			return redirect(base_url('home'));
		}
	}

}