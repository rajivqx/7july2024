<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Project - HRMS admin template</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/dataTables.bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap-datetimepicker.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
            <?php include('comman/side.php'); ?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-4">
							<h4 class="page-title">Products</h4>
						</div>
						<div class="col-sm-8 text-right m-b-20">
							<a href="<?= base_url('products/addnew'); ?>" class="btn btn-primary rounded pull-right"><i class="fa fa-plus"></i> Create Product</a>
						</div>
					</div>
					<div class="row filter-row">
						<div class="col-sm-3 col-xs-6">  
							<div class="form-group form-focus">
								<label class="control-label">Project Name</label>
								<input type="text" class="form-control floating" />
							</div>
						</div>
						<div class="col-sm-3 col-xs-6">  
							<div class="form-group form-focus">
								<label class="control-label">Employee Name</label>
								<input type="text" class="form-control floating" />
							</div>
						</div>
						<div class="col-sm-3 col-xs-6"> 
							<div class="form-group form-focus select-focus">
								<label class="control-label">Role</label>
								<select class="select floating"> 
									<option value="">Select Roll</option>
									<option value="">Web Developer</option>
									<option value="1">Web Designer</option>
									<option value="1">Android Developer</option>
									<option value="1">Ios Developer</option>
								</select>
							</div>
						</div>
						<div class="col-sm-3 col-xs-6">  
							<a href="#" class="btn btn-success btn-block"> Search </a>  
						</div>     
                    </div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table datatable">
									<thead>
										<tr>
											<th>Image</th>
											<th>Name</th>
											<th>SKU</th>
											<th>Category Details</th>
											<th>price</th>
											<th>Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											foreach ($list as $prd) { 
												$cat = $this->mymodel->get_1('category_title', 'category', array('category_id'=>$prd->category_id));
												$scat = $this->mymodel->get_1('title', 'subcategory', array('subcategory_id'=>$prd->subcategory_id));
												$sscat = $this->mymodel->get_1('title', 'sub_subcategory', array('id'=>$prd->sub_subcategory));
                                                $img = $this->mymodel->get_1('*', 'product_image', array('product_id'=>$prd->id));
                                                if($img){$imag_lnk = $img->image_link; }else{
                                                    $imag_lnk = 'default.png';
                                                }
										?>
										<tr>
											<td><img src="<?= base_url('../asset/images/products/'.$imag_lnk); ?>" style="height: 50px; width: 50px;"></td>
											<td>
												<h2><a href="#"><?= $prd->title; ?></a></h2>
											</td>
                                            <td>
												<?= $prd->sku; ?>
											</td>
											<td>
                                                <?= $cat->category_title; ?> <i class="fa fa-angle-right"></i>
                                                <?= $scat->title; ?> <i class="fa fa-angle-right"></i>
                                                <?= $sscat->title; ?>
                                            </td>
											<td><?= $prd->price; ?> </td>
											
											<td>
												<div class="dropdown action-label">
													<a class="btn btn-white btn-sm rounded dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-dot-circle-o text-success"></i> Active <i class="caret"></i></a>
													<ul class="dropdown-menu">
														<li><a href="#"><i class="fa fa-dot-circle-o text-success"></i> Active</a></li>
														<li><a href="#"><i class="fa fa-dot-circle-o text-danger"></i> Inactive</a></li>
													</ul>
												</div>
											</td>
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="<?= base_url('products/edit/'.$prd->id); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" data-id="<?= $prd->id; ?>" class="delet-btn" data-toggle="modal" data-target="#delete_project"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
													</ul>
												</div>
											</td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
				
            </div>
			
			<div id="delete_project" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Delete Project</h4>
						</div>
						<form action="<?= base_url('products/delete'); ?>" class="form-submit">
							<div class="modal-body card-box">
								<p>Are you sure want to delete this?</p>
								<input type="hidden" name="delete_id" value="">
								<div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-danger">Delete</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/moment.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap-datetimepicker.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>

		<script type="text/javascript" src="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.min.js"></script>
		 <script>
			$(document).ready(function(){
				$('.summernote').summernote({
					height: 200,                 // set editor height
					minHeight: null,             // set minimum height of editor
					maxHeight: null,             // set maximum height of editor
					focus: false                 // set focus to editable area after initializing summernote
				});
			});
        </script>
    </body>
   
<script>
	function getSUb(str){
		$('.preloader').show();
		$.ajax({
			url: "<?= base_url('products/fetch_subcategory/'); ?>"+str,
			success : function(result){
				$('select[name=subcategory_id]').html(result);
				$('.preloader').hide();
			}
		});
	}

	function getSUbsub(str){
		$('.preloader').show();
		$.ajax({
			url: "<?= base_url('products/fetch_sub_subcategory/'); ?>"+str,
			success : function(result){
				$('select[name=sub_subcategory_id]').html(result);
				$('.preloader').hide();
			}
		});
	}

</script>
</html>