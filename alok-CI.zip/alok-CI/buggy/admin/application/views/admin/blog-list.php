<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Blog - Buggysale.com admin panel</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/dataTables.bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap-datetimepicker.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
            <?php include('comman/side.php'); ?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-4">
							<h4 class="page-title">Blogs</h4>
						</div>
						<div class="col-sm-8 text-right m-b-20">
							<a href="<?= base_url('blog/addblog'); ?>" class="btn btn-primary rounded pull-right"><i class="fa fa-plus"></i> Create blog</a>
						</div>
					</div>
					<div class="row filter-row">
						<div class="col-sm-6 col-xs-6 col-sm-offset-3">  
							<div class="form-group form-focus">
								<label class="control-label">Blog</label>
								<input type="text" class="form-control floating" />
							</div>
						</div>
						
						<div class="col-sm-3 col-xs-6">  
							<a href="#" class="btn btn-success btn-block"> Search </a>  
						</div>     
                    </div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table datatable">
									<thead>
										<tr>
											<th>Image</th>
											<th>Title</th>
											<th>Create Date</th>
											<th>Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											foreach ($list as $blg) { 
										?>
										<tr>
											<td><img src="<?= base_url('../asset/images/blog/'.$blg->image); ?>" style="height: 50px; width: 50px;"></td>
											<td>
												<h2><a href="#"><?= $blg->title; ?></a></h2>
											</td>
                                            
											<td><?= $blg->create_date; ?> </td>
											
											<td>
												<div class="dropdown action-label">
													<a class="btn btn-white btn-sm rounded dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-dot-circle-o text-success"></i> <?= $blg->status; ?> <i class="caret"></i></a>
													
												</div>
											</td>
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="<?= base_url('blog/edit/'.$blg->id); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" data-id="<?= $blg->id; ?>" class="delet-btn" data-toggle="modal" data-target="#delete_project"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
													</ul>
												</div>
											</td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
				
            </div>
						
			<div id="delete_project" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Delete Project</h4>
						</div>
						<form action="<?= base_url('blog/delete'); ?>" class="form-submit">
							<div class="modal-body card-box">
								<p>Are you sure want to delete this?</p>
								<input type="hidden" name="delete_id" value="">
								<div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-danger">Delete</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/moment.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap-datetimepicker.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>

		<script type="text/javascript" src="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.min.js"></script>
		 <script>
			$(document).ready(function(){
				$('.summernote').summernote({
					height: 200,                 // set editor height
					minHeight: null,             // set minimum height of editor
					maxHeight: null,             // set maximum height of editor
					focus: false                 // set focus to editable area after initializing summernote
				});
			});
        </script>
    </body>
   
<script>
	function getSUb(str){
		$('.preloader').show();
		$.ajax({
			url: "<?= base_url('products/fetch_subcategory/'); ?>"+str,
			success : function(result){
				$('select[name=subcategory_id]').html(result);
				$('.preloader').hide();
			}
		});
	}

	function getSUbsub(str){
		$('.preloader').show();
		$.ajax({
			url: "<?= base_url('products/fetch_sub_subcategory/'); ?>"+str,
			success : function(result){
				$('select[name=sub_subcategory_id]').html(result);
				$('.preloader').hide();
			}
		});
	}

</script>
</html>