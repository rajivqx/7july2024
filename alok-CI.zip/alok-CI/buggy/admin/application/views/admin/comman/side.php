<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
		<div id="sidebar-menu" class="sidebar-menu">
			<ul>
				<li class="active"> 
					<a href="<?= base_url(); ?>">Dashboard</a>
				</li>
				<!-- <li class="submenu">
					<a href="#" class="noti-dot"><span> Employees</span> <span class="menu-arrow"></span></a>
					<ul class="list-unstyled" style="display: none;">
						<li><a href="employees.html">All Employees</a></li>
						<li><a href="holidays.html">Holidays</a></li>
						<li><a href="leaves.html"><span>Leave Requests</span> <span class="badge bg-primary pull-right">1</span></a></li>
						<li><a href="attendance.html">Attendance</a></li>
						<li><a href="departments.html">Departments</a></li>
						<li><a href="designations.html">Designations</a></li>
					</ul>
				</li> -->
                <li> 
					<a href="<?= base_url('banner'); ?>">Banners</a>
				</li>
				<li> 
					<a href="<?= base_url('category'); ?>">Category</a>
				</li>
				<li> 
					<a href="<?= base_url('subcategory'); ?>">Sub category</a>
				</li>
				<li> 
					<a href="<?= base_url('sub_subcategory'); ?>">Sub Subcategory</a>
				</li>
				<li> 
					<a href="<?= base_url('Brands'); ?>">Brands</a>
				</li>
                <li> 
					<a href="<?= base_url('vendor'); ?>">Vendor</a>
				</li>
				<li> 
					<a href="<?= base_url('products'); ?>">Product</a>
				</li>
				<li> 
					<a href="<?= base_url('attributes'); ?>">Attributes</a>
				</li>
                <li> 
					<a href="<?= base_url('orders'); ?>">Orders</a>
				</li>
                <li> 
					<a href="<?= base_url('customers'); ?>">Customers</a>
				</li>
                <li> 
					<a href="<?= base_url('newsletter'); ?>">Newsletters</a>
				</li>
                <li> 
					<a href="<?= base_url('blog'); ?>">Blog</a>
				</li>
                <li> 
					<a href="<?= base_url('review'); ?>">Reviews</a>
				</li>
			</ul>
		</div>
    </div>
</div>
<div class="preloader">
	<img src="<?= base_url('asset/img/preloader.gif'); ?>">
</div>