<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Sub subcategory - Admin panel</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
             <?php include('comman/side.php'); ?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-8 col-xs-6">
							<h4 class="page-title">Sub Subcategory</h4>
						</div>
						<div class="col-sm-4 col-xs-6 text-right m-b-30">
							<a href="<?= base_url('sub_subcategory'); ?>" class="btn btn-primary rounded"><i class="fa fa-reply"></i> Back</a>
						</div>
					</div>
					<div class="row">
						<div class="col-md-8 col-md-offset-2">
							<div class="modal-body">
							<?= form_open_multipart(base_url('sub_subcategory/edit_subx'), array('class'=>'form-submit')); ?>
								<div class="col-md-12">
									<div class="form-group">
										<label>Sub Sub-category <span class="text-danger">*</span></label>
										<input class="form-control" required="" type="text" name="title" value="<?= $list->title; ?>">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label>Detail <span class="text-danger">*</span></label>
										<textarea class="form-control" required="" name="detail"><?= $list->detail; ?></textarea>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Category <span class="text-danger">*</span></label>
										<select class="select" name="category_id"  onchange="getSUb(this.value)">
											<option value="">Select category</option>
											<?php
												$cates = $this->mymodel->select_all('*', 'category', 'category_id', 'desc');
												foreach($cates as $cat ){
											?>
											<option value="<?= $cat->category_id; ?>" <?php if($list->category_id == $cat->category_id){echo 'selected';}?>><?= $cat->category_title; ?></option>
											<?php } ?>
										</select>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Sub Category <span class="text-danger">*</span></label>
										<select class="select" name="subcategory_id">
											<option value="">Select subcategory</option>
											<?php
												$catesa = $this->mymodel->select_all('*', 'subcategory', 'subcategory_id', 'desc');
												foreach($catesa as $scat ){
											?>
											<option value="<?= $scat->subcategory_id; ?>" <?php if($list->subcategory_id == $scat->subcategory_id){echo 'selected';}?>><?= $scat->title; ?></option>
											<?php } ?>
										</select>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>position <span class="text-danger">*</span></label>
										<input class="form-control" required="" type="text" name="position" value="<?= $list->position; ?>">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Status <span class="text-danger">*</span></label>
										<input type="hidden" name="edit_id" value="<?= $list->id; ?>">
										<select class="form-control" name="status">
											<option value="ACTIVE" <?php if($list->status == 'ACTIVE'){echo 'selected';}?>>Active</option>
											<option value="INACTIVE" <?php if($list->status == 'INACTIVE'){echo 'selected';}?>>Inactive</option>
										</select>
									</div>
									
								</div>
								<div class="clearfix"></div>

								<div class="m-t-20 text-center">
									<button class="btn btn-primary">Edit Now</button>
								</div>
							<?= form_close(); ?>
						</div>
						</div>
					</div>
                </div>
				
            </div>

        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>
		<script>
			function getSUb(str){
				$('.preloader').show();
				$.ajax({
					url: "<?= base_url('subcategory/fetch_subcategory/'); ?>"+str,
					success : function(result){
						$('select[name=subcategory_id]').html(result);
						$('.preloader').hide();
					}
				});
			}

		</script>
</body>
</html>