<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
    <title>Reviews : Buggysale-Admin Panel</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!--[if lt IE 9]>
        <script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
        <script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
    <![endif]-->
</head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
            <?php include('comman/side.php'); ?>
           
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-4 col-xs-3">
							<h4 class="page-title">Reviews</h4>
						</div>
						<div class="col-sm-8 col-xs-9 text-right m-b-20">
							
							
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table datatable">
									<thead>
										<tr>
                                            <td>#</td>
											<th>Product</th>
											<th>date</th>
											<th>Rating</th>
											<th>Comment</th>
                                            <th>Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php
                                        $sn = 1;
											foreach ($list as $cst) { ?>
										<tr>
											<td><?= $sn++; ?></td>
											<td><?= $cst->product_id; ?></td>
											<td><?= date('d M y', strtotime($cst->create_date)); ?></td>
											<td><?= $cst->rating; ?></td>
                                            <td><h5><?= $cst->title; ?></h5><p><?= $cst->detail; ?></p></td>
											<td>
												<div class="dropdown action-label">
													<a class="btn btn-white btn-sm rounded dropdown-toggle" href="#" >
														<?php
															if($cst->status == 'SHOW'){ 
																echo '<i class="fa fa-dot-circle-o text-success"></i> SHOW ';
															}
															else{
																echo '<i class="fa fa-dot-circle-o text-danger"></i> HIDE ';
															}
														?>
													</a>
													
												</div>
											</td>
                                            <td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li>
                                                            <a href="#" class="edit_box" data-toggle="modal" data-target="#edit_box" data-id="<?= $cst->id; ?>" data-title="<?= $cst->title; ?>" data-rate="<?= $cst->rating; ?>" data-info="<?= $cst->detail; ?>" data-status="<?= $cst->status; ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                        </li>
														<li>
                                                            <a href="#" data-toggle="modal" data-target="#delete_box" data-id="<?= $cst->id; ?>" class="delet-btn" title="Delete"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                        </li>
													</ul>
												</div>
											</td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
				
            </div>
			<script>
                $(document).ready(function(){
                    $('.edit_box').click(function(e){
                        e.preventDefault();
                        var ml = $(this);
                        $('input[name=title]').val(ml.data('title'));
                        $('input[name=id]').val(ml.data('id'));
                        $('input[name=comment]').val(ml.data('info'));
                        $('input[name=ratting]').val(ml.data('rate'));
                        $('select[name=status]').val(ml.data('status'));
                    });
                });
			</script>
			<div id="edit_box" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Update Review</h4>
						</div>
						<form action="<?= base_url('review/edit'); ?>" class="form-submit">
							<div class="modal-body card-box">
                                
                                <div class="form-group col-md-12">
                                    <label>Title</label>
                                    <input name="title" type="text" class="form-control" value="">
                                    <input name="id" type="hidden" value="">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Comment</label>
                                    <input name="comment" type="text" class="form-control" value="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Ratting</label>
                                    <input name="ratting" type="text" class="form-control" value="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Status</label>
                                    <select class="form-control" name="status">
                                        <option>Select</option>
                                        <option value="HIDE">Hide</option>
                                        <option value="SHOW">Show</option>
                                    </select>
                                </div>
                                <div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-info">Update</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
            
            <div id="delete_box" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Delete Email</h4>
						</div>
						<form action="<?= base_url('newsletter/delete'); ?>" class="form-submit">
							<div class="modal-body card-box">
								<p>Are you sure want to delete this?</p>
								<input type="hidden" name="delete_id" value="">
								<div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-danger">Delete</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/moment.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>
    </body>

<!-- Mirrored from dreamguys.co.in/smarthr/purple/clients-list.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 Aug 2018 10:00:27 GMT -->
</html>