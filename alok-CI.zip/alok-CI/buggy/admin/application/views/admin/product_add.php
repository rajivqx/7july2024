<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Add new products - Admin panel</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
            <!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
        <style>
            .add_prdfrm, #vendor-prods{
                display: none;
            }
            .prv-img {
                width: 100px;
                height: 90px;
                margin: 4px;
                border: 1px solid #ccc;
            }
            .attr-prop {
                border: 1px solid #ccc;
                padding: 1px 0px 12px 12px;
                background: white;
                margin-bottom: 5px;
            }
        </style>
        
        <script>
            function ShowID(str){
                $(str).show();
                $('#vendor-prods').hide();
            }
            
            function seachPrd(str){
                if(str.length > 2){
                    $.ajax({
                        url: '<?= base_url('products/search/'); ?>'+str,
                        success: function(result){
                            $('.add_prdfrm').hide();
                            $('.search-box').html(result);
                        }
                    });
                }else{
                    $('.search-box').html(null);
                }
            }
            
            
            function selectProduct(prdid){
                 $.ajax({
                    url: '<?= base_url('products/select_product/'); ?>'+prdid,
                    success: function(result){
                        $('#product_vendor').html(result);
                        $('#vendor-prods').show();
                         $('.search-box').html(null);
                    }
                });
            }
        </script>
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
            <?php include('comman/side.php'); ?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-8 col-xs-6">
							<h4 class="page-title">Product Listing</h4>
						</div>
						<div class="col-sm-4 col-xs-6 text-right m-b-30">
							<a href="<?= base_url('products'); ?>" class="btn btn-primary rounded"><i class="fa fa-reply"></i> Back</a>
						</div>
                        <?= form_open_multipart(base_url('products/search'), array('class'=>'form-submit')); ?>
                            <div class="row filter-row">
                                <div class="col-sm-7 col-xs-6 col-sm-offset-1">  
                                    <div class="form-group form-focus">
                                        <label class="control-label">Search products ny name, Product Id, etc</label>
                                        <input type="text" class="form-control floating" onkeyup="seachPrd(this.value)">
                                    </div>
                                    
                                    <div class="search-box">
                                        
                                    </div>
                                </div>
                                <div class="col-sm-1 col-xs-6">  
                                    <p class="text-center m-t-15">OR</p> 
                                </div>
                                <div class="col-sm-3 col-xs-6">  
                                    <a href="#" class="btn btn-info rounded block" onclick="ShowID('.add_prdfrm')"> Add </a>  
                                </div>
                            </div>
                        <?= form_close();?>  
                        
					</div>
					<div class="row">
						<div class="col-md-10 col-md-offset-1">
							<div class="modal-body">
							<?= form_open_multipart(base_url('products/add'), array('class'=>'form-submit add_prdfrm form-horizontal')); ?>
                                
                                <div class="row">
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Category:</label>
                                        <div class="col-sm-9">
                                            <select class="select" name="category_id" onchange="getSUb(this.value)">
												<option value="0">Select category</option>
												<?php
													$cats = $this->mymodel->select_all('*', 'category', 'category_title', 'asc');
													foreach ($cats as $cat) {
												?>
													<option value="<?= $cat->category_id ?>"><?= $cat->category_title ?></option>
												<?php	} ?>
												
											</select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Sub Category:</label>
                                        <div class="col-sm-9">
                                            <select class="select" name="subcategory_id" onchange="getSUbsub(this.value)">
												<option value="">Select sub category</option>
												<?php
													$scats = $this->mymodel->select_all('*', 'subcategory', 'subcategory_id', 'desc');
													foreach ($scats as $cat) {
												?>
													<option value="<?= $cat->subcategory_id ?>"><?= $cat->title ?></option>
												<?php	} ?>

											</select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Sub sub-Category:</label>
                                        <div class="col-sm-9">
                                            <select class="select" name="sub_subcategory_id">
												<option value="">Select  sub category</option>
												<?php
													$cats = $this->mymodel->select_all('*', 'sub_subcategory', 'id', 'desc');
													foreach ($cats as $cat) {
												?>
													<option value="<?= $cat->id ?>"><?= $cat->title ?></option>
												<?php	} ?>
											</select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Product Name:</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="text" name="title">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Heading line:</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="text" name="hline">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">SKU:</label>
                                        <div class="col-sm-5">
                                            <input class="form-control" type="text" name="sku">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">MRP:</label>
                                        <div class="col-sm-5">
                                            <input class="form-control" type="text" name="mrp">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Sell Price:</label>
                                        <div class="col-sm-5">
                                            <input class="form-control" type="text" name="price">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Select Brand</label>
                                        <div class="col-sm-5">
                                            <select class="select" name="brand">
                                                <option value="">Select  Brand</option>
                                                <?php
													$brand = $this->mymodel->select_all('*', 'brands', 'title', 'asc');
													foreach ($brand as $brnd) {
												?>
													<option value="<?= $brnd->id ?>"><?= $brnd->title ?></option>
												<?php	} ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Attributes</label>
                                        <div class="col-md-9">
                                            <div id="attr-prop">
                                            </div>
                                            <div class="col-sm-5">
                                                <select class="select" name="add_attrb">
                                                    <option value="0">Select</option>
                                                    <?php
                                                        $brand = $this->mymodel->select_all('*', 'attributes', 'name', 'asc');
                                                        foreach ($brand as $brnd) {
                                                    ?>
                                                        <option value="<?= $brnd->id ?>"><?= $brnd->name ?></option>
                                                    <?php	} ?>

                                                </select>
                                            </div>
                                            <div class="col-sm-3">
                                                <a class="btn btn-info" onclick="addprop()">Add</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
									<label>Highlights</label>
									<textarea rows="4" cols="5" class="form-control summernote" name="short_dtl" placeholder="Enter your message here"></textarea>
								</div>
                                
                                <div class="form-group">
									<label>Description</label>
									<textarea rows="4" cols="5" class="form-control summernote" name="detail" placeholder="Enter your message here"></textarea>
								</div>
                                 
								<div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Upload Files</label>
                                            <input class="form-control" multiple type="file" name="userfile[]" onchange="imagesPreview(this, '#preview-img')">
                                            <p><sub class="text-danger">*Image size must be 570*500 px</sub></p>
                                        </div>
                                    </div>
									
									<div class="col-md-6">
										<div id="preview-img"></div>
									</div>
								</div>
                                
                                <div class="row">
                                    <h4>Vendor details</h4>
                                    <hr>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Vendor</label>
                                            <select class="select" name="vendor">
                                                <option value="">Select Vendor</option>
                                                <?php
                                                    $vender = $this->mymodel->select_all('*', 'vendors', 'id', 'asc');
                                                    foreach ($vender as $vndr) {
                                                ?>
                                                <option value="<?= $vndr->id; ?>"><?= $vndr->company_name?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Vendor Price</label>
                                            <input type="text" name="v_price" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Delivery charge</label>
                                            <input type="text" name="d_price" class="form-control">
                                        </div>
                                    </div>
                                     <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Quantity</label>
                                            <input type="text" name="qty" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Approval status</label>
                                            <select class="select" name="approvel">
                                                <option value="PENDING">Pending</option>
                                                <option value="APPROVE">Approve</option>
                                                <option value="INPROCESS">In Process</option>
                                                <option value="REJECT">Reject</option>
                                            </select>
                                        </div>
                                    </div>   
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Display status</label>
                                            <select class="select" name="display">
                                                <option value="SHOW">Show</option>
                                                <option value="HIDE">Hide</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Comments</label>
                                            <textarea class="form-control" name="comments"></textarea>
                                        </div>
                                    </div>
                                    
                                </div>
								
								<div class="m-t-20 text-center">
									<button class="btn btn-primary" type="submit">Add product</button>
								</div>
							<?= form_close(); ?>
                                
                                <form class="form-submit" action="<?= base_url('products/vendor_product'); ?>" id="vendor-prods">
                                    <div id="product_vendor" class="row">
                                        
                                    </div>
                                    <div class="row">
                                        <hr>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Vendor</label>
                                                <select class="select" name="vendor_id">
                                                    <option value="">Select Vendor</option>
                                                    <?php
                                                        $vender = $this->mymodel->select_all('*', 'vendors', 'id', 'asc');
                                                        foreach ($vender as $vndr) {
                                                    ?>
                                                    <option value="<?= $vndr->id; ?>"><?= $vndr->company_name?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Vendor Price</label>
                                                <input type="text" name="vendor_price" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Delivery charge</label>
                                                <input type="text" name="delivery_price" class="form-control">
                                            </div>
                                        </div>
                                         <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Quantity</label>
                                                <input type="text" name="qyantity" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Approval status</label>
                                                <select class="select" name="approv_status">
                                                    <option value="PENDING">Pending</option>
                                                    <option value="APPROVE">Approve</option>
                                                    <option value="INPROCESS">In Process</option>
                                                    <option value="REJECT">Reject</option>
                                                </select>
                                            </div>
                                        </div>   

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Display status</label>
                                                <select class="select" name="display_status">
                                                    <option value="SHOW">Show</option>
                                                    <option value="HIDE">Hide</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Comments</label>
                                                <textarea class="form-control" name="comment"></textarea>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="m-t-20 text-center">
                                        <button class="btn btn-primary" type="submit">Add product</button>
                                    </div>
                                </form>
						  </div>
						</div>
					</div>
                </div>
				
            </div>

        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>
		<script>
			$(document).ready(function(){
				$('.summernote').summernote({
					height: 200,                 // set editor height
					minHeight: null,             // set minimum height of editor
					maxHeight: null,             // set maximum height of editor
					focus: false                 // set focus to editable area after initializing summernote
				});
			});
            
            function  imagesPreview(input, str){
                if (input.files) {
                    var filesAmount = input.files.length;

                    for (i = 0; i < filesAmount; i++) {
                        var reader = new FileReader();

                        reader.onload = function(event) {
                            $($.parseHTML('<img class="prv-img">')).attr('src', event.target.result).appendTo(str);
                        }

                        reader.readAsDataURL(input.files[i]);
                    }
                }
            }
            
            function addprop(){
                var id = $('select[name=add_attrb]').val();
                $('option:selected', 'select[name=add_attrb]').remove();
                $.ajax({
                    url: '<?= base_url('attributes/fetch/')?>'+id,
                    success: function(result){
                        $('#attr-prop').append(result);
                        
                    }
                });
            }
            
        </script>
		<script>
			function getSUb(str){
				$('.preloader').show();
				$.ajax({
					url: "<?= base_url('products/fetch_subcategory/'); ?>"+str,
					success : function(result){
						$('select[name=subcategory_id]').html(result);
						$('.preloader').hide();
					}
				});
			}

			function getSUbsub(str){
				$('.preloader').show();
				$.ajax({
					url: "<?= base_url('products/fetch_sub_subcategory/'); ?>"+str,
					success : function(result){
						$('select[name=sub_subcategory_id]').html(result);
						$('.preloader').hide();
					}
				});
			}

		</script>
</body>
</html>