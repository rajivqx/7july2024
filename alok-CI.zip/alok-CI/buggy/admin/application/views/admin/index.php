<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Dashboard - admin template</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/plugins/morris/morris.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
             <?php include('comman/header.php'); ?>
             <?php include('comman/side.php'); ?>
            
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-md-6 col-sm-6 col-lg-3">
							<div class="dash-widget clearfix card-box">
								<span class="dash-widget-icon"><i class="fa fa-cubes" aria-hidden="true"></i></span>
								<div class="dash-widget-info">
									<h3><?= $this->mymodel->count_all('products')?></h3>
									<span>Products</span>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-6 col-lg-3">
							<div class="dash-widget clearfix card-box">
								<span class="dash-widget-icon"><i class="fa fa-users" aria-hidden="true"></i></span>
								<div class="dash-widget-info">
									<h3><?= $this->mymodel->count_all('customers')?></h3>
									<span>Users</span>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-6 col-lg-3">
							<div class="dash-widget clearfix card-box">
								<span class="dash-widget-icon"><i class="fa fa-shopping-bag"></i></span>
								<div class="dash-widget-info">
									<h3><?= $this->mymodel->count_where('orders', array('deliver_status'=>'INPROCESS')); ?></h3>
									<span>New Orders</span>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-6 col-lg-3">
							<div class="dash-widget clearfix card-box">
								<span class="dash-widget-icon"><i class="fa fa-user" aria-hidden="true"></i></span>
								<div class="dash-widget-info">
									<h3><?= $this->mymodel->count_all('vendors')?></h3>
									<span>Vendors</span>
								</div>
							</div>
						</div>
					</div>
					<!--<div class="row">
						<div class="col-md-12">
							<div class="row">
								<div class="col-sm-6 text-center">
									<div class="card-box">
										<div id="area-chart" ></div>
									</div>
								</div>
								<div class="col-sm-6 text-center">
									<div class="card-box">
										<div id="line-chart"></div>
									</div>
								</div>
								<div  class="col-md-4 col-sm-12 text-center">
									<div class="card-box">
										<div id="bar-chart" ></div>
									</div>
								</div>
								<div class="col-md-4 col-sm-12 text-center">
									<div class="card-box">
										<div id="stacked" ></div>
									</div>
								</div>
								<div class="col-md-4 col-sm-12 text-center">
									<div class="card-box">
										<div id="pie-chart" ></div>
									</div>
								</div>
							</div>
						</div>
					</div>-->
					<div class="row">
						<div class="col-md-6">
							<div class="panel panel-table">
								<div class="panel-heading">
									<h3 class="panel-title">Recent Orders</h3>
								</div>
								<div class="panel-body">
									<div class="table-responsive">
										<table class="table table-striped custom-table m-b-0">
											<thead>
												<tr>
													<th>Order ID</th>
													<th>Quantity</th>
													<th>Date</th>
													<th>Price</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
                                                <?php
                                                    foreach($odr as $ord){
                                                ?>
												<tr>
													<td><a href="#"><?= $ord->order_id; ?></a></td>
													<td>
														<h2><a href="#"><?= $ord->order_quantity; ?></a></h2>
													</td>
													<td><?= date('h:ia D, d M', strtotime($ord->order_date)); ?></td>
													<td><i class="fa fa-inr"></i> <?= $ord->total_price; ?></td>
													<td>
														<span class="label label-warning-border">INPROCESS</span>
													</td>
												</tr>
                                                <?php } ?>
												
											</tbody>
										</table>
									</div>
								</div>
								<div class="panel-footer">
									<a href="<?= base_url('orders'); ?>" class="text-primary">View all order</a>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="panel panel-table">
								<div class="panel-heading">
									<h3 class="panel-title">Customers</h3>
								</div>
								<div class="panel-body">
									<div class="table-responsive">	
										<table class="table table-striped custom-table m-b-0">
											<thead>
												<tr>
													<th>Name</th>
													<th>Email</th>
													<th>Join date</th>
												</tr>
											</thead>
											<tbody>
                                                <?php
                                                    foreach($custmr as $cust){
                                                ?>
												<tr>
													<td><?= $cust->f_name.' '.$cust->l_name; ?></td>
													
													<td><?= $cust->email_id; ?></td>
													<td><?= date('D, d M', strtotime($cust->create_date)); ?></td>
												</tr>
                                                <?php } ?>
											</tbody>
										</table>
									</div>
								</div>
								<div class="panel-footer">
									<a href="<?= base_url('customers'); ?>" class="text-primary">View all Customer</a>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="panel panel-table">
								<div class="panel-heading">
									<h3 class="panel-title">Vendors</h3>
								</div>
								<div class="panel-body">
									<div class="table-responsive">
										<table class="table table-striped custom-table m-b-0">
											<thead>
												<tr>
													<th style="min-width:200px;">Name</th>
													<th>Email</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
                                                <?php
                                                    foreach($vender as $vndr){
                                                ?>
												<tr>
													<td style="min-width:200px;">
														<a href="#" class="avatar"><?= substr($vndr->company_name,0, 1)?></a>
														<h2><a href="#"><?= $vndr->company_name; ?> <span><?= $vndr->contact_person; ?> </span></a></h2>
													</td>
													<td><?= $vndr->email_id; ?></td>
													<td>
														<div class="dropdown action-label">
															<a class="btn btn-white btn-sm rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-dot-circle-o text-success"></i> <?= $vndr->status; ?>
															</a>
														</div>
													</td>
													
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
								<div class="panel-footer">
									<a href="<?= base_url('vendor'); ?>" class="text-primary">View all Vendors</a>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="panel panel-table">
								<div class="panel-heading">
									<h3 class="panel-title">Recent Category</h3>
								</div>
								<div class="panel-body">
									<div class="table-responsive">
										<table class="table table-striped custom-table m-b-0">
											<thead>
												<tr>
													<th class="col-md-3">Image</th>
													<th class="col-md-3">Category Name </th>
													<th class="col-md-3">Position</th>
													<th class="text-right col-md-1">Status</th>
												</tr>
											</thead>
											<tbody>
                                                <?php
                                                    foreach($cat as $cate){
                                                ?>
												<tr>
                                                    <td><img style="height:40px;" src="<?= base_url('asset/img/category/'.$cate->category_image); ?>"></td>
													<td>
														<h2><a href="#"><?= $cate->category_title; ?></a></h2>
														<small class="block text-ellipsis">
															<span class="text-muted"><?= $cate->category_detail; ?> </span>
														</small>
													</td>
													<td>
														<?= $cate->position; ?>
													</td>
													<td class="text-right">
														<div class="dropdown">
                                                            <a class="btn btn-white btn-sm rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-dot-circle-o text-success"></i> <?= $vndr->status; ?></a>
														</div>
													</td>
												</tr>
                                                <?php } ?>
											</tbody>
										</table>
									</div>
								</div>
								<div class="panel-footer">
									<a href="<?= base_url('category'); ?>" class="text-primary">View all Category</a>
								</div>
							</div>
						</div>
					</div>
					
				</div>
						
			</div>
        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/plugins/morris/morris.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/plugins/raphael/raphael-min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script>
				var data = [
			  { y: '2014', a: 50, b: 90},
			  { y: '2015', a: 65,  b: 75},
			  { y: '2016', a: 50,  b: 50},
			  { y: '2017', a: 75,  b: 60},
			  { y: '2018', a: 80,  b: 65},
			  { y: '2019', a: 90,  b: 70},
			  { y: '2020', a: 100, b: 75},
			  { y: '2021', a: 115, b: 75},
			  { y: '2022', a: 120, b: 85},
			  { y: '2023', a: 145, b: 85},
			  { y: '2024', a: 160, b: 95}
			],
			config = {
			  data: data,
			  xkey: 'y',
			  ykeys: ['a', 'b'],
			  labels: ['Total Income', 'Total Outcome'],
			  fillOpacity: 0.6,
			  hideHover: 'auto',
			  behaveLikeLine: true,
			  resize: true,
			  pointFillColors:['#ffffff'],
			  pointStrokeColors: ['black'],
				gridLineColor: '#eef0f2',
			  lineColors:['gray','#667eea']
		  };
		config.element = 'area-chart';
		Morris.Area(config);
		config.element = 'line-chart';
		Morris.Line(config);
		config.element = 'bar-chart';
		Morris.Bar(config);
		config.element = 'stacked';
		config.stacked = true;
		Morris.Bar(config);
		Morris.Donut({
		  element: 'pie-chart',
		  data: [
			{label: "Employees", value: 30},
			{label: "Clients", value: 15},
			{label: "Projects", value: 45},
			{label: "Tasks", value: 10}
		  ]
		});
		</script>
    </body>

</html>