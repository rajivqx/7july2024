<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Sub subcategory - Admin panel</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    <style>
        .attr-prop {
            border: 1px solid #ccc;
            padding: 1px 0px 12px 12px;
            background: white;
            margin-bottom: 5px;
            text-align: justify;
        }
        .attr-prop span {
            margin: 2px 11px;
            min-width: 6%;
            display: inline-block;
        }
        .prev-imgs img,.prv-img {
            width: 100px;
            height: 90px;
            margin: 4px;
            border: 1px solid #ccc;
        }
        .prev-imgs i.fa {
            position: absolute;
            color: red;
            font-size: 14px;
            z-index: 99;
            top: 6px;
            margin-left: 12px;
            cursor: pointer;
        }
    </style>
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
             <?php include('comman/side.php'); ?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-8 col-xs-6">
							<h4 class="page-title">Edit product</h4>
						</div>
						<div class="col-sm-4 col-xs-6 text-right m-b-30">
							<a href="<?= base_url('products'); ?>" class="btn btn-primary rounded"><i class="fa fa-reply"></i> Back</a>
						</div>
					</div>
					<div class="row">
						<div class="col-md-8 col-md-offset-2">
							<div class="modal-body">
                                
                                <?= form_open_multipart(base_url('products/edits'), array('class'=>'form-submit add_prdfrm form-horizontal')); ?>
                                
                                <div class="row">
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Category:</label>
                                        <div class="col-sm-9">
                                            <select class="select" name="category_id" onchange="getSUb(this.value)">
												<option value="">Select category</option>
												<?php
													$cats = $this->mymodel->select_all('*', 'category', 'category_id', 'desc');
													foreach ($cats as $cat) {
												?>
													<option value="<?= $cat->category_id ?>" <?php if($cat->category_id == $list->category_id){echo 'selected'; } ?>><?= $cat->category_title ?></option>
												<?php	} ?>
												
											</select>
                                        </div>
                                    </div>
                                    <input type="hidden" name="prdid" value="<?= $list->id; ?>">
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Sub Category:</label>
                                        <div class="col-sm-9">
                                            <select class="select" name="subcategory_id" onchange="getSUbsub(this.value)">
												<option value="">Select sub category</option>
												<?php
													$scats = $this->mymodel->select_all('*', 'subcategory', 'subcategory_id', 'desc');
													foreach ($scats as $cat) {
												?>
													<option value="<?= $cat->subcategory_id ?>" <?php if($cat->subcategory_id == $list->subcategory_id){echo 'selected'; } ?>><?= $cat->title ?></option>
												<?php	} ?>

											</select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Sub sub-Category:</label>
                                        <div class="col-sm-9">
                                            <select class="select" name="sub_subcategory_id">
												<option value="">Select  sub category</option>
												<?php
													$cats = $this->mymodel->select_all('*', 'sub_subcategory', 'id', 'desc');
													foreach ($cats as $cat) {
												?>
													<option value="<?= $cat->id ?>" <?php if($cat->id == $list->sub_subcategory){echo 'selected'; } ?>><?= $cat->title ?></option>
												<?php	} ?>
											</select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Product Name:</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="text" name="title" value="<?= $list->title; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Heading line:</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="text" name="hline" value="<?= $list->heading_line;?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">SKU:</label>
                                        <div class="col-sm-5">
                                            <input class="form-control" type="text" name="sku" value="<?= $list->sku;?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">MRP:</label>
                                        <div class="col-sm-5">
                                            <input class="form-control" type="text" name="mrp" value="<?= $list->mrp;?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Sell Price:</label>
                                        <div class="col-sm-5">
                                            <input class="form-control" type="text" name="price" value="<?= $list->price;?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Select Brand</label>
                                        <div class="col-sm-5">
                                            <select class="select" name="brand">
                                                <option value="">Select  Brand</option>
                                                
                                                <?php
													$brand = $this->mymodel->select_all('*', 'brands', 'title', 'asc');
													foreach ($brand as $brnd) {
												?>
													<option value="<?= $brnd->id ?>" <?php if($brnd->id == $list->brand_id){echo 'selected'; } ?>><?= $brnd->title ?></option>
												<?php	} ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label col-sm-3">Attributes</label>
                                        <div class="col-md-9">
                                           <?php
                                                $brand = $this->mymodel->select_all('*', 'attributes', 'name', 'asc');
                                                foreach ($brand as $brnd) {
                                            ?>
                                            <div class="attr-prop">
                                                <h5><?= $brnd->name ?></h5>
                                                <?php
                                                    $attr = $this->mymodel->select_all_where('*', array('attribute_id'=>$brnd->id), 'attribute_property');
                                                    foreach ($attr as $att) {
                                                        $ckek = $this->mymodel->get_1('id', 'product_property', array('property_id'=>$att->id, 'product_id'=>$list->id));;
                                                ?>
                                                <span>
                                                    <input type="checkbox" name="prop[]" value="<?= $att->id; ?>" <?php if($ckek){echo'checked';}?>> : <?= $att->name; ?>
                                                </span>
                                                <?php	} ?>
                                            </div>  
                                            <?php	} ?>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
									<label>Highlights</label>
									<textarea rows="4" cols="5" class="form-control summernote" name="short_dtl" placeholder="Enter your message here"><?= $list->short_details;?></textarea>
								</div>
                                
                                <div class="form-group">
									<label>Description</label>
									<textarea rows="4" cols="5" class="form-control summernote" name="detail" placeholder="Enter your message here"><?= $list->detail; ?></textarea>
								</div>
                                 
								<div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Upload Files</label>
                                            <input class="form-control" multiple type="file" name="userfile[]" onchange="imagesPreview(this, '#preview-img')">
                                            <p><sub class="text-danger">*Image size must be 570*500 px</sub></p>
                                        </div>
                                    </div>
									
									<div class="col-md-6">
                                        
										<div id="preview-img"></div>
									</div>
                                    <div class="col-md-12">
                                        <div class="prev-imgs">
                                            <?php
                                                $imgs = $this->mymodel->select_all_where('*', array('product_id'=>$list->id), 'product_image');
                                                foreach ($imgs as $img) {
                                            ?>
                                            <span>
                                                <i class="fa fa-times" onclick="removeImg(this)" data-id="<?= $img->id; ?>"></i>
                                            <img src="<?= base_url('../asset/images/products/'.$img->image_link); ?>" >
                                            </span>
                                            <?php } ?>
                                        </div>
                                    </div>
								</div>
                                
								<div class="m-t-20 text-center">
									<button class="btn btn-primary" type="submit">Update product</button>
								</div>
							<?= form_close(); ?>
							
						</div>
						</div>
					</div>
                </div>
				
            </div>
            
        </div>
        <script>
            function removeImg(sret){
                var id = $(sret).data('id');
                $.ajax({
                    url: '<?= base_url('products/removeimg/'); ?>'+id,
                    success: function(result){
                        $(sret).parent().remove();
                    }
                });
            }
        </script>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>
		<script>
			$(document).ready(function(){
				$('.summernote').summernote({
					height: 200,                 // set editor height
					minHeight: null,             // set minimum height of editor
					maxHeight: null,             // set maximum height of editor
					focus: false                 // set focus to editable area after initializing summernote
				});
			});
        </script>
		<script>
			function getSUb(str){
				$('.preloader').show();
				$.ajax({
					url: "<?= base_url('products/fetch_subcategory/'); ?>"+str,
					success : function(result){
						$('select[name=subcategory_id]').html(result);
						$('.preloader').hide();
					}
				});
			}

			function getSUbsub(str){
				$('.preloader').show();
				$.ajax({
					url: "<?= base_url('products/fetch_sub_subcategory/'); ?>"+str,
					success : function(result){
						$('select[name=sub_subcategory_id]').html(result);
						$('.preloader').hide();
					}
				});
			}

		</script>
</body>
</html>