<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Project - HRMS admin template</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/dataTables.bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap-datetimepicker.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
            <?php include('comman/side.php'); ?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-4">
							<h4 class="page-title">Orders</h4>
						</div>
						
					</div>
					<div class="row filter-row">
						<div class="col-sm-6 col-xs-6">  
							<div class="form-group form-focus">
								<label class="control-label">Key word</label>
								<input type="text" class="form-control floating" />
							</div>
						</div>
						<div class="col-sm-3 col-xs-6"> 
							<div class="form-group form-focus select-focus">
								<label class="control-label">Status</label>
								<select class="select floating"> 
									<option value="1">Pending</option>
									<option value="1">Android Developer</option>
									<option value="1">Ios Developer</option>
								</select>
							</div>
						</div>
						<div class="col-sm-3 col-xs-6">  
							<a href="#" class="btn btn-success btn-block"> Search </a>  
						</div>     
                    </div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table datatable">
									<thead>
										<tr>
											<th>Oredr id</th>
											<th>Date</th>
											<th>Product</th>
											<th>Amount</th>
											<th>Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											foreach ($list as $odr){
                                                
                                                /*
												$cat = $this->mymodel->get_1('category_title', 'category', array('category_id'=>$prd->category_id));
												$scat = $this->mymodel->get_1('title', 'subcategory', array('subcategory_id'=>$prd->subcategory_id));
												$sscat = $this->mymodel->get_1('title', 'sub_subcategory', array('id'=>$prd->sub_subcategory));
                                                $img = $this->mymodel->get_1('*', 'product_image', array('product_id'=>$prd->id));
                                                if($img){$imag_lnk = $img->image_link; }else{
                                                    $imag_lnk = 'default.png';
                                                }*/
										?>
										<tr>
                                            <td><?= $odr->order_id; ?></td>
                                            <td><?= date('h:i A d M-y', strtotime($odr->order_date)); ?></td>
											<td>
                                                <?php
                                                    $item = $this->mymodel->select_all_where('*', array('order_id'=>$odr->order_id), 'order_items');
                                                    foreach($item as $itm){
                                                        $prd = $this->mymodel->get_1('*', 'products', array('id'=>$itm->product_id));
                                                        $img = $this->mymodel->get_1('*', 'product_image', array('product_id'=>$prd->id));
                                                        if($img){$imag_lnk = $img->image_link; }else{
                                                            $imag_lnk = 'default.png';}
                                                ?>
                                                <div class="row">
                                                    <div class="col-sm-3">
                                                        <img src="<?= base_url('../asset/images/products/'.$imag_lnk); ?>" style="height: 50px; width: 50px;">
                                                    </div>
                                                </div>
                                                <?php } ?>
                                            </td>
											<td><i class="fa fa-inr"></i> <?= $odr->total_price; ?></td>
											<td><?= $odr->deliver_status; ?></td>
											<td class="text-right">
												<a href="#" data-id="<?= $odr->order_id; ?>" class="delet-btn" data-toggle="modal" data-target="#delete_project"><i class="fa fa-eye m-r-5"></i> View</a>
											</td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
				
            </div>
			<div id="create_project" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<div class="modal-content modal-lg">
						<div class="modal-header">
							<h4 class="modal-title">Create Product</h4>
						</div>
						<div class="modal-body">
							<?= form_open_multipart(base_url('products/add'), array('class'=>'form-submit')); ?>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Category</label>
											<select class="select" name="category_id" onchange="getSUb(this.value)">
												<option value="">Select category</option>
												<?php
													$cats = $this->mymodel->select_all('*', 'category', 'category_id', 'desc');
													foreach ($cats as $cat) {
														echo '<option value="'.$cat->category_id.'">'.$cat->category_title.'</option>';
													}
												?>
												
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Sub Category</label>
											<select class="select" name="subcategory_id" onchange="getSUbsub(this.value)">
												<option value="">Select sub category</option>
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Sub sub-Category</label>
											<select class="select" name="sub_subcategory_id">
												<option value="">Select </option>
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Product Name</label>
											<input class="form-control" type="text" name="title">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>MRP</label>
											<input placeholder="$50" class="form-control" type="text" name="mrp">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Sell Price</label>
											<input placeholder="$50" class="form-control" type="text" name="price">
										</div>
									</div>
								</div>
								<div class="form-group">
									<label>Description</label>
									<textarea rows="4" cols="5" class="form-control summernote" name="detail" placeholder="Enter your message here"></textarea>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Status</label>
											<select class="select" name="Status">
												<option value="ACTIVE">Active</option>
												<option value="INACTIVE">Inactive</option>
											</select>
										</div>
										<div class="form-group">
											<label>Upload Files</label>
											<input class="form-control" type="file" name="image" onchange="readURL(this, 'images1')">
										</div>
										<div class="form-group">
											<label>Vendor</label>
											<select class="select" name="vendor">
												<option value="">Select Vendor</option>
												<?php
													$vender = $this->mymodel->select_all('*', 'vendors', 'id', 'asc');
													foreach ($vender as $vndr) {
												?>
												<option value="<?= $vndr->id; ?>"><?= $vndr->company_name?></option>
												<?php } ?>
											</select>
										</div>
									</div>
									
									<div class="col-md-6">
										<img src="" style="max-height: 150px;" id="images1">
									</div>
								</div>
								
								<div class="m-t-20 text-center">
									<button class="btn btn-primary" type="submit">Create Product</button>
								</div>
							<?= form_close(); ?>
						</div>
					</div>
				</div>
			</div>
			
			<div id="delete_project" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Delete Project</h4>
						</div>
						<form action="<?= base_url('products/delete'); ?>" class="form-submit">
							<div class="modal-body card-box">
								<p>Are you sure want to delete this?</p>
								<input type="hidden" name="delete_id" value="">
								<div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-danger">Delete</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/moment.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap-datetimepicker.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>

		<script type="text/javascript" src="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.min.js"></script>
		 <script>
			$(document).ready(function(){
				$('.summernote').summernote({
					height: 200,                 // set editor height
					minHeight: null,             // set minimum height of editor
					maxHeight: null,             // set maximum height of editor
					focus: false                 // set focus to editable area after initializing summernote
				});
			});
        </script>
    </body>
   
<script>
	function getSUb(str){
		$('.preloader').show();
		$.ajax({
			url: "<?= base_url('products/fetch_subcategory/'); ?>"+str,
			success : function(result){
				$('select[name=subcategory_id]').html(result);
				$('.preloader').hide();
			}
		});
	}

	function getSUbsub(str){
		$('.preloader').show();
		$.ajax({
			url: "<?= base_url('products/fetch_sub_subcategory/'); ?>"+str,
			success : function(result){
				$('select[name=sub_subcategory_id]').html(result);
				$('.preloader').hide();
			}
		});
	}

</script>
</html>