<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Login - HRMS admin template</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
			<div class="account-page">
				<div class="container">
					<h3 class="account-title">Management Login</h3>
					<div class="account-box">
						<div class="account-wrapper">
							<div class="account-logo">
								<a href="#"><img src="<?= base_url('asset'); ?>/img/logo2.png"></a>
							</div>
							<form action="<?= base_url('login/signin'); ?>" class="form-submit">
								<div class="form-group form-focus">
									<label class="control-label">Username or Email</label>
									<input class="form-control floating" type="text" name="username">
								</div>
								<div class="form-group form-focus">
									<label class="control-label">Password</label>
									<input class="form-control floating" type="password" name="password">
								</div>
								<div class="form-group text-center">
									<button class="btn btn-primary btn-block account-btn" type="submit">Login</button>
								</div>
								<div class="text-center">
									<a href="<?= base_url('login'); ?>">Forgot your password?</a>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
        </div>
        <div class="notification-popup hide">
		</div>
		<div class="sidebar-overlay" data-reff="#sidebar">nnnnn</div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
        
    </body>

<!-- Mirrored from dreamguys.co.in/smarthr/purple/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 Aug 2018 10:00:04 GMT -->
</html>