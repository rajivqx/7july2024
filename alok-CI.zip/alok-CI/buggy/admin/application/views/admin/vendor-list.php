<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Clients - HRMS admin template</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/dataTables.bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
            <?php include('comman/side.php'); ?>
           
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-4 col-xs-3">
							<h4 class="page-title">Vendor</h4>
						</div>
						<div class="col-sm-8 col-xs-9 text-right m-b-20">
							<a href="#" class="btn btn-primary rounded pull-right" data-toggle="modal" data-target="#add_client"><i class="fa fa-plus"></i> Add Vendor</a>
							
						</div>
					</div>
					<div class="row filter-row">
						<div class="col-sm-3 col-xs-6">  
							<div class="form-group form-focus">
								<label class="control-label">Client ID</label>
								<input type="text" class="form-control floating" />
							</div>
						</div>
						<div class="col-sm-3 col-xs-6">  
							<div class="form-group form-focus">
								<label class="control-label">Client Name</label>
								<input type="text" class="form-control floating" />
							</div>
						</div>
						<div class="col-sm-3 col-xs-6"> 
							<div class="form-group form-focus select-focus">
								<label class="control-label">Company</label>
								<select class="select floating"> 
									<option value="">Select Company</option>
									<option value="">Global Technologies</option>
									<option value="1">Delta Infotech</option>
								</select>
							</div>
						</div>
						<div class="col-sm-3 col-xs-6">  
							<a href="#" class="btn btn-success btn-block"> Search </a>  
						</div>     
                    </div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table datatable">
									<thead>
										<tr>
											<th>Name</th>
											<th>Compney Name</th>
											<th>Contact Person</th>
											<th>Email</th>
											<th>Mobile</th>
											<th>Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach ($list as $vndr) { ?>
										<tr>
											<td>
												<a href="client-profile.html" class="avatar"><?= substr($vndr->company_name,0,1); ?></a>
												<h2><a href="#"><?= ucfirst($vndr->company_name); ?></a></h2>
											</td>
											<td><?= ucfirst($vndr->company_name); ?></td>
											<td><?= ucfirst($vndr->contact_person); ?></td>
											<td><?= $vndr->email_id; ?></td>
											<td><?= $vndr->mobile_no; ?></td>
											<td>
												<div class="dropdown action-label">
													<a class="btn btn-white btn-sm rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">
														<?php
															if($vndr->status == 'ACTIVE'){ 
																echo '<i class="fa fa-dot-circle-o text-success"></i> Active ';
															}
															else{
																echo '<i class="fa fa-dot-circle-o text-danger"></i> Inactive ';
															}
														?>
														<i class="caret"></i>

													</a>
													<ul class="dropdown-menu">
														<li><a href="#"><i class="fa fa-dot-circle-o text-success"></i> Active</a></li>
														<li><a href="#"><i class="fa fa-dot-circle-o text-danger"></i> Inactive</a></li>
													</ul>
												</div>
											</td>
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="#" data-toggle="modal" data-target="#edit_client"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" data-toggle="modal" data-target="#delete_box" data-id="<?= $vndr->id; ?>" class="delet-btn" title="Delete"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
													</ul>
												</div>
											</td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
				
            </div>
			<div id="add_client" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<div class="modal-content modal-lg">
						<div class="modal-header">
							<h4 class="modal-title">Add Vendor</h4>
						</div>
						<div class="modal-body">
							<div class="m-b-30">
								<form class="form-submit" action="<?= base_url('vendor/add'); ?>" methode="post">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Company Name <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="compnay">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Contact Person</label>
												<input class="form-control" type="text" name="contact_prson">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Mobile <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="mobile">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Email <span class="text-danger">*</span></label>
												<input class="form-control floating" type="email" name="email">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Password</label>
												<input class="form-control" type="password" name="password">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Status <span class="text-danger">*</span></label>
												<select class="form-control" name="status">
													<option value="ACTIVE">Active</option>
													<option value="INACTIVE">Inactive</option>
												</select>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label class="control-label">Address </label>
												<textarea class="form-control" name="address"></textarea>
											</div>
										</div>
										
									</div>
									
									<div class="m-t-20 text-center">
										<button class="btn btn-primary" type="submit">Create Vendor</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="delete_box" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Delete Vendor</h4>
						</div>
						<form action="<?= base_url('Vendor/delete'); ?>" class="form-submit">
							<div class="modal-body card-box">
								<p>Are you sure want to delete this?</p>
								<input type="hidden" name="delete_id" value="">
								<div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-danger">Delete</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/moment.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>
    </body>

<!-- Mirrored from dreamguys.co.in/smarthr/purple/clients-list.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 Aug 2018 10:00:27 GMT -->
</html>