<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Add new products - Admin panel</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
            <!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
        <style>
            
            .prv-img {
                width: 100px;
                height: 90px;
                margin: 4px;
                border: 1px solid #ccc;
            }
            .attr-prop {
                border: 1px solid #ccc;
                padding: 1px 0px 12px 12px;
                background: white;
                margin-bottom: 5px;
            }
        </style>
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
            <?php include('comman/side.php'); ?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-8 col-xs-6">
							<h4 class="page-title">Update blog</h4>
						</div>
						<div class="col-sm-4 col-xs-6 text-right m-b-30">
							<a href="<?= base_url('blog'); ?>" class="btn btn-primary rounded"><i class="fa fa-reply"></i> Back</a>
						</div>
                        
					</div>
					<div class="row">
						<div class="col-md-10 col-md-offset-1">
							<div class="modal-body">
							<?= form_open_multipart(base_url('blog/edt'), array('class'=>'form-submit add_prdfrm form-horizontal')); ?>
                                
                                <div class="row">
                                    
                                    <div class="form-group">
                                        <label>Blog title: </label>
                                        <input class="form-control" type="text" name="title" value="<?= $list->title; ?>">
                                    </div>
                                   
                                <div class="form-group">
									<label>Content</label>
									<textarea rows="4" cols="5" class="form-control summernote" name="short_dtl" placeholder="Enter your message here"><?= $list->contents; ?></textarea>
								</div>
                                
                               
                                 
								<div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Upload Files</label>
                                            <input class="form-control" type="file" name="image" onchange="imagesPreview(this, '#preview-img')">
                                            <input type="hidden" name="img1" value="<?= $list->image; ?>">
                                            <input type="hidden" name="edt_id" value="<?= $list->id; ?>">
                                            <p><sub class="text-danger">*Image size must be 570*500 px</sub></p>
                                        </div>
                                    </div>
									
									<div class="col-md-6">
										<div id="preview-img">
                                            <img src="<?= base_url('../asset/images/blog/'.$list->image) ?>" style="height:100px;">
                                        </div>
									</div>
								</div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Selectstatus <span class="text-danger">*</span></label>
                                            <select class="form-control" name="status">
                                                <option value="ACTIVE" <?php if($list->status == 'ACTIVE'){echo 'selected'; }?>>ACTIVE</option>
                                                <option value="INACTIVE" <?php if($list->status == 'INACTIVE'){echo 'selected'; }?>>INACTIVE</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                
								
								<div class="m-t-20 text-center">
									<button class="btn btn-primary" type="submit">Upddate blog</button>
								</div>
							<?= form_close(); ?>
                                
                              
						  </div>
						</div>
					</div>
                </div>
				
            </div>

        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/plugins/summernote/dist/summernote.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>
		<script>
			$(document).ready(function(){
				$('.summernote').summernote({
					height: 200,                 // set editor height
					minHeight: null,             // set minimum height of editor
					maxHeight: null,             // set maximum height of editor
					focus: false                 // set focus to editable area after initializing summernote
				});
			});
            
            function  imagesPreview(input, str){
                if (input.files) {
                    var filesAmount = input.files.length;

                    for (i = 0; i < filesAmount; i++) {
                        var reader = new FileReader();

                        reader.onload = function(event) {
                            $($.parseHTML('<img class="prv-img">')).attr('src', event.target.result).appendTo(str);
                        }

                        reader.readAsDataURL(input.files[i]);
                    }
                }
            }
            
            function addprop(){
                var id = $('select[name=add_attrb]').val();
                $('option:selected', 'select[name=add_attrb]').remove();
                $.ajax({
                    url: '<?= base_url('attributes/fetch/')?>'+id,
                    success: function(result){
                        $('#attr-prop').append(result);
                        
                    }
                });
            }
            
        </script>
		<script>
			function getSUb(str){
				$('.preloader').show();
				$.ajax({
					url: "<?= base_url('products/fetch_subcategory/'); ?>"+str,
					success : function(result){
						$('select[name=subcategory_id]').html(result);
						$('.preloader').hide();
					}
				});
			}

			function getSUbsub(str){
				$('.preloader').show();
				$.ajax({
					url: "<?= base_url('products/fetch_sub_subcategory/'); ?>"+str,
					success : function(result){
						$('select[name=sub_subcategory_id]').html(result);
						$('.preloader').hide();
					}
				});
			}

		</script>
</body>
</html>