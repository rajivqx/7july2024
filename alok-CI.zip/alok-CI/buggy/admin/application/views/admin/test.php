<?= form_open_multipart(base_url('products/edits'), array('class'=>'form-submit')); ?>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Category</label>
											<select class="select" name="category_id" onchange="getSUb(this.value)">
												<option value="">Select category</option>
												<?php
													$cats = $this->mymodel->select_all('*', 'category', 'category_id', 'desc');
													foreach ($cats as $cat) {
												?>
													<option value="<?= $cat->category_id ?>" <?php if($cat->category_id == $list->category_id){echo 'selected'; } ?>><?= $cat->category_title ?></option>
												<?php	} ?>
												
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Sub Category</label>
											
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Sub sub-Category</label>
											
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Product Name</label>
											<input class="form-control" type="text" name="title" value="<?= $list->title; ?>">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>MRP</label>
											<input placeholder="$50" class="form-control" type="text" name="mrp" >
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Sell Price</label>
											<input placeholder="$50" class="form-control" type="text" name="price" value="<?= $list->price;?>">
										</div>
									</div>
								</div>
								<div class="form-group">
									<label>Description</label>
									<textarea rows="4" cols="5" class="form-control summernote" name="detail" placeholder="Enter your message here"><?= $list->detail;?></textarea>
									<input type="hidden" name="edit" value="<?= $list->id; ?>">
									<input type="hidden" name="gallery" value="<?= $list->thumbnail; ?>">
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Status</label>
											<select class="select" name="Status">
												<option value="ACTIVE" <?php if($list->status == 'ACTIVE'){echo 'selected'; } ?>>Active</option>
												<option value="PENDING" <?php if($list->status == 'PENDING'){echo 'selected'; } ?>>Pending</option>
												<option value="INACTIVE" <?php if($list->status == 'INACTIVE'){echo 'selected'; } ?>>Inactive</option>
											</select>
										</div>
										<div class="form-group">
											<label>Upload Files</label>
											<input class="form-control" type="file" name="image" onchange="readURL(this, 'images1')">
										</div>
										<div class="form-group">
											<label>Vendor</label>
											<select class="select" name="vendor">
												<option value="">Select Vendor</option>
												<?php
													$vender = $this->mymodel->select_all('*', 'vendors', 'id', 'asc');
													foreach ($vender as $vndr) {
												?>
												<option value="<?= $vndr->id; ?>" <?php if($vndr->id == $list->vender_id){echo 'selected'; } ?>><?= $vndr->company_name?></option>
												<?php } ?>
											</select>
										</div>
									</div>
									
									<div class="col-md-6">
										<img src="<?= base_url('asset/img/products/'.$list->thumbnail); ?>" style="max-height: 150px;" id="images1">
									</div>
								</div>
								
								<div class="m-t-20 text-center">
									<button class="btn btn-primary" type="submit">Edit product</button>
								</div>
							<?= form_close(); ?>