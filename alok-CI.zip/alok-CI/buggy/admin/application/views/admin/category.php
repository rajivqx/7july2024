<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('asset'); ?>/img/favicon.png">
        <title>Category - Admin panel</title>
		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/select2.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url('asset'); ?>/css/style.css">
		<!--[if lt IE 9]>
			<script src="<?= base_url('asset'); ?>/js/html5shiv.min.js"></script>
			<script src="<?= base_url('asset'); ?>/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
            <?php include('comman/header.php'); ?>
             <?php include('comman/side.php'); ?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-8 col-xs-6">
							<h4 class="page-title">Category</h4>
						</div>
						<div class="col-sm-4 col-xs-6 text-right m-b-30">
							<a href="#" class="btn btn-primary rounded" data-toggle="modal" data-target="#add_tax"><i class="fa fa-plus"></i> Add Category</a>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table m-b-0">
									<thead>
										<tr>
											<th>#</th>
											<th>Image</th>
											<th>Category Name </th>
											<th>Position</th>
											<th>Detail</th>
											<th>Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach ($list as $lst) {
										?>
										<tr>
											<td>1</td>
											<td><img src="<?= base_url('asset/img/category/'.$lst->category_image); ?>" style="height: 100px;"></td>
											<td><?= $lst->category_title; ?></td>
											<td><?= $lst->position; ?></td>
											<td><?= $lst->category_detail; ?></td>
											<td>
												<div class="dropdown action-label">
													<a class="btn btn-white btn-sm rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">
														<?php
															if($lst->status == 'ACTIVE'){ 
																echo '<i class="fa fa-dot-circle-o text-success"></i> Active ';
															}
															else{
																echo '<i class="fa fa-dot-circle-o text-danger"></i> Inactive ';
															}
														?>
														<i class="caret"></i>

													</a>
													<ul class="dropdown-menu">
														<li><a href="#"><i class="fa fa-dot-circle-o text-success"></i> Active</a></li>
														<li><a href="#"><i class="fa fa-dot-circle-o text-danger"></i> Inactive</a></li>
													</ul>
												</div>
											</td>
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="#" class="edit_btn" data-toggle="modal" data-target="#edit_tax" title="Edit" data-title="<?= $lst->category_title; ?>" data-detail="<?= $lst->category_detail; ?>" data-position="<?= $lst->position; ?>" data-id="<?= $lst->category_id; ?>" data-status="<?= $lst->status; ?>" data-image="<?= $lst->category_image; ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" data-toggle="modal" data-target="#delete_box" data-id="<?= $lst->category_id; ?>" class="delet-btn" title="Delete"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
													</ul>
												</div>
											</td>
										</tr>
									<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
				
            </div>

			<div id="delete_box" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Delete Category</h4>
						</div>
						<form action="<?= base_url('category/delete'); ?>" class="form-submit">
							<div class="modal-body card-box">
								<p>Are you sure want to delete this?</p>
								<input type="hidden" name="delete_id" value="">
								<div class="m-t-20 text-left">
									<a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
									<button type="submit" class="btn btn-danger">Delete</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div id="add_tax" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Add Category</h4>
						</div>
						<div class="modal-body">
							<?= form_open_multipart(base_url('category/add_category'), array('class'=>'form-submit')); ?>
								<div class="col-md-12">
									<div class="form-group">
										<label>Category Name <span class="text-danger">*</span></label>
										<input class="form-control" required="" type="text" name="title">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label>Category Detail <span class="text-danger">*</span></label>
										<textarea class="form-control" required="" name="detail"></textarea>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label>Category position <span class="text-danger">*</span></label>
										<input class="form-control" required="" type="text" name="position">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Status <span class="text-danger">*</span></label>
										<select class="select" name="status">
											<option value="ACTIVE">Active</option>
											<option value="INACTIVE">Inactive</option>
										</select>
									</div>
									<div class="form-group">
										<label>Image <span class="text-danger">*</span></label>
										<input type="file" name="image" onchange="readURL(this, 'images1')">
									</div>
								</div>
								<div class="col-md-6">
									<img src="<?= base_url('asset/img/category/default.png'); ?>" alt="category image" id="images1" style="height: 200px;">
								</div>
								<div class="clearfix"></div>

								<div class="m-t-20 text-center">
									<button class="btn btn-primary">Create Catgegory</button>
								</div>
							<?= form_close(); ?>
						</div>
					</div>
				</div>
			</div>


			
			<div id="edit_tax" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Edit Category</h4>
						</div>
						<div class="modal-body">
							<?= form_open_multipart(base_url('category/edit_category'), array('class'=>'form-submit')); ?>

							<div class="col-md-12">
								<div class="form-group">
									<label>Category Name <span class="text-danger">*</span></label>
									<input class="form-control" required="" type="text" name="e_title" value="">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label>Category Detail <span class="text-danger">*</span></label>
									<textarea class="form-control" required="" name="e_detail"></textarea>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label>Category position <span class="text-danger">*</span></label>
									<input class="form-control" required="" type="text" name="e_position" value="">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Status <span class="text-danger">*</span></label>
									<select class="form-control" name="e_status">
										<option value="ACTIVE">Active</option>
										<option value="INACTIVE">Inactive</option>
									</select>
								</div>
								<div class="form-group">
									<label>Image <span class="text-danger">*</span></label>
									<input type="file" name="e_image" onchange="readURL(this, 'edt-img')">
									<input type="hidden" name="gallery_img" value="">
								</div>
							</div>
							<div class="col-md-6">
								<input type="hidden" name="category_id" value="">
								<img src="" alt="category image" id="edt-img" style="height: 200px;">
							</div>
							<div class="clearfix"></div>

							<div class="m-t-20 text-center">
								<button type="submit" class="btn btn-primary">Update Catgegory</button>
							</div>
							<?= form_close(); ?>
							
						</div>
					</div>
				</div>
			</div>
        </div>
		<div class="sidebar-overlay" data-reff="#sidebar"></div>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="<?= base_url('asset'); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/jquery.slimscroll.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/select2.min.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/app.js"></script>
		<script type="text/javascript" src="<?= base_url('asset'); ?>/js/myjs.js"></script>
		<script>
			$(document).ready(function(){
				$('.edit_btn').click(function(){
					$('input[name=e_title]').val($(this).data('title'));
					$('textarea[name=e_detail]').val($(this).data('detail'));
					$('input[name=e_position]').val($(this).data('position'));
					$('input[name=category_id]').val($(this).data('id'));
					$('select[name=e_status]').val($(this).data('status'));
					$('input[name=gallery_img]').val($(this).data('image'));
					$('#edt-img').attr('src','<?= base_url('asset/img/category/'); ?>'+$(this).data('image'));
				});
			});

		</script>
</body>
</html>